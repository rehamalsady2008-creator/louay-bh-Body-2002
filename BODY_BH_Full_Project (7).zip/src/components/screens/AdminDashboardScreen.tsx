import React, { useState } from 'react';
import { ArrowLeft, Shield, Users, DollarSign, AlertTriangle, Check, X, TrendingUp, Sparkles } from 'lucide-react';
import { MOCK_ADMIN_STATS } from '../../data/mockData';

interface AdminDashboardScreenProps {
  onBack: () => void;
}

export const AdminDashboardScreen: React.FC<AdminDashboardScreenProps> = ({ onBack }) => {
  const [reports, setReports] = useState([
    { id: 'r1', postUser: '@zayn_power', reason: 'Unverified medical claim in workout video caption', status: 'pending' },
    { id: 'r2', postUser: '@fake_creator.bh', reason: 'Impersonating official BODY BH ambassador in Bahrain Bay', status: 'pending' },
  ]);

  const stats = MOCK_ADMIN_STATS;

  const handleResolve = (id: string, action: 'dismiss' | 'remove') => {
    setReports((prev) => prev.filter((r) => r.id !== id));
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 p-4 pt-12 pb-28 max-w-md mx-auto selection:bg-amber-400 selection:text-slate-900">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 pb-3 border-b border-slate-200">
        <button onClick={onBack} className="p-2.5 rounded-full bg-slate-100 border border-slate-200 text-slate-700 hover:text-slate-900 transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2">
          <img src="/logo.jpg" alt="BODY BH Logo" className="w-7 h-7 rounded-lg object-cover border border-amber-400 shadow-xs" />
          <h1 className="text-sm font-black text-slate-900 tracking-tight uppercase">لوحة تحكم إدارة BODY BH 🇧🇭</h1>
        </div>
        <div className="w-8" />
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="p-4 rounded-3xl bg-slate-50 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider">Active Users</span>
            <Users className="w-4 h-4 text-amber-600" />
          </div>
          <span className="text-xl font-black text-slate-900">{(stats.totalUsers / 1000).toFixed(1)}k</span>
          <span className="text-[9px] text-emerald-600 font-extrabold block mt-1">+14.2% traffic growth</span>
        </div>

        <div className="p-4 rounded-3xl bg-slate-50 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider">Monthly Revenue</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <span className="text-xl font-black text-slate-900">${stats.monthlyRevenue.toLocaleString()}</span>
          <span className="text-[9px] text-amber-700 font-extrabold block mt-1">BODY BH+ VIP Pass</span>
        </div>
      </div>

      {/* Analytics Chart Simulation */}
      <div className="p-5 rounded-3xl bg-slate-50 border border-slate-200 mb-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xs font-black text-slate-900">Daily Active Engagement</h3>
            <span className="text-[10px] text-slate-500 font-medium">Kingdom of Bahrain Network Traffic</span>
          </div>
          <TrendingUp className="w-4 h-4 text-amber-600" />
        </div>

        {/* Visual Bar Chart */}
        <div className="flex items-end justify-between h-28 pt-4 border-b border-slate-200 px-2">
          {stats.dailyActiveUsers.map((val, idx) => {
            const heightPercent = (val / 80000) * 100;
            return (
              <div key={idx} className="flex flex-col items-center gap-1.5 flex-1">
                <div
                  className="w-full max-w-[18px] bg-gradient-to-t from-amber-400 to-amber-300 rounded-t-lg shadow-xs"
                  style={{ height: `${heightPercent}%` }}
                />
                <span className="text-[8px] text-slate-400 font-mono font-bold">Day {idx + 1}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Moderation Queue */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <AlertTriangle className="w-4 h-4 text-rose-500" />
          <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">
            Content Moderation Queue ({reports.length})
          </h3>
        </div>

        <div className="space-y-3">
          {reports.length === 0 ? (
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-center text-xs text-slate-500 font-medium">
              No pending reports. All content verified clean.
            </div>
          ) : (
            reports.map((report) => (
              <div
                key={report.id}
                className="p-4 rounded-3xl bg-slate-50 border border-rose-200 flex items-center justify-between gap-3 shadow-xs"
              >
                <div>
                  <span className="text-xs font-black text-rose-600 block">{report.postUser}</span>
                  <p className="text-[11px] text-slate-700 leading-snug mt-0.5 font-medium">{report.reason}</p>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => handleResolve(report.id, 'dismiss')}
                    className="p-2.5 rounded-xl bg-slate-100 text-slate-500 hover:text-slate-900 transition-colors border border-slate-200"
                    title="Dismiss Report"
                  >
                    <X className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleResolve(report.id, 'remove')}
                    className="p-2.5 rounded-xl bg-rose-500 text-white font-bold hover:bg-rose-600 transition-colors shadow-xs"
                    title="Remove Content"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
