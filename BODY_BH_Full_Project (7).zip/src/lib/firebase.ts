import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  OAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendEmailVerification,
  signInWithPhoneNumber,
  RecaptchaVerifier,
  ConfirmationResult,
  signOut,
  sendPasswordResetEmail,
  onAuthStateChanged,
  User
} from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

declare global {
  interface Window {
    recaptchaVerifier?: RecaptchaVerifier;
    confirmationResult?: ConfirmationResult;
  }
}

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId || undefined);

export const setupRecaptcha = (containerId: string = 'recaptcha-container') => {
  try {
    const container = document.getElementById(containerId);
    if (!window.recaptchaVerifier && container) {
      window.recaptchaVerifier = new RecaptchaVerifier(auth, containerId, {
        size: 'invisible',
        callback: () => {
          // Recaptcha solved
        }
      });
    }
  } catch (err) {
    console.warn('Recaptcha init notice:', err);
  }
  return window.recaptchaVerifier;
};

export const sendSMSCode = async (phoneNumber: string, containerId: string = 'recaptcha-container') => {
  try {
    const appVerifier = setupRecaptcha(containerId);
    if (!appVerifier) {
      return { confirmationResult: null, error: 'Recaptcha container not ready' };
    }
    const confirmationResult = await signInWithPhoneNumber(auth, phoneNumber, appVerifier);
    window.confirmationResult = confirmationResult;
    return { confirmationResult, error: null };
  } catch (error: any) {
    if (error?.code === 'auth/operation-not-allowed' || error?.message?.includes('operation-not-allowed')) {
      console.warn('Firebase Phone Auth is disabled in Firebase Console (auth/operation-not-allowed). Fallback activated.');
      return {
        confirmationResult: null,
        error: 'auth/operation-not-allowed: تسجيل الدخول بواسطة رقم الهاتف غير مفعّل في Firebase Console. تم تفعيل وضع التجربة وتوليد كود الـ OTP في الإشعار العلوي.'
      };
    }
    console.warn('SMS Code Notice:', error?.message || error);
    return { confirmationResult: null, error: error?.message || 'فشل إرسال كود التحقق عبر SMS' };
  }
};

export const confirmSMSCode = async (code: string) => {
  try {
    if (!window.confirmationResult) {
      throw new Error('لم يتم العثور على طلب كود سابق. يرجى إعادة طلب كود التحقق.');
    }
    const result = await window.confirmationResult.confirm(code);
    return { user: result.user, error: null };
  } catch (error: any) {
    console.error('Verify OTP Error:', error);
    return { user: null, error: error.message || 'كود التحقق غير صحيح أو منتهي الصلاحية' };
  }
};

export const logoutUser = async () => {
  try {
    await signOut(auth);
    return { success: true, error: null };
  } catch (error: any) {
    console.error('Logout error:', error);
    return { success: false, error: error.message };
  }
};

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

export const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return { user: result.user, error: null };
  } catch (error: any) {
    console.error('Google Sign-In Error:', error);
    return { user: null, error: error.message || 'فشل تسجيل الدخول عبر Google' };
  }
};

export const sendUserEmailVerification = async (user: User) => {
  try {
    await sendEmailVerification(user);
    return { success: true, error: null };
  } catch (error: any) {
    console.error('Email Verification Error:', error);
    return { success: false, error: error.message || 'فشل إرسال بريد التحقق' };
  }
};

export const sendEmailCode = async (userParam?: User | null) => {
  const user = userParam || auth.currentUser;
  if (user) {
    try {
      await sendEmailVerification(user);
      console.log("تم إرسال رابط/كود التأكيد إلى البريد الإلكتروني");
      return { success: true, error: null };
    } catch (error: any) {
      console.error("خطأ في إرسال البريد:", error.message);
      return { success: false, error: error.message || "حدث خطأ أثناء الإرسال" };
    }
  } else {
    console.log("لا يوجد مستخدم مسجل حالياً.");
    return { success: false, error: "لا يوجد مستخدم مسجل حالياً." };
  }
};

export const appleProvider = new OAuthProvider('apple.com');

export const signInWithApple = async () => {
  try {
    const result = await signInWithPopup(auth, appleProvider);
    return { user: result.user, error: null };
  } catch (error: any) {
    console.error('Apple Sign-In Error:', error);
    return { user: null, error: error.message || 'فشل تسجيل الدخول عبر Apple' };
  }
};

export const registerWithEmail = async (email: string, pass: string) => {
  try {
    const res = await createUserWithEmailAndPassword(auth, email, pass);
    if (res.user) {
      await sendEmailVerification(res.user);
    }
    return { user: res.user, error: null };
  } catch (error: any) {
    console.error('Email Registration Error:', error);
    let msg = 'حدث خطأ أثناء إنشاء الحساب';
    if (error.code === 'auth/email-already-in-use') msg = 'البريد الإلكتروني مستخدم بالفعل';
    if (error.code === 'auth/weak-password') msg = 'كلمة المرور ضعيفة جداً (يجب أن تكون 6 أحرف على الأقل)';
    if (error.code === 'auth/invalid-email') msg = 'صيغة البريد الإلكتروني غير صالحة';
    return { user: null, error: msg };
  }
};

export const loginWithEmail = async (email: string, pass: string) => {
  try {
    const res = await signInWithEmailAndPassword(auth, email, pass);
    return { user: res.user, error: null };
  } catch (error: any) {
    console.error('Email Login Error:', error);
    let msg = 'بيانات الدخول غير صحيحة';
    if (error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
      msg = 'البريد الإلكتروني أو كلمة المرور غير صحيحة';
    }
    return { user: null, error: msg };
  }
};

export const resetPasswordEmail = async (email: string) => {
  try {
    await sendPasswordResetEmail(auth, email);
    return { success: true, error: null };
  } catch (error: any) {
    console.error('Password Reset Error:', error);
    let msg = 'تعذر إرسال رابط إعادة تعيين كلمة المرور';
    if (error.code === 'auth/user-not-found') msg = 'البريد الإلكتروني غير مسجل بالمنصة';
    if (error.code === 'auth/invalid-email') msg = 'صيغة البريد الإلكتروني غير صحيحة';
    return { success: false, error: msg };
  }
};

export { onAuthStateChanged };
export type { User };
