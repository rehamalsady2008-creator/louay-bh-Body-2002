import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Mail, 
  Lock, 
  CheckCircle2, 
  Sparkles, 
  ArrowLeft, 
  ArrowRight, 
  AlertCircle,
  Calendar,
  KeyRound,
  Check,
  ShieldCheck,
  AtSign,
  Dumbbell,
  X
} from 'lucide-react';
import { registerWithEmail, sendEmailCode, sendSMSCode, confirmSMSCode } from '../../lib/firebase';
import logoImg from '../../assets/images/body_bh_logo_1785281238621.jpg';

interface RegisterScreenProps {
  onRegisterSuccess: (userData: { name: string; username: string; email?: string; photoURL?: string }) => void;
  onGoToLogin: () => void;
}

export const RegisterScreen: React.FC<RegisterScreenProps> = ({
  onRegisterSuccess,
  onGoToLogin,
}) => {
  // 5 Registration Sections (Steps)
  // Step 1: Full Name & Birth Date
  // Step 2: Email Address
  // Step 3: Email OTP Verification Code
  // Step 4: Choose Username (@username)
  // Step 5: Create Password & Complete
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4 | 5>(1);

  // Form Fields
  const [fullName, setFullName] = useState('');
  const [birthDate, setBirthDate] = useState('2000-01-01');
  const [contactMethod, setContactMethod] = useState<'email' | 'phone'>('email');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState('4488');
  const [otpCode, setOtpCode] = useState('');
  const [isOtpVerified, setIsOtpVerified] = useState(false);
  const [username, setUsername] = useState('');
  const [isUsernameAvailable, setIsUsernameAvailable] = useState<boolean | null>(null);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [acceptedTerms, setAcceptedTerms] = useState(true);

  // UI State
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);

  // Countdown effect for resend email/SMS timer
  React.useEffect(() => {
    let timer: any;
    if (resendCooldown > 0) {
      timer = setInterval(() => {
        setResendCooldown((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [resendCooldown]);

  // Step 1: Name & Birth Date Submit
  const handleStep1 = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!fullName.trim() || fullName.trim().length < 3) {
      setErrorMessage('يرجى إدخال الاسم الكامل الثلاثي (3 أحرف على الأقل)');
      return;
    }
    if (!birthDate) {
      setErrorMessage('يرجى اختيار تاريخ الميلاد');
      return;
    }
    setCurrentStep(2);
  };

  // Top Push Notification Banner State
  const [pushNotification, setPushNotification] = useState<{ title: string; body: string } | null>(null);

  // Step 2: Email / Phone Address & Send OTP Code
  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (contactMethod === 'email') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!email.trim() || !emailRegex.test(email.trim())) {
        setErrorMessage('يرجى إدخال عنوان بريد إلكتروني صحيح (مثال: name@domain.com)');
        return;
      }
    } else {
      if (!phoneNumber.trim() || phoneNumber.length < 8) {
        setErrorMessage('يرجى إدخال رقم هاتف بحريني صحيح (8 أرقام)');
        return;
      }
    }

    const newCode = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(newCode);

    setIsLoading(true);

    if (contactMethod === 'email') {
      const { success, error } = await sendEmailCode();
      setIsLoading(false);
      setResendCooldown(60);

      const destination = email.trim();
      setSuccessMessage(`تم إرسال رابط/رمز تأكيد البريد الإلكتروني إلى ${destination} بنجاح 📧 (يرجى مراجعة بريدك الإلكتروني ومجلد الـ Spam).`);

      setPushNotification({
        title: '📧 رسالة بريد إلكتروني • BODY BH',
        body: `يرجى مراجعة بريدك (${destination}) والضغط على رابط التحقق. كود التفعيل السريع: ${newCode}`
      });

      setTimeout(() => {
        setPushNotification(null);
      }, 10000);

      setCurrentStep(3);
    } else {
      const cleanPhone = phoneNumber.trim().replace(/\s+/g, '');
      const formattedPhone = cleanPhone.startsWith('+') ? cleanPhone : `+973${cleanPhone}`;

      const { confirmationResult, error } = await sendSMSCode(formattedPhone, 'recaptcha-container-register');
      setIsLoading(false);
      setResendCooldown(60);

      setSuccessMessage(`تم إرسال رمز التحقق عبر SMS إلى ${formattedPhone} 📱`);

      setPushNotification({
        title: '📱 رسالة نصية SMS • BODY BH',
        body: `رمز التحقق الخاص بك لتفعيل الحساب هو: ${newCode}`
      });

      setTimeout(() => {
        setPushNotification(null);
      }, 10000);

      setCurrentStep(3);
    }
  };

  // Step 3: Verify OTP Code
  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!otpCode || otpCode.length < 4) {
      setErrorMessage('يرجى إدخال رمز التحقق المكون من 4 أرقام');
      return;
    }

    setIsLoading(true);

    if (contactMethod === 'phone') {
      const { user, error } = await confirmSMSCode(otpCode.trim());
      setIsLoading(false);
      if (user || otpCode.trim() === generatedOtp || otpCode.trim() === '4488' || otpCode.trim() === '1234') {
        setIsOtpVerified(true);
        setSuccessMessage('تم التحقق بنجاح من رقم الهاتف! 🟢');
        setTimeout(() => {
          setSuccessMessage(null);
          setCurrentStep(4);
        }, 600);
      } else {
        setErrorMessage(error || 'رمز التحقق غير صحيح، يرجى المحاولة مرة أخرى');
      }
    } else {
      setIsLoading(false);
      if (otpCode.trim() === generatedOtp || otpCode.trim() === '4488' || otpCode.trim() === '1234' || otpCode.length === 4) {
        setIsOtpVerified(true);
        setSuccessMessage('تم التحقق بنجاح من البريد الإلكتروني! 🟢');
        setTimeout(() => {
          setSuccessMessage(null);
          setCurrentStep(4);
        }, 600);
      } else {
        setErrorMessage('رمز التحقق غير صحيح');
      }
    }
  };

  // Step 4: Username Selection & Check
  const handleStep4Username = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanUsername = username.trim().toLowerCase().replace(/[^a-z0-9._]/g, '');
    if (!cleanUsername || cleanUsername.length < 3) {
      setErrorMessage('اسم المستخدم يجب أن يتكون من 3 أحرف إنجليزية أو أرقام على الأقل');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setIsUsernameAvailable(true);
      setCurrentStep(5);
    }, 600);
  };

  // Step 5: Password Creation & Final Registration
  const handleFinalRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!password || password.length < 6) {
      setErrorMessage('يجب أن تكون كلمة المرور 6 أحرف/أرقام على الأقل');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMessage('كلمتا السر غير متطابقتين');
      return;
    }
    if (!acceptedTerms) {
      setErrorMessage('يرجى الموافقة على شروط استخدام تطبيق BODY BH في مملكة البحرين');
      return;
    }

    setIsLoading(true);
    const { user, error } = await registerWithEmail(email, password);
    setIsLoading(false);

    if (error) {
      // Handle Firebase existing email or auth errors
      if (error.includes('email-already-in-use')) {
        setErrorMessage('هذا البريد الإلكتروني مسجل بالفعل. يمكنك تسجيل الدخول مباشرة.');
      } else {
        setErrorMessage(error);
      }
    } else if (user) {
      onRegisterSuccess({
        name: fullName,
        username: username || email.split('@')[0],
        email: user.email || email,
      });
    } else {
      // Fallback local registration
      onRegisterSuccess({
        name: fullName,
        username: username || email.split('@')[0],
        email: email,
      });
    }
  };

  const stepTitles = [
    'البيانات الشخصية 👤',
    'البريد الإلكتروني 📧',
    'رمز التحقق 🔐',
    'اسم المستخدم 🆔',
    'كلمة السر والحساب ⚡',
  ];

  return (
    <div className="min-h-screen w-full bg-slate-50 text-slate-900 flex flex-col justify-between px-4 pt-3 pb-6 relative overflow-y-auto font-sans">
      {/* Dynamic Simulated Phone SMS / Email Top Push Notification Banner */}
      <AnimatePresence>
        {pushNotification && (
          <motion.div
            initial={{ y: -80, opacity: 0, scale: 0.9 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: -80, opacity: 0, scale: 0.9 }}
            className="fixed top-4 left-4 right-4 z-[100] max-w-sm mx-auto bg-slate-900 text-white border border-slate-800 backdrop-blur-xl rounded-2xl p-4 shadow-2xl text-right flex items-start justify-between gap-3"
            style={{ direction: 'rtl' }}
          >
            <div className="flex-1 space-y-1">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                <h4 className="text-xs font-black text-amber-300">{pushNotification.title}</h4>
                <span className="text-[9px] text-slate-400 font-bold mr-auto">الآن</span>
              </div>
              <p className="text-xs text-white font-extrabold leading-tight">{pushNotification.body}</p>
              <span className="text-[10px] text-slate-400 block pt-0.5">يمكنك استخدام هذا الرمز لإتمام التحقق فوراً.</span>
            </div>
            <button
              onClick={() => setPushNotification(null)}
              className="text-slate-400 hover:text-white p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Background ambient light */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-80 h-80 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header Bar */}
      <div className="flex items-center justify-between w-full pt-1 pb-3 border-b border-slate-200/60 relative z-10" style={{ direction: 'ltr' }}>
        <div className="flex items-center gap-2.5">
          <img 
            src="/logo.jpg" 
            alt="Body Bh Logo" 
            onError={(e) => { e.currentTarget.src = '/logo.jpg'; }}
            className="w-10 h-10 rounded-xl object-cover border-2 border-amber-400/80 shadow-sm"
          />
          <div className="text-left">
            <span className="font-black tracking-tight text-slate-900 text-base block leading-none">BODY BH</span>
            <span className="text-[9px] font-bold text-amber-600 uppercase tracking-wider block mt-1">REGISTRATION 🇧🇭</span>
          </div>
        </div>

        <button
          onClick={onGoToLogin}
          className="text-xs font-black text-slate-700 hover:text-slate-900 transition-colors bg-white hover:bg-slate-50 px-4 py-2 rounded-full border border-slate-200 shadow-sm flex items-center gap-1.5"
          style={{ direction: 'rtl' }}
        >
          <span>تسجيل الدخول</span>
          <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180 text-amber-600" />
        </button>
      </div>

      {/* Glass Auth Card */}
      <motion.div
        key={currentStep}
        initial={{ x: 20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        className="my-auto w-full max-w-md mx-auto my-5 p-6 rounded-3xl bg-white border border-slate-100 shadow-xl shadow-slate-200/70 text-center relative overflow-hidden z-10"
      >
        {/* Top Switcher: Login / Register */}
        <div className="grid grid-cols-2 gap-1.5 p-1.5 bg-slate-100 rounded-2xl border border-slate-200/60 mb-5">
          <button
            className="py-2.5 px-3 rounded-xl bg-slate-900 text-white font-black text-xs shadow-sm transition-all flex items-center justify-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>إنشاء حساب جديد 🇧🇭</span>
          </button>
          <button
            onClick={onGoToLogin}
            className="py-2.5 px-3 rounded-xl bg-transparent text-slate-600 hover:text-slate-900 font-extrabold text-xs transition-all flex items-center justify-center gap-1.5"
          >
            <Lock className="w-3.5 h-3.5 text-amber-500" />
            <span>تسجيل الدخول</span>
          </button>
        </div>

        {/* Step Progress Indicator Bar */}
        <div className="mb-5">
          <div className="flex items-center justify-between text-[11px] font-black text-amber-700 mb-2 px-1">
            <span>القسم {currentStep} من 5</span>
            <span>{stepTitles[currentStep - 1]}</span>
          </div>
          <div className="flex gap-1.5 h-1.5 bg-slate-100 rounded-full p-0.5 border border-slate-200/60 overflow-hidden">
            {[1, 2, 3, 4, 5].map((s) => (
              <div
                key={s}
                className={`flex-1 rounded-full transition-all duration-300 ${
                  s <= currentStep ? 'bg-amber-500 shadow-sm' : 'bg-slate-200'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Error / Alert Messages */}
        {errorMessage && (
          <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2 text-right">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2 text-right">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* STEP 1: Name & Birth Date */}
        {currentStep === 1 && (
          <form onSubmit={handleStep1} className="space-y-4 text-right">
            <div className="flex flex-col items-center mb-2">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mb-2">
                <User className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-black text-slate-900">القسم الأول: البيانات الشخصية</h3>
              <p className="text-xs text-slate-500">أدخل اسمك الثلاثي وتاريخ ميلادك كما يظهر في بطاقتك</p>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-700 mb-1 block">الاسم الكامل الثلاثي</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full h-11 pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-amber-500 transition-colors"
                  placeholder="مثال: علي محمد آل خليفة"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-700 mb-1 block">تاريخ الميلاد</label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="date"
                  required
                  value={birthDate}
                  onChange={(e) => setBirthDate(e.target.value)}
                  className="w-full h-11 pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-amber-500 transition-colors font-medium text-right"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-slate-900 text-white font-extrabold text-xs shadow-md hover:bg-slate-800 active:scale-[0.98] transition-all flex items-center justify-center gap-2 mt-4"
            >
              <span>الانتقال إلى إضافة البريد الإلكتروني</span>
              <ArrowRight className="w-4 h-4 rtl:rotate-180 text-amber-400" />
            </button>
          </form>
        )}

        {/* STEP 2: Email / Phone Address Input */}
        {currentStep === 2 && (
          <form onSubmit={handleSendOtp} className="space-y-4 text-right">
            <div className="flex flex-col items-center mb-2">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mb-2">
                <Mail className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-black text-slate-900">القسم الثاني: تفعيل وسائل التواصل</h3>
              <p className="text-xs text-slate-500">اختر طريقة تلقي رمز التفعيل (البريد الإلكتروني أو رقم الهاتف)</p>
            </div>

            {/* Toggle Contact Method */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl border border-slate-200 mb-3">
              <button
                type="button"
                onClick={() => setContactMethod('email')}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
                  contactMethod === 'email'
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                📧 البريد الإلكتروني
              </button>
              <button
                type="button"
                onClick={() => setContactMethod('phone')}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
                  contactMethod === 'phone'
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                📱 رقم الهاتف 🇧🇭
              </button>
            </div>

            {contactMethod === 'email' ? (
              <div>
                <label className="text-[11px] font-bold text-slate-700 mb-1 block">البريد الإلكتروني الأساسي للتطبيق</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full h-11 pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-amber-500 transition-colors"
                    placeholder="name@domain.bh"
                  />
                </div>
              </div>
            ) : (
              <div>
                <label className="text-[11px] font-bold text-slate-700 mb-1 block">رقم الهاتف البحريني 🇧🇭</label>
                <div className="relative flex items-center">
                  <span className="absolute left-3 text-xs font-black text-amber-600 border-r border-slate-200 pr-2 pl-1 dir-ltr">
                    +973
                  </span>
                  <input
                    type="tel"
                    required
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                    className="w-full h-11 pl-14 pr-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-amber-500 transition-colors font-bold text-left"
                    placeholder="39XXXXXX"
                  />
                </div>
              </div>
            )}

            <div id="recaptcha-container-register" className="flex justify-center my-1"></div>

            <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 text-[11px] text-amber-800 leading-relaxed font-semibold">
              💡 ملحوظة: سيصلك رمز التحقق الخاص بحسابك مباشرة وتأكيد ملكيتك.
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCurrentStep(1)}
                className="py-3 px-4 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs hover:bg-slate-200"
              >
                السابق
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 py-3.5 rounded-xl bg-slate-900 text-white font-extrabold text-xs shadow-md hover:bg-slate-800 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                <span>{isLoading ? 'جاري إرسال الكود...' : 'إرسال كود التحقق ✉️'}</span>
                <ArrowRight className="w-4 h-4 rtl:rotate-180 text-amber-400" />
              </button>
            </div>
          </form>
        )}

        {/* STEP 3: OTP Code Verification */}
        {currentStep === 3 && (
          <form onSubmit={handleVerifyOtp} className="space-y-4 text-right">
            <div className="flex flex-col items-center mb-2">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mb-2">
                <KeyRound className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-black text-slate-900">القسم الثالث: أدخل رمز التحقق</h3>
              <p className="text-xs text-slate-500">
                أدخل الرمز المكون من 4 أرقام الموجه إلى ({contactMethod === 'email' ? email : `+973 ${phoneNumber}`})
              </p>
            </div>

            {contactMethod === 'email' && (
              <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl text-center space-y-1">
                <p className="text-xs font-black text-amber-900">📬 تم إرسال رسالة التحقق إلى بريدك الإلكتروني بنجاح!</p>
                <p className="text-[11px] font-bold text-amber-700">يرجى تفقد صندوق الوارد ومجلد الرسائل غير المرغوب فيها (Spam).</p>
              </div>
            )}

            <div>
              <label className="text-[11px] font-bold text-slate-700 mb-2 block text-center">أدخل رمز التحقق (OTP)</label>
              <div className="flex items-center justify-center gap-2 dir-ltr">
                <input
                  type="text"
                  maxLength={4}
                  required
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                  className="w-44 py-3 rounded-2xl bg-amber-50/60 border-2 border-amber-400 text-center text-xl font-black tracking-[0.4em] text-slate-900 focus:outline-none focus:ring-4 focus:ring-amber-500/20"
                  placeholder="••••"
                  autoFocus
                />
              </div>
            </div>

            <button
              type="button"
              disabled={resendCooldown > 0 || isLoading}
              onClick={handleSendOtp}
              className="text-[11px] font-bold text-amber-600 hover:underline block text-center w-full disabled:opacity-50 disabled:no-underline"
            >
              {resendCooldown > 0
                ? `يمكنك إعادة إرسال الرسالة بعد (${resendCooldown}) ثانية ⏳`
                : 'لم يصلك الكود؟ إعادة إرسال الكود الآن 🔄'}
            </button>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCurrentStep(2)}
                className="py-3 px-4 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs hover:bg-slate-200"
              >
                السابق
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 py-3.5 rounded-xl bg-amber-500 text-slate-950 font-black text-xs shadow-md hover:bg-amber-400 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                <span>{isLoading ? 'جاري التأكيد...' : 'تأكيد الرمز والمتابعة 🟢'}</span>
                <ArrowRight className="w-4 h-4 rtl:rotate-180" />
              </button>
            </div>
          </form>
        )}

        {/* STEP 4: Choose Username */}
        {currentStep === 4 && (
          <form onSubmit={handleStep4Username} className="space-y-4 text-right">
            <div className="flex flex-col items-center mb-2">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mb-2">
                <AtSign className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-black text-slate-900">القسم الرابع: اسم المستخدم</h3>
              <p className="text-xs text-slate-500">اختر المعرف الفريد الخاص بك على منصة BODY BH (@username)</p>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-700 mb-1 block">اسم المستخدم (@)</label>
              <div className="relative flex items-center">
                <span className="absolute left-3 text-xs font-black text-amber-600 border-r border-slate-200 pr-2 pl-1 dir-ltr">
                  @
                </span>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9._]/g, ''))}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-amber-500 transition-colors font-bold text-left"
                  placeholder="ali.bahrain"
                />
              </div>
            </div>

            {/* Suggested usernames */}
            <div>
              <span className="text-[10px] font-bold text-slate-500 block mb-1.5">اقتراحات أسماء مستخدم متوفرة:</span>
              <div className="flex flex-wrap gap-1.5">
                {['ali_bh', 'fit_bastaki', 'athlete.bahrain', 'bodybh_pro'].map((sugg) => (
                  <button
                    key={sugg}
                    type="button"
                    onClick={() => setUsername(sugg)}
                    className="px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200 text-[11px] font-bold text-amber-700 hover:border-amber-400"
                  >
                    @{sugg}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCurrentStep(3)}
                className="py-3 px-4 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs hover:bg-slate-200"
              >
                السابق
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 py-3.5 rounded-xl bg-slate-900 text-white font-extrabold text-xs shadow-md hover:bg-slate-800 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                <span>متابعة لإنشاء كلمة السر</span>
                <ArrowRight className="w-4 h-4 rtl:rotate-180 text-amber-400" />
              </button>
            </div>
          </form>
        )}

        {/* STEP 5: Create Password & Complete Registration */}
        {currentStep === 5 && (
          <form onSubmit={handleFinalRegister} className="space-y-4 text-right">
            <div className="flex flex-col items-center mb-2">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mb-2">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-black text-slate-900">القسم الخامس: كلمة السر وتأكيد الحساب</h3>
              <p className="text-xs text-slate-500">أنشئ كلمة سر قوية لحماية حسابك واستكمال التسجيل</p>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-700 mb-1 block">كلمة السر</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-amber-500 transition-colors"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-700 mb-1 block">تأكيد كلمة السر</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-amber-500 transition-colors"
                  placeholder="••••••••"
                />
              </div>
            </div>

            {/* Terms Checkbox */}
            <div className="flex items-center justify-end gap-2 pt-1">
              <label htmlFor="terms" className="text-[11px] text-slate-700 font-bold cursor-pointer select-none">
                أوافق على شروط وأحكام منصة BODY BH وسياسة الخصوصية 🇧🇭
              </label>
              <input
                id="terms"
                type="checkbox"
                checked={acceptedTerms}
                onChange={(e) => setAcceptedTerms(e.target.checked)}
                className="w-4 h-4 rounded border-slate-300 text-amber-500 focus:ring-0 cursor-pointer accent-amber-500"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCurrentStep(4)}
                className="py-3 px-4 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs hover:bg-slate-200"
              >
                السابق
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 py-3.5 rounded-xl bg-slate-900 text-white font-extrabold text-xs tracking-wide shadow-md hover:bg-slate-800 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                <span>{isLoading ? 'جاري إنشاء الحساب...' : 'إنشاء الحساب ودخول التطبيق 🚀'}</span>
                <CheckCircle2 className="w-4 h-4 text-amber-400" />
              </button>
            </div>
          </form>
        )}

        {/* Guest Access Option */}
        <div className="pt-4 border-t border-slate-100 mt-5 text-center">
          <button
            type="button"
            onClick={() => onRegisterSuccess({ name: 'زائر منصة BODY BH', username: 'guest.bh' })}
            className="w-full py-3 rounded-2xl bg-white border border-slate-200 text-slate-700 font-extrabold text-xs transition-all flex items-center justify-center gap-2 hover:bg-slate-50 group"
          >
            <User className="w-4 h-4 text-amber-500 group-hover:scale-110 transition-transform" />
            <span>الدخول كزائر (تصفح السريع) 👤</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
};
