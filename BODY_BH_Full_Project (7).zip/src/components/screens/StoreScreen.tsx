import React, { useState } from 'react';
import { 
  ArrowLeft, 
  ShoppingBag, 
  Search, 
  Star, 
  Plus, 
  Minus, 
  Trash2, 
  CheckCircle2, 
  Sparkles, 
  Tag, 
  Truck, 
  ShieldCheck, 
  X,
  Crown,
  Dumbbell
} from 'lucide-react';
import { StoreProduct, CartItem, ScreenType } from '../../types';
import { MOCK_PRODUCTS } from '../../data/mockData';

interface StoreScreenProps {
  onBack: () => void;
  onNavigate: (screen: ScreenType) => void;
}

export const StoreScreen: React.FC<StoreScreenProps> = ({ onBack, onNavigate }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<StoreProduct | null>(null);
  const [promoCode, setPromoCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState(0);
  const [checkoutSuccess, setCheckoutSuccess] = useState(false);

  const categories = [
    { id: 'all', label: 'الكل' },
    { id: 'supplements', label: 'المكملات 💊' },
    { id: 'apparel', label: 'الملابس 👕' },
    { id: 'equipment', label: 'المعدات 🏋️' },
    { id: 'free_perks', label: 'مميزات مجانية 🇧🇭' },
  ];

  const filteredProducts = MOCK_PRODUCTS.filter((p) => {
    const matchesCategory = activeCategory === 'all' || p.category === activeCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const addToCart = (product: StoreProduct) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discountAmount = (subtotal * appliedDiscount) / 100;
  const deliveryFee = subtotal > 0 ? 1.5 : 0; // 1.5 BHD delivery fee in Bahrain
  const finalTotal = Math.max(0, subtotal - discountAmount + deliveryFee);
  const totalItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleApplyPromo = () => {
    if (promoCode.trim().toUpperCase() === 'BODYBH10' || promoCode.trim().toUpperCase() === 'BAHRAIN') {
      setAppliedDiscount(10);
    } else {
      alert('كود الخصم غير صحيح. جرب كود BODYBH10 للحصول على خصم 10%');
    }
  };

  const handleCheckout = () => {
    if (cart.length === 0) return;
    setCheckoutSuccess(true);
    setTimeout(() => {
      setCheckoutSuccess(false);
      setCart([]);
      setIsCartOpen(false);
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 pb-28 pt-3 max-w-md mx-auto relative selection:bg-amber-400 selection:text-slate-900">
      {/* Top Header */}
      <header className="sticky top-0 z-30 px-4 py-3 bg-white/95 backdrop-blur-2xl border-b border-slate-200 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-full bg-slate-100 border border-slate-200 text-slate-700 hover:text-slate-900 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-base font-black text-slate-900 tracking-tight flex items-center gap-1.5">
              <span>متجر BODY BH 🇧🇭</span>
            </h1>
            <p className="text-[10px] text-amber-700 font-bold">توصيل سريع داخل مملكة البحرين</p>
          </div>
        </div>

        <button
          onClick={() => setIsCartOpen(true)}
          className="relative p-2.5 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-300 text-slate-900 font-black shadow-xs hover:scale-105 transition-transform"
        >
          <ShoppingBag className="w-5 h-5 stroke-[2.5]" />
          {totalItemsCount > 0 && (
            <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-rose-600 border-2 border-white text-white text-[10px] font-black flex items-center justify-center animate-bounce">
              {totalItemsCount}
            </span>
          )}
        </button>
      </header>

      {/* Hero Banner */}
      <div className="px-4 pt-4">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 p-5 text-slate-900 shadow-md border border-amber-300">
          <div className="relative z-10 max-w-[70%]">
            <span className="inline-block px-2.5 py-1 rounded-full bg-slate-900 text-amber-300 text-[10px] font-black mb-2 uppercase tracking-wider">
              عروض حصرية 🇧🇭
            </span>
            <h2 className="text-lg font-black leading-tight mb-1 text-slate-900">
              أفضل المكملات والمعدات الرياضية
            </h2>
            <p className="text-[11px] font-bold text-slate-950 mb-3 leading-snug">
              خصومات تصل إلى 25% مع توصيل مباشر لباب منزلك في البحرين.
            </p>
            <button
              onClick={() => setActiveCategory('supplements')}
              className="px-4 py-2 rounded-xl bg-slate-900 text-amber-300 text-xs font-black shadow-sm hover:bg-slate-800 transition-colors"
            >
              تسوق المكملات الآن
            </button>
          </div>
          <Dumbbell className="absolute -bottom-4 -left-4 w-36 h-36 text-slate-900/15 stroke-[1.5] pointer-events-none" />
        </div>
      </div>

      {/* Search Input */}
      <div className="px-4 pt-4">
        <div className="relative">
          <Search className="absolute right-3.5 top-3 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث عن مكمل، ملابس، حزام رفع أوزان..."
            className="w-full pr-10 pl-4 py-2.5 rounded-2xl bg-slate-100 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-400 shadow-xs"
          />
        </div>
      </div>

      {/* Categories Horizontal Scroll */}
      <div className="px-4 py-4 flex items-center gap-2 overflow-x-auto scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-4 py-2 rounded-2xl text-xs font-black whitespace-nowrap transition-all border ${
              activeCategory === cat.id
                ? 'bg-gradient-to-r from-amber-400 to-amber-300 text-slate-900 border-amber-400 shadow-xs scale-105'
                : 'bg-slate-100 text-slate-700 border-slate-200 hover:border-amber-300'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Products Grid */}
      <div className="px-4 grid grid-cols-2 gap-3.5">
        {filteredProducts.map((product) => (
          <div
            key={product.id}
            className="rounded-3xl bg-slate-50 border border-slate-200 overflow-hidden flex flex-col justify-between hover:border-amber-400/60 transition-all shadow-xs group"
          >
            <div>
              {/* Image & Badges */}
              <div 
                onClick={() => setSelectedProduct(product)}
                className="relative h-36 bg-slate-100 overflow-hidden cursor-pointer"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 via-transparent to-transparent" />

                {product.isPopular && (
                  <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-full bg-amber-400 text-slate-900 text-[9px] font-black shadow-xs">
                    الأكثر مبيعاً 🔥
                  </span>
                )}
                {product.isNew && (
                  <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-full bg-cyan-500 text-white text-[9px] font-black shadow-xs">
                    جديد ⚡
                  </span>
                )}

                <div className="absolute bottom-2 right-2 flex items-center gap-1 px-2 py-0.5 rounded-lg bg-white/90 backdrop-blur-md border border-slate-200 text-[10px] font-bold text-slate-900 shadow-xs">
                  <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                  <span>{product.rating}</span>
                </div>
              </div>

              {/* Product Info */}
              <div className="p-3">
                <span className="text-[9px] font-bold text-amber-700 uppercase tracking-wider block mb-1">
                  {product.categoryLabel}
                </span>
                <h3 
                  onClick={() => setSelectedProduct(product)}
                  className="text-xs font-black text-slate-900 leading-snug line-clamp-2 cursor-pointer hover:text-amber-600 transition-colors"
                >
                  {product.name}
                </h3>
              </div>
            </div>

            {/* Price & Add to Cart */}
            <div className="p-3 pt-0 flex items-center justify-between border-t border-slate-200/80 mt-2">
              <div>
                <div className="flex items-baseline gap-1">
                  <span className="text-sm font-black text-slate-900">{product.price.toFixed(2)}</span>
                  <span className="text-[10px] font-bold text-slate-500">د.ب</span>
                </div>
                {product.originalPrice && (
                  <span className="text-[9px] text-slate-400 line-through">
                    {product.originalPrice.toFixed(2)} د.ب
                  </span>
                )}
              </div>

              <button
                onClick={() => addToCart(product)}
                className="p-2.5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-300 text-slate-900 font-black hover:scale-105 transition-all shadow-xs active:scale-95"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Empty Search State */}
      {filteredProducts.length === 0 && (
        <div className="py-16 text-center px-6">
          <div className="w-16 h-16 rounded-3xl bg-slate-100 border border-amber-300 flex items-center justify-center text-amber-600 mx-auto mb-4">
            <Search className="w-8 h-8" />
          </div>
          <h3 className="text-base font-black text-slate-900 mb-1">لم يتم العثور على منتجات</h3>
          <p className="text-xs text-slate-500 max-w-xs mx-auto">
            جرب البحث عن منتجات أخرى أو اختر فئة مختلفة من القائمة أعلاه.
          </p>
        </div>
      )}

      {/* Product Detail Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-t-3xl sm:rounded-3xl overflow-hidden p-5 animate-in fade-in slide-in-from-bottom duration-200 shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <span className="px-2.5 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-[10px] font-bold">
                {selectedProduct.categoryLabel}
              </span>
              <button
                onClick={() => setSelectedProduct(null)}
                className="p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="h-48 rounded-2xl bg-slate-100 overflow-hidden mb-4 relative">
              <img
                src={selectedProduct.image}
                alt={selectedProduct.name}
                className="w-full h-full object-cover"
              />
            </div>

            <h2 className="text-base font-black text-slate-900 mb-2">{selectedProduct.name}</h2>
            <p className="text-xs text-slate-600 leading-relaxed mb-4">{selectedProduct.description}</p>

            <div className="flex items-center justify-between pt-3 border-t border-slate-200">
              <div>
                <span className="text-[10px] text-slate-500 font-bold block">السعر الكلي</span>
                <div className="flex items-baseline gap-1">
                  <span className="text-xl font-black text-slate-900">{selectedProduct.price.toFixed(2)}</span>
                  <span className="text-xs font-bold text-slate-600">د.ب</span>
                </div>
              </div>

              <button
                onClick={() => {
                  addToCart(selectedProduct);
                  setSelectedProduct(null);
                  setIsCartOpen(true);
                }}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-300 text-slate-900 font-black text-xs shadow-md flex items-center gap-2 hover:scale-105 transition-all"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>إضافة إلى السلة</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Shopping Cart Drawer */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-md flex items-end justify-center">
          <div className="w-full max-w-md bg-white border-t border-slate-200 rounded-t-3xl max-h-[85vh] flex flex-col p-5 shadow-2xl animate-in slide-in-from-bottom duration-300 relative text-right">
            
            {/* Drawer Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-amber-600" />
                <h2 className="text-base font-black text-slate-900">سلة التسوق ({totalItemsCount})</h2>
              </div>
              <button
                onClick={() => setIsCartOpen(false)}
                className="p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Cart Items List */}
            <div className="flex-1 overflow-y-auto py-4 space-y-3">
              {cart.length === 0 ? (
                <div className="py-12 text-center text-slate-500">
                  <ShoppingBag className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                  <p className="text-xs font-bold">سلة التسوق فارغة حالياً</p>
                  <p className="text-[11px] text-slate-400 mt-1">تصفح المنتجات وأضف ما يعجبك إلى السلة</p>
                </div>
              ) : (
                cart.map(({ product, quantity }) => (
                  <div
                    key={product.id}
                    className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3"
                  >
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-14 h-14 rounded-xl object-cover shrink-0 border border-slate-200"
                    />

                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-black text-slate-900 truncate">{product.name}</h4>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span className="text-xs font-extrabold text-slate-900">
                          {(product.price * quantity).toFixed(2)}
                        </span>
                        <span className="text-[10px] text-slate-500 font-bold">د.ب</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 bg-white px-2 py-1 rounded-xl border border-slate-200">
                      <button
                        onClick={() => updateQuantity(product.id, -1)}
                        className="p-1 text-slate-500 hover:text-slate-900"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="text-xs font-black text-slate-900 px-1">{quantity}</span>
                      <button
                        onClick={() => updateQuantity(product.id, 1)}
                        className="p-1 text-slate-500 hover:text-slate-900"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Summary & Checkout */}
            {cart.length > 0 && (
              <div className="pt-4 border-t border-slate-200 space-y-3">
                {/* Promo Code Input */}
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    placeholder="كود الخصم (مثل BODYBH10)"
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 uppercase focus:outline-none focus:border-amber-400"
                  />
                  <button
                    onClick={handleApplyPromo}
                    className="px-4 py-2 rounded-xl bg-slate-100 text-slate-900 font-bold text-xs hover:bg-slate-200 border border-slate-200"
                  >
                    تطبيق
                  </button>
                </div>

                {appliedDiscount > 0 && (
                  <div className="flex justify-between text-xs text-emerald-600 font-bold px-1">
                    <span>خصم الكود (10%)</span>
                    <span>-{discountAmount.toFixed(2)} د.ب</span>
                  </div>
                )}

                <div className="flex justify-between text-xs text-slate-500 px-1">
                  <span>رسوم التوصيل في البحرين</span>
                  <span>{deliveryFee.toFixed(2)} د.ب</span>
                </div>

                <div className="flex justify-between text-sm font-black text-slate-900 px-1 pt-2 border-t border-slate-200">
                  <span>المجموع النهائي</span>
                  <span className="text-amber-700 text-base">{finalTotal.toFixed(2)} د.ب</span>
                </div>

                <button
                  onClick={handleCheckout}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-300 to-amber-200 text-slate-900 font-black text-sm shadow-md hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-5 h-5" />
                  <span>تأكيد الطلب والدفع</span>
                </button>
              </div>
            )}

            {/* Success Overlay */}
            {checkoutSuccess && (
              <div className="absolute inset-0 z-20 bg-white/95 backdrop-blur-xl rounded-t-3xl flex flex-col items-center justify-center p-6 text-center animate-in fade-in duration-300">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 border border-emerald-300 flex items-center justify-center mb-4 shadow-sm animate-bounce">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="text-lg font-black text-slate-900 mb-2">تم استلام طلبك بنجاح! 🇧🇭</h3>
                <p className="text-xs text-slate-600 max-w-xs leading-relaxed">
                  شكراً لطلبك من متجر BODY BH. سيتم إرسال تفاصيل التوصيل إلى رقمك المعتمد في البحرين.
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
