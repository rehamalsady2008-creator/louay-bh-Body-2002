import React, { useState } from 'react';
import { Compass, Flame, Radio, Heart, Play, Sparkles, MapPin, Eye } from 'lucide-react';
import { ScreenType } from '../../types';

interface ExploreScreenProps {
  onNavigate: (screen: ScreenType) => void;
  onOpenLiveStream: () => void;
}

export const ExploreScreen: React.FC<ExploreScreenProps> = ({
  onNavigate,
  onOpenLiveStream,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = ['All', 'Bahrain Bay', 'Fine Dining', 'Cafes', 'Nightlife', 'Events', 'VIP'];

  const exploreCards: {
    id: string;
    title: string;
    image: string;
    likes: string;
    type: string;
    creator: string;
    category: string;
    aspectRatio: string;
  }[] = [];

  const filteredCards = activeCategory === 'All'
    ? exploreCards
    : exploreCards.filter(c => c.category === activeCategory);

  return (
    <div className="min-h-screen bg-white text-slate-900 p-4 pt-12 pb-28 max-w-md mx-auto selection:bg-amber-400 selection:text-slate-900">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-300 text-slate-900 shadow-xs">
            <Compass className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tight text-slate-900">Explore Bahrain</h1>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider -mt-0.5">
              Curated Luxury Lifestyle 🇧🇭
            </p>
          </div>
        </div>
        <span className="px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-[10px] font-black text-amber-800 shadow-xs">
          Bahrain Grid
        </span>
      </div>

      {/* Category Pills Bar */}
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-none pb-3 mb-4">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all ${
              activeCategory === cat
                ? 'bg-amber-400 text-slate-900 font-black shadow-xs scale-105'
                : 'bg-slate-100 border border-slate-200 text-slate-600 hover:text-slate-900'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Featured Spotlight Banner */}
      <div
        onClick={() => onNavigate('reels')}
        className="relative w-full h-40 rounded-3xl overflow-hidden mb-6 border border-amber-300 p-4 flex flex-col justify-between cursor-pointer group shadow-sm"
      >
        <img
          src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&q=80&w=800"
          alt="Featured"
          className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent" />

        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400 text-slate-900 font-black text-[10px] shadow-xs">
            <Sparkles className="w-3 h-3 fill-slate-900" />
            <span>محتوى مميز في البحرين 🇧🇭</span>
          </div>
          <span className="text-[10px] text-white font-bold bg-slate-900/80 px-2.5 py-1 rounded-full backdrop-blur-md border border-slate-700 flex items-center gap-1">
            <Eye className="w-3 h-3 text-amber-400" />
            <span>14.2k مشاهدة</span>
          </span>
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-1 text-[10px] text-amber-300 font-bold mb-0.5">
            <MapPin className="w-3 h-3" />
            <span>خليج البحرين • Bahrain Bay</span>
          </div>
          <h3 className="text-sm font-black text-white leading-tight">
            تمارين اللياقة والمرونة عند الغروب
          </h3>
          <p className="text-[10px] text-slate-300 font-medium">Elena Rostova • @elena.aesthetics</p>
        </div>
      </div>

      {/* Bento Grid */}
      {filteredCards.length === 0 ? (
        <div className="py-16 text-center flex flex-col items-center justify-center border border-slate-200 rounded-3xl bg-slate-50 my-4">
          <div className="w-14 h-14 rounded-full bg-white border border-amber-300 flex items-center justify-center text-amber-600 mb-3 shadow-xs">
            <Compass className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-black text-slate-900 mb-1">لا يوجد محتوى في هذه الفئة</h3>
          <p className="text-[11px] text-slate-500 max-w-[220px] font-medium">
            تصفح فئات أخرى أو أضف منشورات جديدة في مجتمع البحرين 🇧🇭
          </p>
        </div>
      ) : (
        <div className="columns-2 gap-3 space-y-3">
          {filteredCards.map((card) => (
            <div
              key={card.id}
              onClick={() => onNavigate(card.type === 'reel' ? 'reels' : 'home')}
              className={`relative rounded-3xl overflow-hidden bg-slate-100 border border-slate-200 group cursor-pointer break-inside-avoid shadow-xs hover:border-amber-400 transition-all ${card.aspectRatio}`}
            >
              <img
                src={card.image}
                alt={card.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent" />

              {/* Type badge */}
              <div className="absolute top-3 right-3 p-2 rounded-full bg-slate-900/70 backdrop-blur-md border border-slate-700 text-white shadow-xs">
                {card.type === 'reel' ? (
                  <Play className="w-3 h-3 fill-white" />
                ) : (
                  <Sparkles className="w-3 h-3 text-amber-400" />
                )}
              </div>

              <div className="absolute bottom-3 left-3 right-3">
                <span className="text-[10px] font-black text-amber-300 block mb-0.5">{card.creator}</span>
                <h4 className="text-[11px] font-bold text-white leading-snug line-clamp-2 drop-shadow-xs">
                  {card.title}
                </h4>
                <div className="flex items-center gap-1 mt-1.5 text-[10px] text-slate-300 font-semibold">
                  <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
                  <span>{card.likes}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
