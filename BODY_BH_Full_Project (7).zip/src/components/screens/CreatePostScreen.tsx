import React, { useState, useRef } from 'react';
import { 
  ArrowLeft, 
  Sparkles, 
  MapPin, 
  Tag, 
  Image as ImageIcon, 
  Wand2, 
  Check, 
  Send, 
  Camera, 
  Sliders, 
  Upload, 
  Play, 
  Video, 
  Type, 
  Sparkles as SparkleIcon,
  Film
} from 'lucide-react';
import { ScreenType } from '../../types';

interface CreatePostScreenProps {
  onBack: () => void;
  onPostSuccess: (postData: { mediaUrl: string; mediaType?: 'image' | 'video'; title?: string; caption: string; location: string }) => void;
}

export const CreatePostScreen: React.FC<CreatePostScreenProps> = ({
  onBack,
  onPostSuccess,
}) => {
  const [mediaUrl, setMediaUrl] = useState('');
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [mediaTitle, setMediaTitle] = useState('');
  const [caption, setCaption] = useState('');
  const [location, setLocation] = useState('المنامة، مملكة البحرين 🇧🇭');
  const [selectedFilter, setSelectedFilter] = useState('طبيعي Normal');
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  // Hidden File Inputs
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const filterOptions = [
    { id: 'Normal', name: 'طبيعي Normal', class: '' },
    { id: 'Vivid', name: 'ذهبي Gold', class: 'saturate-150 contrast-110 brightness-105' },
    { id: 'Warm', name: 'دافئ Warm', class: 'sepia-30 hue-rotate-15 saturate-150' },
    { id: 'Cinema', name: 'سينمائي Vintage', class: 'contrast-125 brightness-90 hue-rotate-340' },
    { id: 'Dramatic', name: 'دراما Dramatic', class: 'contrast-150 brightness-95 saturate-125' },
    { id: 'Noir', name: 'أسود وأبيض Noir', class: 'grayscale contrast-125' },
  ];

  // Handle local device file select
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileUrl = URL.createObjectURL(file);
    const isVideoFile = file.type.startsWith('video');
    setMediaType(isVideoFile ? 'video' : 'image');
    setMediaUrl(fileUrl);
    if (!mediaTitle) {
      setMediaTitle(file.name.split('.')[0] || (isVideoFile ? 'فيديو جديد' : 'صورة جديدة'));
    }
  };

  const currentFilterClass = filterOptions.find((f) => f.name === selectedFilter)?.class || '';

  const generateAiCaption = async () => {
    setIsGeneratingAi(true);
    try {
      const res = await fetch('/api/ai/caption', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: mediaTitle || 'تمرين رياضي لياقة بدنية محتوى احترافي البحرين',
          tone: 'high luxury fitness influencer',
        }),
      });
      const data = await res.json();
      if (data.caption) {
        const fullCaption = `${data.caption}\n\n${(data.hashtags || []).join(' ')}`;
        setCaption(fullCaption);
      } else {
        throw new Error('Fallback required');
      }
    } catch (err) {
      setCaption(
        'جلسة تمرين رياضية حماسية ومميزة على منصة BODY BH! استمر في الانضباط وطور أداءك الرياضي يومياً. 🏋️‍♂️🔥\n\n#BODYBH #BahrainFitness #كمال_أجسام #البحرين #لياقة'
      );
    } finally {
      setIsGeneratingAi(false);
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 p-4 pt-12 pb-28 max-w-md mx-auto selection:bg-amber-400 selection:text-slate-900" style={{ direction: 'rtl' }}>
      {/* Hidden inputs for camera & gallery */}
      <input
        type="file"
        ref={galleryInputRef}
        accept="image/*,video/*"
        onChange={handleFileChange}
        className="hidden"
      />
      <input
        type="file"
        ref={cameraInputRef}
        accept="image/*,video/*"
        capture="environment"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Top Navigation Bar */}
      <div className="flex items-center justify-between mb-5">
        <button 
          onClick={onBack} 
          className="p-2.5 rounded-2xl bg-slate-100 border border-slate-200 text-slate-700 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="text-center">
          <h1 className="text-sm font-black text-slate-900 tracking-tight">نشر محتوى جديد على BODY BH</h1>
          <p className="text-[10px] text-amber-600 font-bold">صور وفيديوهات حقيقية من الجوال 🇧🇭</p>
        </div>
        <button
          onClick={() => onPostSuccess({ mediaUrl, mediaType, title: mediaTitle, caption, location })}
          className="px-5 py-2 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-300 text-slate-900 font-extrabold text-xs shadow-sm hover:brightness-105 active:scale-95 transition-all"
        >
          نشر الآن ✨
        </button>
      </div>

      {/* Media Type & Choice Buttons Row */}
      <div className="grid grid-cols-2 gap-2.5 mb-4">
        <button
          onClick={() => cameraInputRef.current?.click()}
          className="py-3 px-3 rounded-2xl bg-slate-50 border border-amber-300 hover:border-amber-400 text-slate-900 font-extrabold text-xs flex items-center justify-center gap-2 shadow-xs transition-all active:scale-95 group"
        >
          <Camera className="w-4 h-4 text-amber-600 group-hover:scale-110 transition-transform" />
          <span>تصوير بالكاميرا المباشرة 📸</span>
        </button>

        <button
          onClick={() => galleryInputRef.current?.click()}
          className="py-3 px-3 rounded-2xl bg-slate-50 border border-slate-200 hover:border-amber-400 text-slate-900 font-extrabold text-xs flex items-center justify-center gap-2 shadow-xs transition-all active:scale-95 group"
        >
          <Upload className="w-4 h-4 text-amber-600 group-hover:scale-110 transition-transform" />
          <span>اختيار من استوديو الجوال 🖼️</span>
        </button>
      </div>

      {/* Media Title Field (اسم/عنوان الصورة أو الفيديو) */}
      <div className="mb-4 bg-slate-50 border border-slate-200 rounded-2xl p-3 shadow-xs space-y-1">
        <label className="text-[11px] font-black text-amber-800 flex items-center gap-1.5">
          <Type className="w-3.5 h-3.5 text-amber-600" />
          <span>اسم أو عنوان الصورة / الفيديو</span>
        </label>
        <input
          type="text"
          value={mediaTitle}
          onChange={(e) => setMediaTitle(e.target.value)}
          placeholder="مثال: تمرين الأسكوات صباحاً، أو بطولة كمال الأجسام 🏆"
          className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-400 font-bold"
        />
      </div>

      {/* Media Upload & Preview Section */}
      {!mediaUrl ? (
        <div
          onClick={() => galleryInputRef.current?.click()}
          className="relative w-full aspect-square rounded-3xl border-2 border-dashed border-amber-300 hover:border-amber-500 bg-amber-50/30 hover:bg-amber-50/70 cursor-pointer flex flex-col items-center justify-center p-6 text-center transition-all mb-4 group shadow-xs"
        >
          <div className="w-16 h-16 rounded-2xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-700 mb-3 group-hover:scale-110 transition-transform shadow-xs">
            <Upload className="w-8 h-8 text-amber-600" />
          </div>
          <h3 className="text-sm font-black text-slate-900 mb-1">اضغط هنا لاختيار صورة أو فيديو من الاستديو 🖼️</h3>
          <p className="text-xs text-slate-500 font-medium max-w-xs">يمكنك رفع صورك وفيديوهاتك مباشرة من معرض الصور بالجوال بدون أي تعقيدات</p>
          <div className="mt-4 px-4 py-2 rounded-xl bg-amber-400 text-slate-900 font-black text-xs shadow-xs group-hover:bg-amber-500 transition-colors">
            تصفح ملفات الاستديو
          </div>
        </div>
      ) : (
        <div className="relative w-full aspect-square rounded-3xl overflow-hidden bg-slate-100 border border-slate-200 mb-4 shadow-sm group">
          {mediaType === 'video' ? (
            <video
              src={mediaUrl}
              controls
              autoPlay
              loop
              muted
              className={`w-full h-full object-cover transition-all duration-300 ${currentFilterClass}`}
            />
          ) : (
            <img
              src={mediaUrl}
              alt="Preview"
              className={`w-full h-full object-cover transition-all duration-300 ${currentFilterClass}`}
              referrerPolicy="no-referrer"
            />
          )}

          {/* Change or Delete Media Buttons */}
          <div className="absolute top-3 right-3 flex items-center gap-2">
            <button
              onClick={() => galleryInputRef.current?.click()}
              className="px-3 py-1.5 rounded-full bg-slate-900/80 backdrop-blur-md border border-amber-400/40 text-[10px] font-black text-amber-300 shadow-sm hover:bg-slate-900 transition-colors"
            >
              تغيير الصورة 🖼️
            </button>
            <button
              onClick={() => setMediaUrl('')}
              className="px-2.5 py-1.5 rounded-full bg-red-600/90 text-white font-black text-[10px] shadow-sm hover:bg-red-700 transition-colors"
            >
              حذف
            </button>
          </div>

          <div className="absolute top-3 left-3 px-3 py-1.5 rounded-full bg-slate-900/80 backdrop-blur-md border border-white/20 text-[10px] font-black text-white shadow-sm">
            فلتر: {selectedFilter}
          </div>
        </div>
      )}

      {/* Instagram-style Photo/Video Filters Selector */}
      {mediaUrl && (
        <div className="mb-5 bg-slate-50 border border-slate-200 rounded-2xl p-3">
          <label className="text-[11px] font-black text-amber-800 mb-2 block flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-amber-600" />
            <span>اختر الفلتر أو التأثير البصري</span>
          </label>
          <div className="overflow-x-auto scrollbar-none flex gap-2 pt-1 pb-1">
            {filterOptions.map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setSelectedFilter(f.name)}
                className={`px-3.5 py-2 rounded-xl border text-[11px] font-extrabold transition-all shrink-0 flex items-center gap-1 ${
                  selectedFilter === f.name
                    ? 'bg-gradient-to-r from-amber-400 to-amber-300 text-slate-900 border-amber-400 shadow-sm scale-105'
                    : 'bg-white text-slate-700 border-slate-200 hover:text-slate-900'
                }`}
              >
                {selectedFilter === f.name && <Check className="w-3 h-3 text-slate-900 stroke-[3]" />}
                <span>{f.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Caption & Gemini AI Generator */}
      <div className="space-y-3 bg-slate-50 border border-slate-200 rounded-3xl p-4 shadow-xs mb-4">
        <div className="flex items-center justify-between">
          <label className="text-[11px] font-black text-slate-700 uppercase tracking-wider">وصف المنشور (Caption)</label>
          <button
            type="button"
            onClick={generateAiCaption}
            disabled={isGeneratingAi}
            className="flex items-center gap-1.5 text-amber-700 text-xs font-black hover:underline"
          >
            <Wand2 className="w-3.5 h-3.5 text-amber-600 animate-spin-slow" />
            <span>{isGeneratingAi ? 'جاري التوليد...' : 'توليد بالذكاء الاصطناعي 🤖'}</span>
          </button>
        </div>

        <textarea
          rows={3}
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          placeholder="اكتب وصف المنشور أو تفاصيل التمارين الرياضية..."
          className="w-full p-3.5 rounded-2xl bg-white border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-400 shadow-xs font-medium"
        />

        {/* Location Picker */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-200 text-xs text-slate-700">
          <MapPin className="w-4 h-4 text-amber-600 shrink-0" />
          <input
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="flex-1 bg-transparent focus:outline-none text-xs text-slate-900 font-bold placeholder-slate-400"
            placeholder="أضف الموقع الجغرافي..."
          />
        </div>
      </div>
    </div>
  );
};

