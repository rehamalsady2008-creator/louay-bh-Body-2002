import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Phone, Video, Send, Mic, Image, Sparkles, Play, Pause, CheckCircle2, PhoneOff, MicOff, Volume2 } from 'lucide-react';
import { ChatThread, MessageItem } from '../../types';

interface ChatScreenProps {
  chat: ChatThread;
  onBack: () => void;
}

export const ChatScreen: React.FC<ChatScreenProps> = ({ chat, onBack }) => {
  const [messages, setMessages] = useState<MessageItem[]>(chat.messages);
  const [input, setInput] = useState('');
  const [isPlayingVoice, setIsPlayingVoice] = useState(false);
  const [voiceProgress, setVoiceProgress] = useState(35);
  const [smartReplies, setSmartReplies] = useState<string[]>([]);
  const [isLoadingAi, setIsLoadingAi] = useState(false);
  const [isCalling, setIsCalling] = useState<'audio' | 'video' | null>(null);

  const handleSend = (textToSend?: string) => {
    const text = textToSend || input;
    if (!text.trim()) return;

    const newMessage: MessageItem = {
      id: `m_${Date.now()}`,
      senderId: 'user_me',
      text,
      timestamp: 'Just now',
      status: 'delivered',
    };

    setMessages((prev) => [...prev, newMessage]);
    if (!textToSend) setInput('');
    setSmartReplies([]);
  };

  const generateAiSmartReplies = async () => {
    setIsLoadingAi(true);
    const lastMsg = messages[messages.length - 1]?.text || chat.lastMessage;
    try {
      const res = await fetch('/api/ai/smart-reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lastMessage: lastMsg, senderName: chat.participant.name }),
      });
      const data = await res.json();
      if (data.suggestions && Array.isArray(data.suggestions)) {
        setSmartReplies(data.suggestions);
      } else {
        throw new Error('Fallback required');
      }
    } catch (err) {
      setSmartReplies([
        'Sounds awesome brother! Let\'s link up in Bahrain Bay 💪',
        'Checking your latest post on BODY BH right now! 🔥',
        'Appreciate you! Have a legendary workout day in Manama 🙌',
      ]);
    } finally {
      setIsLoadingAi(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-white text-slate-900 flex flex-col justify-between max-w-md mx-auto selection:bg-amber-400 selection:text-slate-900">
      {/* Top Header */}
      <header className="px-4 pt-11 pb-3 flex items-center justify-between bg-white/95 backdrop-blur-2xl border-b border-slate-200 shadow-xs">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-full bg-slate-100 border border-slate-200 text-slate-700 hover:text-slate-900 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5">
            <div className="relative">
              <img
                src={chat.participant.avatar}
                alt={chat.participant.name}
                className="w-9.5 h-9.5 rounded-full object-cover border border-amber-400 shadow-xs"
                referrerPolicy="no-referrer"
              />
              {chat.isOnline && (
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border border-white" />
              )}
            </div>

            <div>
              <div className="flex items-center gap-1">
                <span className="text-xs font-black text-slate-900">{chat.participant.name}</span>
                {chat.participant.verified && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-500" />}
              </div>
              <span className="text-[10px] text-amber-700 font-extrabold">@{chat.participant.username}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsCalling('audio')}
            className="p-2.5 rounded-full bg-slate-100 border border-slate-200 text-slate-700 hover:text-slate-900 hover:border-amber-400 transition-colors shadow-xs"
          >
            <Phone className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsCalling('video')}
            className="p-2.5 rounded-full bg-slate-100 border border-slate-200 text-slate-700 hover:text-slate-900 hover:border-amber-400 transition-colors shadow-xs"
          >
            <Video className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-50/60">
        {messages.map((msg) => {
          const isMe = msg.senderId === 'user_me';
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[82%] p-3.5 rounded-3xl text-xs leading-relaxed shadow-xs ${
                  isMe
                    ? 'bg-gradient-to-tr from-amber-400 via-amber-400 to-amber-300 text-slate-900 font-bold rounded-br-none'
                    : 'bg-white border border-slate-200 text-slate-900 rounded-bl-none font-medium'
                }`}
              >
                {msg.isVoiceNote ? (
                  /* Voice Note Waveform Player */
                  <div className="flex items-center gap-3 pr-2 min-w-[200px]">
                    <button
                      onClick={() => setIsPlayingVoice(!isPlayingVoice)}
                      className={`p-2.5 rounded-full shadow-xs ${
                        isMe ? 'bg-slate-900 text-amber-400' : 'bg-gradient-to-tr from-amber-400 to-amber-300 text-slate-900 font-extrabold'
                      }`}
                    >
                      {isPlayingVoice ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    </button>

                    <div className="flex-1 flex flex-col gap-1">
                      <div className="flex items-center gap-1 h-5">
                        {[40, 70, 30, 90, 60, 100, 40, 80, 50, 90, 30, 70].map((h, i) => (
                          <div
                            key={i}
                            style={{ height: `${h}%` }}
                            className={`w-1 rounded-full ${
                              isMe ? 'bg-slate-900/80' : 'bg-amber-500'
                            } ${isPlayingVoice ? 'animate-pulse' : ''}`}
                          />
                        ))}
                      </div>
                      <div className="flex items-center justify-between text-[9px] font-extrabold opacity-80">
                        <span>0:18</span>
                        <span>{msg.voiceDuration || '0:42'}</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <p>{msg.text}</p>
                )}
              </div>
              <div className="flex items-center gap-1 text-[9px] text-slate-500 font-semibold mt-1 px-1">
                <span>{msg.timestamp}</span>
                {isMe && <span className="text-cyan-600 font-black">✓✓ Delivered</span>}
              </div>
            </div>
          );
        })}
      </div>

      {/* AI Smart Replies Popup Bar */}
      <div className="px-4 py-2.5 bg-white border-t border-slate-200">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-amber-800 text-[10px] font-black tracking-wide">
            <Sparkles className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
            <span>GEMINI AI SMART REPLIES</span>
          </div>

          <button
            onClick={generateAiSmartReplies}
            disabled={isLoadingAi}
            className="text-[10px] font-extrabold text-amber-700 underline hover:text-slate-900 transition-colors"
          >
            {isLoadingAi ? 'Generating...' : 'Suggest Quick Replies'}
          </button>
        </div>

        {smartReplies.length > 0 && (
          <div className="flex gap-2 overflow-x-auto scrollbar-none pb-2">
            {smartReplies.map((reply, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(reply)}
                className="px-3.5 py-1.5 rounded-full bg-amber-50 border border-amber-300 text-[10px] text-amber-900 font-bold whitespace-nowrap hover:bg-amber-400 hover:text-slate-900 transition-colors shadow-xs"
              >
                {reply}
              </button>
            ))}
          </div>
        )}

        {/* Input bar */}
        <div className="flex items-center gap-2 pt-1 pb-4">
          <button className="p-3 rounded-full bg-slate-100 border border-slate-200 text-slate-600 hover:text-slate-900 transition-colors">
            <Image className="w-4 h-4" />
          </button>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="iMessage for BODY BH..."
            className="flex-1 px-4 py-3 rounded-full bg-slate-100 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500 shadow-xs"
          />

          <button
            onClick={() => handleSend()}
            disabled={!input.trim()}
            className="p-3 rounded-full bg-gradient-to-tr from-amber-400 to-amber-300 text-slate-900 font-bold disabled:opacity-40 hover:brightness-110 transition-all shadow-xs"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Audio / Video Call Simulation Modal */}
      <AnimatePresence>
        {isCalling && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-0 z-50 bg-black/95 backdrop-blur-3xl p-6 flex flex-col justify-between items-center text-center max-w-md mx-auto"
          >
            <div className="pt-12 flex flex-col items-center">
              <div className="relative mb-4">
                <img
                  src={chat.participant.avatar}
                  alt={chat.participant.name}
                  className="w-28 h-28 rounded-full object-cover border-4 border-amber-400 shadow-2xl animate-pulse"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute -bottom-1 -right-1 bg-amber-400 text-black p-1.5 rounded-full shadow-lg">
                  {isCalling === 'audio' ? <Phone className="w-4 h-4" /> : <Video className="w-4 h-4" />}
                </span>
              </div>
              <h2 className="text-xl font-black text-white tracking-tight">{chat.participant.name}</h2>
              <p className="text-xs text-amber-300 font-extrabold mt-1">
                BODY BH {isCalling === 'audio' ? 'Encrypted Audio Call' : 'HD Video Call'}
              </p>
              <p className="text-[11px] text-neutral-400 mt-3 animate-pulse">Calling from Bahrain Bay HQ...</p>
            </div>

            <div className="w-full pb-12 flex items-center justify-center gap-6">
              <button className="p-4 rounded-full bg-neutral-800 text-white border border-white/10 hover:bg-neutral-700">
                <MicOff className="w-6 h-6" />
              </button>
              <button
                onClick={() => setIsCalling(null)}
                className="p-5 rounded-full bg-rose-600 text-white shadow-2xl shadow-rose-600/50 hover:bg-rose-700 active:scale-95 transition-all"
              >
                <PhoneOff className="w-7 h-7" />
              </button>
              <button className="p-4 rounded-full bg-neutral-800 text-white border border-white/10 hover:bg-neutral-700">
                <Volume2 className="w-6 h-6" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
