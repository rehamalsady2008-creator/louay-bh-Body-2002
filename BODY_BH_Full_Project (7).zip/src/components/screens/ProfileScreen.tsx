import React, { useState } from 'react';
import {
  Grid,
  Film,
  Repeat,
  UserCheck,
  Plus,
  TrendingUp,
  Menu,
  AtSign,
  UserPlus,
  Camera,
  Sparkles
} from 'lucide-react';
import { ScreenType, UserProfile, PostItem } from '../../types';
import { CURRENT_USER } from '../../data/mockData';
import { useLanguage } from '../../context/LanguageContext';

interface ProfileScreenProps {
  userProfile?: UserProfile;
  userPosts?: PostItem[];
  onNavigate: (screen: ScreenType) => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  userProfile = CURRENT_USER,
  userPosts = [],
  onNavigate,
}) => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'grid' | 'reels' | 'reposts' | 'tagged'>('grid');

  return (
    <div className="min-h-screen bg-white text-slate-900 pb-28 max-w-md mx-auto selection:bg-amber-400 selection:text-slate-900 pt-12">
      {/* Top Bar Header */}
      <div className="flex items-center justify-between px-4 mb-4">
        <div className="flex items-center gap-1.5 cursor-pointer">
          <h1 className="text-lg font-black text-slate-900 tracking-tight">@{userProfile.username || 'user.bh'}</h1>
          <span className="w-2 h-2 rounded-full bg-cyan-500" />
        </div>

        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('create-post')} className="text-slate-600 hover:text-amber-600 transition-colors">
            <Plus className="w-6 h-6" />
          </button>
          <button onClick={() => onNavigate('settings')} className="text-slate-600 hover:text-amber-600 transition-colors">
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Main Profile Info Header */}
      <div className="px-4">
        <div className="flex items-center justify-between mb-4">
          {/* Avatar */}
          <div className="relative shrink-0">
            <div className="relative w-20 h-20 rounded-full border-2 border-amber-400 p-0.5 shadow-sm">
              <img
                src={userProfile.avatar || '/logo.jpg'}
                alt={userProfile.name}
                className="w-full h-full rounded-full object-cover"
                referrerPolicy="no-referrer"
              />
              <button 
                onClick={() => onNavigate('create-post')}
                className="absolute bottom-0 right-0 p-1 rounded-full bg-amber-400 text-slate-900 border-2 border-white hover:scale-110 transition-transform shadow-xs"
              >
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
              </button>
            </div>
          </div>

          {/* Stats Bar */}
          <div className="flex-1 flex items-center justify-around text-center px-2">
            <div>
              <span className="text-base font-black text-slate-900 block">{userPosts.length}</span>
              <span className="text-xs text-slate-500 font-bold block">{t('posts')}</span>
            </div>
            <button onClick={() => onNavigate('followers-list' as any)} className="text-center hover:opacity-80 transition-opacity">
              <span className="text-base font-black text-slate-900 block">{userProfile.followersCount || 0}</span>
              <span className="text-xs text-slate-500 font-bold block">{t('followers')}</span>
            </button>
            <button onClick={() => onNavigate('following-list' as any)} className="text-center hover:opacity-80 transition-opacity">
              <span className="text-base font-black text-slate-900 block">{userProfile.followingCount || 0}</span>
              <span className="text-xs text-slate-500 font-bold block">{t('followingCount')}</span>
            </button>
          </div>
        </div>

        {/* User Bio */}
        <div className="mb-3">
          <h2 className="text-sm font-black text-slate-900">{userProfile.name}</h2>
          <p className="text-xs text-slate-700 mt-1 font-medium whitespace-pre-line leading-relaxed">
            {userProfile.bio || 'مرحباً بك في حسابي الرسمي على منصة BODY BH 🇧🇭'}
          </p>
          <div className="mt-2 flex items-center gap-2 text-[11px] font-bold text-amber-700">
            <span>📍 {userProfile.location || 'المنامة، مملكة البحرين'}</span>
          </div>
        </div>

        {/* Buttons Row */}
        <div className="grid grid-cols-2 gap-2 mb-5">
          <button
            onClick={() => onNavigate('edit-profile')}
            className="py-2.5 rounded-xl bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:bg-slate-200 transition-colors shadow-xs"
          >
            {t('editProfile')}
          </button>
          <button
            onClick={() => onNavigate('settings')}
            className="py-2.5 rounded-xl bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:bg-slate-200 transition-colors shadow-xs"
          >
            {t('shareProfile')}
          </button>
        </div>

        {/* Profile Tabs */}
        <div className="flex border-b border-slate-200 mb-3 text-slate-400">
          <button
            onClick={() => setActiveTab('grid')}
            className={`flex-1 py-3 flex items-center justify-center border-b-2 transition-colors ${
              activeTab === 'grid' ? 'border-amber-500 text-amber-600' : 'border-transparent'
            }`}
          >
            <Grid className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveTab('reels')}
            className={`flex-1 py-3 flex items-center justify-center border-b-2 transition-colors ${
              activeTab === 'reels' ? 'border-amber-500 text-amber-600' : 'border-transparent'
            }`}
          >
            <Film className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveTab('reposts')}
            className={`flex-1 py-3 flex items-center justify-center border-b-2 transition-colors ${
              activeTab === 'reposts' ? 'border-amber-500 text-amber-600' : 'border-transparent'
            }`}
          >
            <Repeat className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveTab('tagged')}
            className={`flex-1 py-3 flex items-center justify-center border-b-2 transition-colors ${
              activeTab === 'tagged' ? 'border-amber-500 text-amber-600' : 'border-transparent'
            }`}
          >
            <UserCheck className="w-5 h-5" />
          </button>
        </div>

        {/* Grid Posts or Empty State */}
        {userPosts.length > 0 ? (
          <div className="grid grid-cols-3 gap-1">
            {userPosts.map((post) => (
              <div
                key={post.id}
                onClick={() => onNavigate('home')}
                className="relative aspect-square bg-slate-100 rounded-lg overflow-hidden cursor-pointer group border border-slate-200 shadow-xs"
              >
                <img
                  src={post.mediaUrls[0]}
                  alt="Post"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
              </div>
            ))}
          </div>
        ) : (
          <div className="py-12 px-5 text-center rounded-3xl bg-slate-50 border border-slate-200 my-4 flex flex-col items-center justify-center shadow-xs">
            <div className="w-16 h-16 rounded-2xl bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-700 mb-3 shadow-xs">
              <Camera className="w-8 h-8" />
            </div>
            <h3 className="text-sm font-black text-slate-900 mb-1">حسابك جديد كلياً 🇧🇭</h3>
            <p className="text-xs text-slate-600 max-w-xs mb-4 leading-relaxed font-medium">
              لا توجد منشورات بعد. اضغط على الزر أدناه لإضافة أول صورة أو فيديو لك على المنصة!
            </p>
            <button
              onClick={() => onNavigate('create-post')}
              className="px-6 py-2.5 rounded-full bg-gradient-to-r from-amber-400 to-amber-300 text-slate-900 font-black text-xs flex items-center gap-2 shadow-md hover:brightness-105 active:scale-95 transition-all"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>نشر أول صورة / فيديو</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

