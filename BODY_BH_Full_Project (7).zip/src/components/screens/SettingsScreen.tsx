import React, { useState } from 'react';
import {
  ArrowLeft,
  User,
  Eye,
  Globe,
  TrendingUp,
  Archive,
  Shield,
  UserPlus,
  CheckCircle2,
  Lock,
  AtSign,
  Users,
  RefreshCw,
  AlertTriangle,
  Clock,
  Ban,
  Bell,
  MessageCircle,
  FileText,
  LogOut,
  ChevronLeft,
  Check,
  Code,
  Download,
  FolderArchive,
  Sun,
  Moon,
  Sparkles,
  Monitor,
  X
} from 'lucide-react';
import { ScreenType } from '../../types';
import { useLanguage } from '../../context/LanguageContext';
import { useTheme, ThemeMode } from '../../context/ThemeContext';
import { logoutUser } from '../../lib/firebase';
import { ConfirmationModal } from '../modals/ConfirmationModal';

interface SettingsScreenProps {
  onBack: () => void;
  onNavigate: (screen: ScreenType) => void;
  onLogout: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  onBack,
  onNavigate,
  onLogout,
}) => {
  const { language, setLanguage } = useLanguage();
  const { themeMode, setThemeMode, activeTheme } = useTheme();
  
  // Toggles
  const [privateAccount, setPrivateAccount] = useState(false);
  const [allowStoryShare, setAllowStoryShare] = useState(true);
  const [showContextCards, setShowContextCards] = useState(true);
  const [activityStatus, setActivityStatus] = useState(true);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  
  // Modals state
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportInput, setReportInput] = useState('');
  
  // Toast alert
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handleConfirmLogout = async () => {
    setIsLoggingOut(true);
    try {
      await logoutUser();
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoggingOut(false);
      setShowLogoutConfirm(false);
      onLogout();
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 p-4 pt-12 pb-28 max-w-md mx-auto selection:bg-amber-400 selection:text-slate-900 text-right">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-2xl bg-emerald-500 text-slate-900 font-black text-xs text-center flex items-center gap-2 shadow-2xl animate-bounce">
          <Check className="w-4 h-4 text-slate-900 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header */}
      <div className="flex items-center justify-between mb-6">
        <button onClick={onBack} className="p-2.5 rounded-full bg-slate-100 border border-slate-200 text-slate-700 hover:text-slate-900 hover:bg-slate-200 transition-colors">
          <ArrowLeft className="w-5 h-5 rtl:rotate-180" />
        </button>
        <h1 className="text-base font-black text-slate-900 tracking-tight">الإعدادات</h1>
        <div className="w-8" />
      </div>

      <div className="space-y-6">

        {/* 1. قسم الحساب (Account) */}
        <div>
          <span className="text-xs font-bold text-slate-500 block mb-2 px-2">الحساب</span>
          <div className="bg-slate-50 border border-slate-200 rounded-3xl overflow-hidden divide-y divide-slate-200 shadow-sm">
            {/* تعديل الملف الشخصي */}
            <div
              onClick={() => onNavigate('edit-profile')}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <User className="w-4.5 h-4.5 text-amber-500" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">تعديل الملف الشخصي</h4>
                  <p className="text-[10px] text-slate-500 font-medium">loa@</p>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>

            {/* كلمة المرور */}
            <div
              onClick={() => showToast('تم إرسال رابط إعادة تعيين كلمة المرور برابط آمن')}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <Eye className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">كلمة المرور</h4>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>

            {/* البريد الإلكتروني */}
            <div
              onClick={() => onNavigate('edit-profile')}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <Globe className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">البريد الإلكتروني</h4>
                  <p className="text-[10px] text-slate-500 font-medium">louayj2011@gmail.com</p>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>

            {/* الترقية إلى حساب احترافي */}
            <div
              onClick={() => showToast('حسابك مفعل كحساب احترافي مجاناً 🇧🇭')}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 shrink-0 shadow-xs">
                  <TrendingUp className="w-4.5 h-4.5" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">الترقية إلى حساب احترافي</h4>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>

            {/* أرشيف */}
            <div
              onClick={() => showToast('الأرشيف فارغ حالياً')}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <Archive className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">أرشيف</h4>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>

            {/* ملكية الحساب والتحكم فيه */}
            <div
              onClick={() => showToast('إدارتك للحساب محمية بأعلى درجات الأمان')}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <Shield className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">ملكية الحساب والتحكم فيه</h4>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>
          </div>
        </div>

        {/* 2. قسم الطلبات (Requests) */}
        <div>
          <span className="text-xs font-bold text-slate-500 block mb-2 px-2">الطلبات</span>
          <div className="bg-slate-50 border border-slate-200 rounded-3xl overflow-hidden divide-y divide-slate-200 shadow-sm">
            {/* طلب اسم مستخدم */}
            <div
              onClick={() => onNavigate('edit-profile')}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <UserPlus className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">طلب اسم مستخدم</h4>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>

            {/* طلب التوثيق */}
            <div
              onClick={() => showToast('تم تقديم طلب التوثيق وسيتم المراجعة')}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 shrink-0 shadow-xs">
                  <CheckCircle2 className="w-4.5 h-4.5 text-amber-500" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">طلب التوثيق</h4>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>
          </div>
        </div>

        {/* 3. الخصوصية والتفاعل */}
        <div>
          <div className="bg-slate-50 border border-slate-200 rounded-3xl overflow-hidden divide-y divide-slate-200 shadow-sm">
            {/* حساب خاص */}
            <div className="p-3.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <Lock className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">حساب خاص</h4>
              </div>
              <button
                onClick={() => setPrivateAccount(!privateAccount)}
                className={`w-12 h-6.5 rounded-full transition-colors relative p-0.5 shadow-inner ${
                  privateAccount ? 'bg-amber-400' : 'bg-slate-200'
                }`}
              >
                <div
                  className={`w-5.5 h-5.5 rounded-full bg-white shadow-md transition-transform ${
                    privateAccount ? '-translate-x-5.5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* من يمكنه ذكرك */}
            <div
              onClick={() => showToast('الإتاحة: الجميع')}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <AtSign className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">من يمكنه ذكرك</h4>
                  <p className="text-[10px] text-slate-500 font-medium">الجميع</p>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>

            {/* من يمكنه إضافتك إلى المجموعات */}
            <div
              onClick={() => showToast('الإتاحة: الأشخاص الذين تتابعهم')}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <Users className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">من يمكنه إضافتك إلى المجموعات</h4>
                  <p className="text-[10px] text-slate-500 font-medium">الأشخاص الذين تتابعهم</p>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>

            {/* السماح للمذكورين بمشاركة قصتك */}
            <div className="p-3.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <RefreshCw className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">السماح للمذكورين بمشاركة قصتك</h4>
              </div>
              <button
                onClick={() => setAllowStoryShare(!allowStoryShare)}
                className={`w-12 h-6.5 rounded-full transition-colors relative p-0.5 shadow-inner ${
                  allowStoryShare ? 'bg-amber-400' : 'bg-slate-200'
                }`}
              >
                <div
                  className={`w-5.5 h-5.5 rounded-full bg-white shadow-md transition-transform ${
                    allowStoryShare ? '-translate-x-5.5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* إظهار بطاقات السياق */}
            <div className="p-3.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <AlertTriangle className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">إظهار بطاقات السياق</h4>
              </div>
              <button
                onClick={() => setShowContextCards(!showContextCards)}
                className={`w-12 h-6.5 rounded-full transition-colors relative p-0.5 shadow-inner ${
                  showContextCards ? 'bg-amber-400' : 'bg-slate-200'
                }`}
              >
                <div
                  className={`w-5.5 h-5.5 rounded-full bg-white shadow-md transition-transform ${
                    showContextCards ? '-translate-x-5.5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* حالة النشاط */}
            <div className="p-3.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <Clock className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">حالة النشاط</h4>
              </div>
              <button
                onClick={() => setActivityStatus(!activityStatus)}
                className={`w-12 h-6.5 rounded-full transition-colors relative p-0.5 shadow-inner ${
                  activityStatus ? 'bg-amber-400' : 'bg-slate-200'
                }`}
              >
                <div
                  className={`w-5.5 h-5.5 rounded-full bg-white shadow-md transition-transform ${
                    activityStatus ? '-translate-x-5.5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* المستخدمون المحظورون */}
            <div
              onClick={() => showToast('قائمة الحظر فارغة')}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-600 shrink-0 shadow-xs">
                  <Ban className="w-4.5 h-4.5" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">المستخدمون المحظورون</h4>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>
          </div>
        </div>

        {/* 4. الإشعارات والمظهر */}
        <div>
          <div className="bg-slate-50 border border-slate-200 rounded-3xl overflow-hidden divide-y divide-slate-200 shadow-sm">
            {/* الإشعارات */}
            <div
              onClick={() => setNotificationsEnabled(!notificationsEnabled)}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 shrink-0 shadow-xs">
                  <Bell className="w-4.5 h-4.5" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">الإشعارات</h4>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>

            {/* مظهر الشاشة: [الوضع النهاري | الوضع الداكن | الوضع الليلي | النظام] */}
            <div className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-500 block">ثيم ومظهر التطبيق</span>
                <span className="text-[10px] font-black text-amber-700 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-full">
                  {activeTheme === 'light' ? 'الوضع النهاري ☀️' : activeTheme === 'night' ? 'الوضع الليلي 🌌' : 'الوضع الداكن 🌙'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    setThemeMode('light');
                    showToast('تم تفعيل الوضع النهاري (النهار ☀️)');
                  }}
                  className={`p-3 rounded-2xl border text-xs font-black transition-all flex items-center gap-2 justify-center ${
                    themeMode === 'light'
                      ? 'bg-amber-400 text-slate-900 border-amber-500 shadow-sm scale-[1.02]'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <Sun className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>الوضع النهاري</span>
                </button>

                <button
                  onClick={() => {
                    setThemeMode('dark');
                    showToast('تم تفعيل الوضع الداكن 🌙');
                  }}
                  className={`p-3 rounded-2xl border text-xs font-black transition-all flex items-center gap-2 justify-center ${
                    themeMode === 'dark'
                      ? 'bg-slate-900 text-white border-slate-950 shadow-sm scale-[1.02]'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <Moon className="w-4 h-4 text-slate-400 shrink-0" />
                  <span>الوضع الداكن</span>
                </button>

                <button
                  onClick={() => {
                    setThemeMode('night');
                    showToast('تم تفعيل الوضع الليلي الفائق 🌌');
                  }}
                  className={`p-3 rounded-2xl border text-xs font-black transition-all flex items-center gap-2 justify-center ${
                    themeMode === 'night'
                      ? 'bg-neutral-950 text-amber-400 border-amber-500/50 shadow-sm scale-[1.02]'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>الوضع الليلي</span>
                </button>

                <button
                  onClick={() => {
                    setThemeMode('system');
                    showToast('تم تفعيل مظهر النظام التلقائي 📱');
                  }}
                  className={`p-3 rounded-2xl border text-xs font-black transition-all flex items-center gap-2 justify-center ${
                    themeMode === 'system'
                      ? 'bg-slate-200 text-slate-900 border-slate-300 shadow-sm scale-[1.02]'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <Monitor className="w-4 h-4 text-slate-600 shrink-0" />
                  <span>تلقائي (النظام)</span>
                </button>
              </div>
            </div>

            {/* اللغة */}
            <div
              onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <Globe className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">اللغة</h4>
                  <p className="text-[10px] text-slate-500 font-medium">
                    {language === 'ar' ? 'العربية (النظام)' : 'English (System)'}
                  </p>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>
          </div>
        </div>

        {/* 5. الدعم وسياسة الخصوصية */}
        <div>
          <div className="bg-slate-50 border border-slate-200 rounded-3xl overflow-hidden divide-y divide-slate-200 shadow-sm">
            {/* الإبلاغ عن مشكلة */}
            <div
              onClick={() => setShowReportModal(true)}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <MessageCircle className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">الإبلاغ عن مشكلة والدعم الفني</h4>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>

            {/* Privacy Policy */}
            <div
              onClick={() => setShowPrivacyModal(true)}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <Shield className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">سياسة الخصوصية • Privacy Policy</h4>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>

            {/* Terms of Service */}
            <div
              onClick={() => setShowTermsModal(true)}
              className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-100/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <FileText className="w-4.5 h-4.5 text-slate-700" />
                </div>
                <h4 className="text-xs font-bold text-slate-900">شروط الاستخدام • Terms of Service</h4>
              </div>
              <ChevronLeft className="w-4 h-4 text-slate-400 rtl:rotate-180" />
            </div>
          </div>
        </div>

        {/* 6. تصدير مشروع التطبيق ZIP */}
        <div>
          <div className="bg-gradient-to-br from-amber-50 via-amber-100/60 to-orange-50 border border-amber-300 rounded-3xl p-4 shadow-sm text-right relative overflow-hidden space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-400 text-slate-900 flex items-center justify-center shrink-0 shadow-sm">
                  <FolderArchive className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-900">تصدير مشروع التطبيق (ZIP / GitHub)</h4>
                  <p className="text-[10px] text-amber-800 font-bold">جاهز للنشر على App Store و Google Play</p>
                </div>
              </div>
            </div>

            <p className="text-[11px] text-slate-700 leading-relaxed font-medium bg-white/80 p-3 rounded-2xl border border-amber-200">
              اضغط على الزر أدناه لتحميل ملف <strong className="text-amber-800">ZIP</strong> المباشر المكتمل لكود مشروع التطبيق كاملاً، أو استخدم زر الإعدادات ⚙️ أعلى منصة AI Studio.
            </p>

            <a
              href="/api/download-zip"
              download="BODY_BH_Full_Project.zip"
              onClick={() => showToast('جاري بدء تحميل ملف المشروع ZIP مباشرة... 📦')}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-300 text-slate-900 font-black text-xs flex items-center justify-center gap-2 shadow-md hover:brightness-105 active:scale-95 transition-all text-center block"
            >
              <Download className="w-4 h-4 text-slate-900 inline-block" />
              <span>تحميل كود التطبيق كامل ZIP مباشرة 📦</span>
            </a>
          </div>
        </div>

        {/* 7. حقوق المطور */}
        <div>
          <div className="bg-slate-50 border border-amber-300/60 rounded-3xl p-4 shadow-sm text-right relative overflow-hidden">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-700 shrink-0">
                  <Code className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-900">حقوق المطور والبرمجة</h4>
                  <p className="text-[10px] text-amber-700 font-bold">المطور والمهندس المسؤول</p>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-amber-100 border border-amber-300 text-[10px] font-black text-amber-800">
                v2.4 PRO 🇧🇭
              </span>
            </div>
            <div className="p-2.5 rounded-2xl bg-white border border-slate-200 flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-500">اسم المطور الرسمي:</span>
              <span className="text-xs font-black text-amber-700">لؤي بن حسين</span>
            </div>
          </div>
        </div>

        {/* 7. تسجيل الخروج */}
        <div>
          <div className="bg-slate-50 border border-slate-200 rounded-3xl overflow-hidden shadow-sm">
            <button
              onClick={() => setShowLogoutConfirm(true)}
              className="w-full p-4 flex items-center justify-between text-rose-600 hover:bg-rose-50 transition-colors"
            >
              <h4 className="text-xs font-black text-rose-600">تسجيل الخروج</h4>
              <div className="w-8 h-8 rounded-xl bg-rose-100 flex items-center justify-center">
                <LogOut className="w-4 h-4 text-rose-600" />
              </div>
            </button>
          </div>
        </div>

      </div>

      {/* 🛑 Modal confirmation for logout */}
      <ConfirmationModal
        isOpen={showLogoutConfirm}
        onClose={() => setShowLogoutConfirm(false)}
        onConfirm={handleConfirmLogout}
        title="تأكيد تسجيل الخروج"
        description="هل أنت تأكد من رغبتك في تسجيل الخروج من حسابك في شبكة BODY BH؟"
        confirmText="تأكيد الخروج"
        cancelText="إلغاء"
        isDanger={true}
        isLoading={isLoggingOut}
        icon={<LogOut className="w-7 h-7 text-rose-600" />}
      />

      {/* 📜 Privacy Policy Modal */}
      {showPrivacyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-100 overflow-hidden text-right">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-500" />
                <h3 className="font-black text-slate-900 text-sm">سياسة الخصوصية (Privacy Policy)</h3>
              </div>
              <button
                onClick={() => setShowPrivacyModal(false)}
                className="p-1.5 rounded-full bg-slate-200/70 text-slate-600 hover:bg-slate-300 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs leading-relaxed text-slate-700">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-amber-900 font-bold">
                تلتزم منصة BODY BH بحماية بيانات وخصوصية المستخدمين وفق قوانين مملكة البحرين 🇧🇭 والمعايير العالمية لمنصات Apple & Google Store.
              </div>

              <div>
                <h4 className="font-black text-slate-900 text-xs mb-1">1. البيانات التي نجمعها</h4>
                <p>نجمع البيانات الأساسية اللازمة لإنشاء حسابك وتجربة التواصل (الاسم، البريد الإلكتروني، اسم المستخدم، وصورة الحساب الشخصية) بشكل آمن ومشفر.</p>
              </div>

              <div>
                <h4 className="font-black text-slate-900 text-xs mb-1">2. استخدام وتأمين البيانات</h4>
                <p>تُحفظ البيانات في خوادم مقترنة بقواعد حماية متطورة (Firebase Security Rules). لا نقوم ببيع أو مشاركة بياناتك مع أي طرف ثالث تحت أي ظرف.</p>
              </div>

              <div>
                <h4 className="font-black text-slate-900 text-xs mb-1">3. حق حذف الحساب والبيانات</h4>
                <p>يحق للمستخدم طلب حذف حسابه وكافة بياناته نهائياً في أي وقت من خلال خيار الإبلاغ أو عبر الدعم الفني المباشر للتطبيق.</p>
              </div>

              <div>
                <h4 className="font-black text-slate-900 text-xs mb-1">4. التحديثات والتواصل</h4>
                <p>يتم تحديث سياسة الخصوصية لعام 2026 لمواكبة أحدث المتطلبات، ولأي استفسارات يمكنك مراسلة الفريق عبر قسم الدعم.</p>
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 bg-slate-50">
              <button
                onClick={() => setShowPrivacyModal(false)}
                className="w-full py-2.5 bg-slate-900 text-white font-black text-xs rounded-xl shadow-sm hover:bg-slate-800"
              >
                موافق وإغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 📄 Terms of Service Modal */}
      {showTermsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-100 overflow-hidden text-right">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-500" />
                <h3 className="font-black text-slate-900 text-sm">شروط الخدمة (Terms of Service)</h3>
              </div>
              <button
                onClick={() => setShowTermsModal(false)}
                className="p-1.5 rounded-full bg-slate-200/70 text-slate-600 hover:bg-slate-300 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs leading-relaxed text-slate-700">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-amber-900 font-bold">
                مرحباً بك في منصة BODY BH. بشرائك أو استخدامك للتطبيق فإنك توافق على الالتزام بالقواعد التالية:
              </div>

              <div>
                <h4 className="font-black text-slate-900 text-xs mb-1">1. قواعد السلوك والمحتوى</h4>
                <p>يُمنع نشر أي محتوى يسيء للآخرين أو يخالف الآداب العامة وقوانين مملكة البحرين. نحتفظ بحق حظر أو تقييد الحسابات المخالفة فوراً.</p>
              </div>

              <div>
                <h4 className="font-black text-slate-900 text-xs mb-1">2. أمان الحساب والسرية</h4>
                <p>أنت مسؤول عن الحفاظ على سرية كلمة المرور الخاصة بك وبيانات الدخول عبر Google أو Apple.</p>
              </div>

              <div>
                <h4 className="font-black text-slate-900 text-xs mb-1">3. الملكية الفكرية</h4>
                <p>جميع العلامات والشعارات والتصميم الخاصة بتطبيق BODY BH مملوكة بالكامل للمنصة وتخضع للحماية القانونية.</p>
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 bg-slate-50">
              <button
                onClick={() => setShowTermsModal(false)}
                className="w-full py-2.5 bg-slate-900 text-white font-black text-xs rounded-xl shadow-sm hover:bg-slate-800"
              >
                موافق وإغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 💬 Report Issue / Support Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-fade-in">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-100 text-right space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5 text-amber-500" />
                <h3 className="font-black text-slate-900 text-sm">الإبلاغ عن مشكلة والدعم</h3>
              </div>
              <button
                onClick={() => setShowReportModal(false)}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed font-medium">
              يرجى كتابة تفاصيل المشكلة أو الاقتراح وسيتم مراجعتها من فريق دعم BODY BH مباشرة:
            </p>

            <textarea
              rows={4}
              value={reportInput}
              onChange={(e) => setReportInput(e.target.value)}
              placeholder="اكتب ملاحظاتك أو المشكلة هنا..."
              className="w-full p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-900 focus:outline-none focus:bg-white focus:border-amber-500"
            />

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowReportModal(false)}
                className="py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs hover:bg-slate-200"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={() => {
                  if (reportInput.trim()) {
                    showToast('تم إرسال بلاغك بنجاح إلى فريق الدعم 🇧🇭');
                    setReportInput('');
                    setShowReportModal(false);
                  } else {
                    showToast('يرجى كتابة وصف للمشكلة قبل الإرسال');
                  }
                }}
                className="py-2.5 rounded-xl bg-amber-500 text-slate-950 font-black text-xs shadow-md hover:bg-amber-400"
              >
                إرسال التقرير
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

