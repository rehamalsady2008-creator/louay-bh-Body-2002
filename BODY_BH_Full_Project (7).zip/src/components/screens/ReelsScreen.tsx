import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, MessageCircle, Share2, Bookmark, CheckCircle2, Music, Disc, Plus, Volume2, VolumeX, ChevronUp, ChevronDown } from 'lucide-react';
import { ReelItem } from '../../types';
import { MOCK_REELS } from '../../data/mockData';
import { CommentsModal } from '../modals/CommentsModal';
import { ShareModal } from '../modals/ShareModal';

export const ReelsScreen: React.FC = () => {
  const [reelsIndex, setReelsIndex] = useState(0);
  const [reels, setReels] = useState<ReelItem[]>(MOCK_REELS);
  const [isMuted, setIsMuted] = useState(false);
  const [doubleTapHearts, setDoubleTapHearts] = useState<{ id: number; x: number; y: number }[]>([]);

  const [selectedCommentsReel, setSelectedCommentsReel] = useState<ReelItem | null>(null);
  const [isShareOpen, setIsShareOpen] = useState(false);

  if (reels.length === 0) {
    return (
      <div className="relative w-full h-screen bg-black text-white flex flex-col items-center justify-center p-6 text-center select-none pb-20">
        <div className="w-20 h-20 rounded-3xl bg-neutral-900 border border-amber-400/30 flex items-center justify-center text-amber-400 mb-4 shadow-xl shadow-amber-500/10">
          <Disc className="w-10 h-10 animate-spin" style={{ animationDuration: '6s' }} />
        </div>
        <h2 className="text-xl font-black text-white mb-2">لا توجد مقاطع ريلز بعد</h2>
        <p className="text-xs text-neutral-400 max-w-xs mb-6 leading-relaxed">
          شارك مقاطع الفيديو الرياضية والتمارين الخاصة بك مع مجتمع BODY BH 🇧🇭
        </p>
      </div>
    );
  }

  const currentReel = reels[reelsIndex] || reels[0];

  const handleNextReel = () => {
    setReelsIndex((prev) => (prev + 1) % reels.length);
  };

  const handlePrevReel = () => {
    setReelsIndex((prev) => (prev === 0 ? reels.length - 1 : prev - 1));
  };

  const toggleLike = () => {
    setReels((prev) =>
      prev.map((r) => {
        if (r.id === currentReel.id) {
          return {
            ...r,
            isLiked: !r.isLiked,
            likesCount: r.isLiked ? r.likesCount - 1 : r.likesCount + 1,
          };
        }
        return r;
      })
    );
  };

  const handleDoubleTap = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const newHeart = { id: Date.now(), x, y };
    setDoubleTapHearts((prev) => [...prev, newHeart]);

    setTimeout(() => {
      setDoubleTapHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
    }, 900);

    if (!currentReel.isLiked) {
      toggleLike();
    }
  };

  const toggleBookmark = () => {
    setReels((prev) =>
      prev.map((r) => (r.id === currentReel.id ? { ...r, isSaved: !r.isSaved } : r))
    );
  };

  return (
    <div className="relative w-full h-screen bg-black text-white overflow-hidden select-none pb-20">
      {/* Video Container with HTML5 video / high quality fallback image */}
      <div
        onDoubleClick={handleDoubleTap}
        className="relative w-full h-full flex items-center justify-center bg-neutral-950"
      >
        <video
          key={currentReel.id}
          src={currentReel.videoUrl}
          poster={currentReel.thumbnail}
          autoPlay
          loop
          muted={isMuted}
          playsInline
          className="w-full h-full object-cover"
        />

        {/* Subtle Dark Vignette Gradients for Text Readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/80 pointer-events-none" />

        {/* Up / Down Reel Switcher Overlay Controls */}
        <div className="absolute left-1/2 -translate-x-1/2 top-14 z-20 flex items-center gap-3">
          <button
            onClick={handlePrevReel}
            className="p-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-neutral-300 hover:text-white"
          >
            <ChevronUp className="w-4 h-4" />
          </button>
          <span className="text-xs font-black tracking-wider text-amber-300 uppercase bg-black/60 px-3 py-1 rounded-full border border-amber-400/30 backdrop-blur-md">
            Reels {reelsIndex + 1} / {reels.length}
          </span>
          <button
            onClick={handleNextReel}
            className="p-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-neutral-300 hover:text-white"
          >
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>

        {/* Sound Toggle */}
        <button
          onClick={() => setIsMuted(!isMuted)}
          className="absolute top-14 right-4 z-20 p-2.5 rounded-full bg-black/60 backdrop-blur-md border border-white/20 hover:scale-105 transition-transform"
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-amber-400" /> : <Volume2 className="w-4 h-4 text-white" />}
        </button>

        {/* Particle Heart Bursts */}
        <AnimatePresence>
          {doubleTapHearts.map((heart) => (
            <motion.div
              key={heart.id}
              initial={{ scale: 0.2, opacity: 0, y: 0 }}
              animate={{ scale: 1.4, opacity: 1, y: -30 }}
              exit={{ scale: 0.2, opacity: 0, y: -70 }}
              style={{ left: heart.x - 56, top: heart.y - 56 }}
              className="absolute pointer-events-none z-30"
            >
              <Heart className="w-28 h-28 text-rose-500 fill-rose-500 drop-shadow-[0_0_40px_rgba(244,63,94,0.9)]" />
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Vertical Action Sidebar */}
        <div className="absolute right-3.5 bottom-28 z-30 flex flex-col items-center gap-5">
          {/* Like */}
          <button onClick={toggleLike} className="flex flex-col items-center gap-1 group">
            <div className="p-3 rounded-full bg-black/60 backdrop-blur-xl border border-white/15 group-active:scale-125 transition-transform shadow-lg">
              <Heart
                className={`w-6 h-6 ${
                  currentReel.isLiked ? 'text-rose-500 fill-rose-500' : 'text-white'
                }`}
              />
            </div>
            <span className="text-[10px] font-extrabold text-white tracking-tight">
              {currentReel.likesCount.toLocaleString()}
            </span>
          </button>

          {/* Comment */}
          <button
            onClick={() => setSelectedCommentsReel(currentReel)}
            className="flex flex-col items-center gap-1"
          >
            <div className="p-3 rounded-full bg-black/60 backdrop-blur-xl border border-white/15 shadow-lg">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <span className="text-[10px] font-extrabold text-white">{currentReel.commentsCount}</span>
          </button>

          {/* Share */}
          <button onClick={() => setIsShareOpen(true)} className="flex flex-col items-center gap-1">
            <div className="p-3 rounded-full bg-black/60 backdrop-blur-xl border border-white/15 shadow-lg">
              <Share2 className="w-6 h-6 text-white" />
            </div>
            <span className="text-[10px] font-extrabold text-white">{currentReel.sharesCount}</span>
          </button>

          {/* Save */}
          <button onClick={toggleBookmark} className="flex flex-col items-center gap-1">
            <div className="p-3 rounded-full bg-black/60 backdrop-blur-xl border border-white/15 shadow-lg">
              <Bookmark className={`w-6 h-6 ${currentReel.isSaved ? 'text-amber-400 fill-amber-400' : 'text-white'}`} />
            </div>
          </button>

          {/* Rotating Audio Vinyl Disc */}
          <div className="w-11 h-11 rounded-full border-2 border-amber-400 overflow-hidden animate-spin shadow-xl shadow-amber-500/20 p-1 bg-black" style={{ animationDuration: '6s' }}>
            <img
              src={currentReel.userAvatar}
              alt="disc"
              className="w-full h-full rounded-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Bottom Creator & Caption Overlay */}
        <div className="absolute left-4 right-18 bottom-24 z-20 space-y-2.5 max-w-[80%]">
          {/* Creator Header */}
          <div className="flex items-center gap-2.5">
            <img
              src={currentReel.userAvatar}
              alt={currentReel.username}
              className="w-10 h-10 rounded-full object-cover border-2 border-amber-400 shadow-md"
              referrerPolicy="no-referrer"
            />
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black text-white">{currentReel.username}</span>
              {currentReel.verified && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
            </div>
            <button className="px-3.5 py-1 rounded-full bg-gradient-to-r from-amber-400 to-amber-200 text-black font-extrabold text-[10px] shadow-lg shadow-amber-500/20 hover:brightness-110 active:scale-95 transition-all">
              Follow +
            </button>
          </div>

          {/* Caption */}
          <p className="text-xs text-neutral-200 line-clamp-3 leading-relaxed drop-shadow-md">
            {currentReel.caption}
          </p>

          {/* Audio track pill */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/15 text-[11px] text-amber-300 font-semibold w-fit shadow-md">
            <Music className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span className="truncate max-w-[200px]">{currentReel.audioName}</span>
          </div>
        </div>
      </div>

      {/* Modals */}
      {selectedCommentsReel && (
        <CommentsModal
          isOpen={!!selectedCommentsReel}
          onClose={() => setSelectedCommentsReel(null)}
          comments={selectedCommentsReel.comments}
          onAddComment={(text) => {
            const newComment = {
              id: `rc_${Date.now()}`,
              userId: 'user_me',
              username: 'tariq.bh',
              avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=800',
              verified: true,
              text,
              timeAgo: 'Just now',
              likesCount: 0,
            };
            setSelectedCommentsReel((prev) =>
              prev ? { ...prev, comments: [newComment, ...prev.comments] } : null
            );
          }}
        />
      )}

      <ShareModal isOpen={isShareOpen} onClose={() => setIsShareOpen(false)} />
    </div>
  );
};
