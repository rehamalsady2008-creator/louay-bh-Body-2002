import React, { useState } from 'react';
import { Bell, Heart, MessageCircle, UserPlus, Radio, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';
import { NotificationItem, ScreenType } from '../../types';
import { MOCK_NOTIFICATIONS } from '../../data/mockData';

interface NotificationsScreenProps {
  onNavigate: (screen: ScreenType) => void;
  onOpenLiveStream: () => void;
}

export const NotificationsScreen: React.FC<NotificationsScreenProps> = ({
  onNavigate,
  onOpenLiveStream,
}) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>(MOCK_NOTIFICATIONS);

  const handleFollowBack = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  return (
    <div className="min-h-screen bg-black text-white p-4 pt-12 pb-28 max-w-md mx-auto selection:bg-amber-400 selection:text-black">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-200 text-black shadow-lg shadow-amber-500/20">
            <Bell className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tight text-white">Notifications</h1>
            <p className="text-[10px] text-neutral-400 font-semibold uppercase tracking-wider -mt-0.5">
              Live Activity & Mentions
            </p>
          </div>
        </div>
        <span className="text-[10px] bg-neutral-900 border border-white/10 text-amber-300 font-extrabold px-3 py-1 rounded-full">
          {notifications.filter(n => !n.isRead).length} غير مقروء
        </span>
      </div>

      {/* Notifications Stack */}
      <div className="space-y-3">
        {notifications.length === 0 ? (
          <div className="py-20 text-center flex flex-col items-center justify-center border border-white/10 rounded-3xl bg-neutral-900/40 my-4">
            <div className="w-14 h-14 rounded-full bg-neutral-900 border border-amber-400/30 flex items-center justify-center text-amber-400 mb-3 shadow-md">
              <Bell className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-black text-white mb-1">لا توجد إشعارات حالياً</h3>
            <p className="text-[11px] text-neutral-400 max-w-[220px]">
              ستظهر هنا التفاعلات والإعجابات والمتابعات الجديدة
            </p>
          </div>
        ) : (
          notifications.map((item) => {
          return (
            <div
              key={item.id}
              className={`p-4 rounded-3xl border transition-all flex items-center justify-between gap-3 shadow-xl ${
                !item.isRead
                  ? 'bg-amber-500/10 border-amber-400/40 shadow-amber-500/5'
                  : 'bg-neutral-900/80 border-white/10'
              }`}
            >
              <div className="flex items-center gap-3.5 flex-1">
                <div className="relative shrink-0">
                  <img
                    src={item.avatar}
                    alt={item.username}
                    className="w-12 h-12 rounded-full object-cover border border-amber-400/40 shadow-md"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute -bottom-1 -right-1 p-1 rounded-full bg-black border border-white/20 shadow-md">
                    {item.type === 'like' && <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />}
                    {item.type === 'comment' && <MessageCircle className="w-3 h-3 text-cyan-400" />}
                    {item.type === 'follow' && <UserPlus className="w-3 h-3 text-amber-400" />}
                    {item.type === 'live' && <Radio className="w-3 h-3 text-rose-400" />}
                  </div>
                </div>

                <div className="flex-1 text-xs">
                  <div className="flex items-center gap-1 mb-0.5">
                    <span className="font-extrabold text-white">{item.username}</span>
                    {item.verified && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
                    <span className="text-[10px] text-neutral-500 font-medium ml-1">{item.timeAgo}</span>
                  </div>
                  <p className="text-neutral-300 leading-snug font-medium">{item.content}</p>
                </div>
              </div>

              {/* Right Action Trigger */}
              {item.type === 'follow' ? (
                <button
                  onClick={() => handleFollowBack(item.id)}
                  className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-amber-400 to-amber-200 text-black font-black text-[10px] shrink-0 hover:scale-105 transition-transform shadow-md"
                >
                  Follow Back
                </button>
              ) : item.type === 'live' ? (
                <button
                  onClick={onOpenLiveStream}
                  className="px-3.5 py-1.5 rounded-full bg-rose-500 text-white font-black text-[10px] shrink-0 animate-pulse shadow-md shadow-rose-500/30"
                >
                  Join Live
                </button>
              ) : item.postThumbnail ? (
                <img
                  src={item.postThumbnail}
                  alt="thumbnail"
                  className="w-11 h-11 rounded-2xl object-cover border border-white/10 shrink-0 shadow-md"
                  referrerPolicy="no-referrer"
                />
              ) : null}
            </div>
          );
        }))}
      </div>
    </div>
  );
};
