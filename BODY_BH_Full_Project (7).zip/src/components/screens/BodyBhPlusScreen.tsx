import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, Sparkles, ShieldCheck, Zap, Heart, Check, Gift } from 'lucide-react';

interface BodyBhPlusScreenProps {
  onBack: () => void;
}

export const BodyBhPlusScreen: React.FC<BodyBhPlusScreenProps> = ({ onBack }) => {
  const [confirmed, setConfirmed] = useState(true);

  const perks = [
    { title: 'رفع الفيديوهات بدقة 4K 60fps مجاناً', desc: 'يمكن لجميع المستخدمين في البحرين رفع الصور والفيديوهات بأعلى جودة بدقة 4K مجاناً', icon: Zap },
    { title: 'مدرب الذكاء الاصطناعي Gemini AI المجاني', desc: 'تحليل السعرات، خطط التغذية، والبرامج الرياضية متاحة 100% بدون أي رسوم', icon: Sparkles },
    { title: 'البث المباشر والغرف الرياضية المفتوحة', desc: 'إمكانية إطلاق بث مباشر والدردشة مع الرياضيين مجاناً للجميع', icon: Gift },
    { title: 'تطبيق بدون إعلانات مزعجة 🇧🇭', desc: 'تصفح سلس وسريع بدون أي إعلانات أو باقات VIP مدفوعة', icon: ShieldCheck },
  ];

  return (
    <div className="min-h-screen bg-white text-slate-900 p-4 pt-12 pb-28 max-w-md mx-auto relative overflow-hidden selection:bg-amber-400 selection:text-slate-900 text-right">
      {/* Background Ambient Glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between mb-6 relative z-10">
        <button onClick={onBack} className="p-2.5 rounded-full bg-slate-100 border border-slate-200 text-slate-700 hover:text-slate-900 transition-colors shadow-xs">
          <ArrowLeft className="w-5 h-5 rtl:rotate-180" />
        </button>
        <span className="text-xs font-black text-emerald-700 uppercase tracking-widest flex items-center gap-1">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>تطبيق مجاني 100% 🇧🇭</span>
        </span>
        <div className="w-8" />
      </div>

      {/* Main Title Hero */}
      <div className="text-center mb-6 relative z-10">
        <div className="inline-flex p-1 rounded-3xl bg-amber-400 shadow-md mb-3">
          <img 
            src="/logo.jpg" 
            alt="BODY BH Logo" 
            className="w-16 h-16 rounded-2xl object-cover"
          />
        </div>
        <h1 className="text-2xl font-black text-slate-900 tracking-tight">
          تطبيق BODY BH مجاني بالكامل 🇧🇭
        </h1>
        <p className="text-xs font-bold text-amber-900 mt-2 max-w-xs mx-auto leading-relaxed bg-amber-50 border border-amber-300 p-2.5 rounded-2xl">
          تم إلغاء جميع اشتراكات VIP والرسوم المالية! التطبيق مجاني 100% لجميع أهل ومقيمي مملكة البحرين.
        </p>
      </div>

      {/* Zero Fees Status Banner */}
      <div className="p-4 rounded-3xl bg-emerald-50 border border-emerald-300 mb-6 relative z-10 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500 text-white font-black flex items-center justify-center shrink-0">
            0.0
          </div>
          <div>
            <h3 className="text-xs font-black text-slate-900">الاشتراك: 0 د.ب (مجاني دائماً)</h3>
            <p className="text-[10px] text-emerald-800 font-extrabold">جميع المميزات والمستويات متاحة مجاناً</p>
          </div>
        </div>
        <Check className="w-5 h-5 text-emerald-600 shrink-0" />
      </div>

      {/* Perks List */}
      <div className="space-y-3 mb-8 relative z-10">
        {perks.map((p) => {
          const Icon = p.icon;
          return (
            <div
              key={p.title}
              className="p-4 rounded-3xl bg-slate-50 border border-slate-200 flex items-start gap-4 hover:border-emerald-400 transition-colors shadow-xs"
            >
              <div className="p-3 rounded-2xl bg-emerald-100 text-emerald-800 border border-emerald-300 shrink-0 shadow-xs">
                <Icon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs font-black text-slate-900">{p.title}</h3>
                <p className="text-[11px] text-slate-600 mt-0.5 leading-snug font-medium">{p.desc}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Action Button */}
      <div className="relative z-10">
        <button
          onClick={onBack}
          className="w-full py-4 rounded-3xl bg-gradient-to-r from-emerald-500 via-emerald-400 to-teal-400 text-white font-black text-xs shadow-md hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2"
        >
          <CheckCircle2 className="w-5 h-5" />
          <span>استمتع بالتطبيق المجاني 🇧🇭</span>
        </button>
      </div>
    </div>
  );
};
