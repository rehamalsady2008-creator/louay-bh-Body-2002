import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Heart, 
  Send, 
  Volume2, 
  VolumeX, 
  CheckCircle2, 
  Eye, 
  Flame, 
  Sparkles, 
  Dumbbell, 
  Crown,
  Share2
} from 'lucide-react';
import { StoryItem } from '../../types';

interface StoriesScreenProps {
  story: StoryItem;
  onClose: () => void;
}

export const StoriesScreen: React.FC<StoriesScreenProps> = ({ story, onClose }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(142);
  const [showHeartBurst, setShowHeartBurst] = useState(false);
  const [floatingReaction, setFloatingReaction] = useState<string | null>(null);

  const currentSlide = story.stories[currentIndex] || story.stories[0];

  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          if (currentIndex < story.stories.length - 1) {
            setCurrentIndex((i) => i + 1);
            return 0;
          } else {
            onClose();
            return 100;
          }
        }
        return prev + 2;
      }, 100);

      return () => clearInterval(interval);
    }, 100);
  }, [currentIndex, isPaused, story.stories.length, onClose]);

  const handleNext = () => {
    if (currentIndex < story.stories.length - 1) {
      setCurrentIndex((i) => i + 1);
      setProgress(0);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((i) => i - 1);
      setProgress(0);
    }
  };

  const handleToggleLike = () => {
    if (!isLiked) {
      setIsLiked(true);
      setLikesCount((c) => c + 1);
      setShowHeartBurst(true);
      setTimeout(() => setShowHeartBurst(false), 900);
    } else {
      setIsLiked(false);
      setLikesCount((c) => Math.max(0, c - 1));
    }
  };

  const handleQuickEmojiReaction = (emoji: string) => {
    setFloatingReaction(emoji);
    if (!isLiked) {
      setIsLiked(true);
      setLikesCount((c) => c + 1);
    }
    setTimeout(() => setFloatingReaction(null), 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col justify-between text-white select-none">
      {/* Floating Reaction Animation */}
      <AnimatePresence>
        {floatingReaction && (
          <motion.div
            initial={{ scale: 0.3, y: 100, opacity: 0 }}
            animate={{ scale: 1.8, y: -150, opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.9 }}
            className="absolute bottom-32 left-1/2 -translate-x-1/2 pointer-events-none z-50 text-6xl drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)]"
          >
            {floatingReaction}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Heart Burst Animation */}
      <AnimatePresence>
        {showHeartBurst && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 2.2, opacity: 1 }}
            exit={{ scale: 3, opacity: 0 }}
            transition={{ duration: 0.7 }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-50 text-rose-500 drop-shadow-2xl"
          >
            <Heart className="w-24 h-24 fill-rose-500 stroke-white stroke-2" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Media Slide */}
      <div
        onMouseDown={() => setIsPaused(true)}
        onMouseUp={() => setIsPaused(false)}
        onTouchStart={() => setIsPaused(true)}
        onTouchEnd={() => setIsPaused(false)}
        className="relative w-full h-full flex items-center justify-center bg-neutral-950 overflow-hidden"
      >
        <img
          src={currentSlide.mediaUrl}
          alt="Story"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />

        {/* Tap areas */}
        <div onClick={handlePrev} className="absolute left-0 top-0 bottom-0 w-1/3 z-10" />
        <div onClick={handleNext} className="absolute right-0 top-0 bottom-0 w-1/3 z-10" />

        {/* Header Overlay */}
        <div className="absolute top-0 left-0 right-0 p-4 pt-10 bg-gradient-to-b from-black/90 via-black/50 to-transparent z-20">
          {/* Progress Indicators Bar */}
          <div className="flex gap-1.5 mb-3">
            {story.stories.map((s, idx) => (
              <div key={s.id} className="flex-1 h-1.5 bg-white/25 rounded-full overflow-hidden backdrop-blur-md">
                <div
                  className="h-full bg-gradient-to-r from-amber-400 to-amber-200 transition-all duration-100 rounded-full shadow-sm"
                  style={{
                    width:
                      idx < currentIndex
                        ? '100%'
                        : idx === currentIndex
                        ? `${progress}%`
                        : '0%',
                  }}
                />
              </div>
            ))}
          </div>

          {/* User Profile Bar */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <img
                src={story.userAvatar}
                alt={story.username}
                className="w-10 h-10 rounded-full object-cover border-2 border-amber-400 shadow-lg"
                referrerPolicy="no-referrer"
              />
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-black text-white">{story.username}</span>
                  {story.verified && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
                  <span className="text-[10px] text-amber-400 font-bold bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/30">
                    القصة {currentIndex + 1}
                  </span>
                </div>
                <span className="text-[10px] text-neutral-300 font-medium block mt-0.5">
                  {currentSlide.timestamp || 'منذ ساعة'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-neutral-300 bg-black/50 px-2 py-1 rounded-full border border-white/10 flex items-center gap-1">
                <Eye className="w-3 h-3 text-amber-400" />
                <span>2.4k</span>
              </span>

              <button onClick={onClose} className="p-2 rounded-full bg-black/50 border border-white/15 backdrop-blur-md hover:bg-neutral-800 transition-colors">
                <X className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>
        </div>

        {/* Caption Overlay */}
        {currentSlide.caption && (
          <div className="absolute bottom-28 left-4 right-4 p-3.5 rounded-2xl bg-black/70 backdrop-blur-md border border-white/15 z-20 text-center text-xs font-bold leading-relaxed shadow-xl">
            {currentSlide.caption}
          </div>
        )}

        {/* Inline Fast Reactions Bar */}
        <div className="absolute bottom-20 left-4 right-4 flex items-center justify-center gap-3 z-30">
          {['❤️', '🔥', '👏', '🏋️', '👑', '🇧🇭'].map((emoji) => (
            <button
              key={emoji}
              onClick={() => handleQuickEmojiReaction(emoji)}
              className="w-9 h-9 rounded-full bg-black/60 backdrop-blur-md border border-white/20 hover:scale-125 hover:border-amber-400 transition-all flex items-center justify-center text-lg shadow-lg active:scale-95"
            >
              {emoji}
            </button>
          ))}
        </div>

        {/* Direct Inline Like & Reply Bar */}
        <div className="absolute bottom-4 left-4 right-4 flex items-center gap-2.5 z-30">
          <input
            type="text"
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
            placeholder={`الرد على قصة ${story.username}...`}
            className="flex-1 px-4 py-3 rounded-full bg-black/70 backdrop-blur-md border border-white/20 text-xs text-white placeholder-neutral-400 focus:outline-none focus:border-amber-400 shadow-inner"
          />

          {/* Direct Heart / Like Button */}
          <button
            onClick={handleToggleLike}
            className={`p-3 rounded-full backdrop-blur-md border transition-all flex items-center justify-center gap-1 shadow-lg active:scale-90 ${
              isLiked
                ? 'bg-rose-500/20 border-rose-500 text-rose-500'
                : 'bg-black/70 border-white/20 text-white hover:text-rose-400'
            }`}
          >
            <Heart className={`w-5 h-5 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
            {isLiked && <span className="text-[10px] font-black text-rose-400">{likesCount}</span>}
          </button>

          <button className="p-3 rounded-full bg-amber-400 text-black font-extrabold shadow-lg hover:bg-amber-300 transition-colors">
            <Send className="w-4 h-4 rtl:rotate-180" />
          </button>
        </div>
      </div>
    </div>
  );
};
