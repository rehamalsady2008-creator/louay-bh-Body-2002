import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { PostItem, UserProfile, CommentItem, NotificationItem, ChatThread, MessageItem } from '../types';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
  };
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
    },
    operationType,
    path
  };
  console.warn('Firestore Operation Notice: ', JSON.stringify(errInfo));
}

// User Profile Services
export async function syncUserProfileToFirestore(profile: UserProfile): Promise<void> {
  const path = `users/${profile.id}`;
  try {
    await setDoc(doc(db, 'users', profile.id), {
      ...profile,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function fetchUserProfileFromFirestore(userId: string): Promise<UserProfile | null> {
  const path = `users/${userId}`;
  try {
    const snap = await getDoc(doc(db, 'users', userId));
    if (snap.exists()) {
      return snap.data() as UserProfile;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
  return null;
}

// Posts Firestore Services
export async function fetchPostsFromFirestore(): Promise<PostItem[]> {
  const path = 'posts';
  try {
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(20));
    const snap = await getDocs(q);
    const posts: PostItem[] = [];
    snap.forEach((docSnap) => {
      posts.push({ id: docSnap.id, ...docSnap.data() } as PostItem);
    });
    return posts;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
    return [];
  }
}

export async function createPostInFirestore(post: PostItem): Promise<boolean> {
  const path = `posts/${post.id}`;
  try {
    await setDoc(doc(db, 'posts', post.id), {
      ...post,
      createdAt: new Date().toISOString()
    });
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
    return false;
  }
}

export async function updatePostLikesInFirestore(postId: string, newLikesCount: number, isLiked: boolean): Promise<void> {
  const path = `posts/${postId}`;
  try {
    await updateDoc(doc(db, 'posts', postId), {
      likesCount: newLikesCount
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

// Report Content
export async function createReportInFirestore(reporterId: string, targetType: 'post' | 'user', targetId: string, reason: string): Promise<boolean> {
  const path = 'reports';
  try {
    await addDoc(collection(db, 'reports'), {
      reporterId,
      targetType,
      targetId,
      reason,
      status: 'pending',
      createdAt: new Date().toISOString()
    });
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
    return false;
  }
}
