import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.bodybh.app',
  appName: 'BODY BH',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
