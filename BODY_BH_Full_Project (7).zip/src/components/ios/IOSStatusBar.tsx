import React, { useState, useEffect } from 'react';
import { Wifi, Battery, Radio, Sparkles, Crown, Play, Pause, X, ExternalLink, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface IOSStatusBarProps {
  activeNotification?: string | null;
  isLiveActive?: boolean;
}

export const IOSStatusBar: React.FC<IOSStatusBarProps> = () => {
  return null;
};
