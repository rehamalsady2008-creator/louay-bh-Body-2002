import React, { useState } from 'react';
import { 
  Search, 
  X, 
  CheckCircle2, 
  Users, 
  FileText, 
  ShoppingBag, 
  Dumbbell, 
  Sparkles, 
  TrendingUp, 
  ArrowUpLeft, 
  Eye,
  Heart,
  MessageCircle,
  Plus
} from 'lucide-react';
import { MOCK_USERS, MOCK_POSTS, MOCK_PRODUCTS } from '../../data/mockData';
import { ScreenType } from '../../types';
import { useLanguage } from '../../context/LanguageContext';

interface SearchScreenProps {
  onNavigate: (screen: ScreenType) => void;
}

export const SearchScreen: React.FC<SearchScreenProps> = ({ onNavigate }) => {
  const { t } = useLanguage();
  const [query, setQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'members' | 'posts'>('all');
  const [activeCategory, setActiveCategory] = useState('الكل');

  const categories = ['الكل', 'البحرين 🇧🇭', 'المجتمع 🤝', 'فعاليات 🎉', 'ثقافة وفنون 🎨', 'يوميات 📸'];

  // Real-time suggested searches & items matching query
  const matchingMembers = MOCK_USERS.filter(
    (u) =>
      u.name.toLowerCase().includes(query.toLowerCase()) ||
      u.username.toLowerCase().includes(query.toLowerCase()) ||
      (u.category && u.category.toLowerCase().includes(query.toLowerCase()))
  );

  const matchingPosts = MOCK_POSTS.filter(
    (p) =>
      p.caption.toLowerCase().includes(query.toLowerCase()) ||
      p.username.toLowerCase().includes(query.toLowerCase())
  );

  const totalResultsCount = matchingMembers.length + matchingPosts.length;

  return (
    <div className="min-h-screen bg-white text-slate-900 p-4 pt-12 pb-28 max-w-md mx-auto selection:bg-amber-400 selection:text-slate-900">
      {/* Search Header */}
      <div className="flex items-center justify-between mb-3">
        <h1 className="text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
          <span>البحث والياوزرات</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-300 font-bold">
            BODY BH 🇧🇭
          </span>
        </h1>
      </div>

      {/* Instant Real-Time Search Input Bar */}
      <div className="relative flex items-center mb-4">
        <Search className="w-4 h-4 text-amber-600 absolute left-3.5 rtl:right-3.5 rtl:left-auto pointer-events-none" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="ابحث عن مستخدمين، يوزرات، أصدقاء أو منشورات..."
          className="w-full pl-10 pr-10 rtl:pr-10 rtl:pl-10 py-3 rounded-2xl bg-slate-100 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500 shadow-xs"
        />
        {query ? (
          <button
            onClick={() => setQuery('')}
            className="absolute right-3 rtl:left-3 rtl:right-auto p-1.5 rounded-full bg-slate-200 text-slate-600 hover:text-slate-900 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        ) : null}
      </div>

      {/* Main Filter Tabs: (الكل | الحسابات | المنشورات) */}
      <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-2 mb-3">
        <button
          onClick={() => setActiveFilter('all')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-black shrink-0 transition-all ${
            activeFilter === 'all'
              ? 'bg-amber-400 text-slate-900 shadow-xs'
              : 'bg-slate-100 border border-slate-200 text-slate-600 hover:text-slate-900'
          }`}
        >
          الكل ({query ? totalResultsCount : MOCK_USERS.length + MOCK_POSTS.length})
        </button>

        <button
          onClick={() => setActiveFilter('members')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-black shrink-0 transition-all flex items-center gap-1.5 ${
            activeFilter === 'members'
              ? 'bg-amber-400 text-slate-900 shadow-xs'
              : 'bg-slate-100 border border-slate-200 text-slate-600 hover:text-slate-900'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>الحسابات واليوزرات ({matchingMembers.length})</span>
        </button>

        <button
          onClick={() => setActiveFilter('posts')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-black shrink-0 transition-all flex items-center gap-1.5 ${
            activeFilter === 'posts'
              ? 'bg-amber-400 text-slate-900 shadow-xs'
              : 'bg-slate-100 border border-slate-200 text-slate-600 hover:text-slate-900'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>المنشورات ({matchingPosts.length})</span>
        </button>
      </div>

      {/* Instant Suggested Live Results dropdown / view */}
      {query ? (
        <div className="space-y-6">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-black text-amber-700 uppercase tracking-wider flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>نتائج مقترحة فورية لكلمه: "{query}"</span>
            </span>
            <span className="text-[10px] font-bold text-slate-500">{totalResultsCount} نتيجة</span>
          </div>

          {/* Members Results */}
          {(activeFilter === 'all' || activeFilter === 'members') && matchingMembers.length > 0 && (
            <div className="space-y-2.5">
              <div className="text-[11px] font-black text-slate-500 flex items-center justify-between px-1">
                <span>الحسابات والأعضاء 👥</span>
                <span className="text-amber-700 text-[10px] cursor-pointer hover:underline font-bold" onClick={() => setActiveFilter('members')}>
                  عرض الجميع
                </span>
              </div>
              {matchingMembers.map((user) => (
                <div
                  key={user.id}
                  onClick={() => onNavigate('profile')}
                  className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-200 cursor-pointer hover:border-amber-400 transition-all shadow-xs group"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-11 h-11 rounded-full object-cover border border-amber-400"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-slate-900 group-hover:text-amber-700">@{user.username}</span>
                        {user.verified && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-500 shrink-0" />}
                      </div>
                      <span className="text-[11px] text-slate-500 block font-medium">{user.name}</span>
                    </div>
                  </div>
                  <button className="px-3 py-1 rounded-xl bg-slate-200 text-[11px] font-bold text-slate-900 hover:bg-amber-400 transition-colors">
                    زيارة الحساب
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Posts Results */}
          {(activeFilter === 'all' || activeFilter === 'posts') && matchingPosts.length > 0 && (
            <div className="space-y-2.5">
              <div className="text-[11px] font-black text-slate-500 flex items-center justify-between px-1">
                <span>المنشورات واليوميات 📱</span>
              </div>
              {matchingPosts.map((post) => (
                <div
                  key={post.id}
                  onClick={() => onNavigate('reels')}
                  className="p-3 rounded-2xl bg-slate-50 border border-slate-200 cursor-pointer hover:border-amber-400 transition-all shadow-xs flex gap-3 items-center"
                >
                  <img
                    src={post.mediaUrls?.[0] || post.userAvatar}
                    alt="Post"
                    className="w-14 h-14 rounded-xl object-cover shrink-0 border border-slate-200"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1 truncate">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="text-xs font-black text-slate-900">@{post.username}</span>
                    </div>
                    <p className="text-xs text-slate-700 truncate font-medium mb-1">{post.caption}</p>
                    <div className="flex items-center gap-3 text-[10px] text-slate-500 font-bold">
                      <span className="flex items-center gap-1 text-rose-500">
                        <Heart className="w-3 h-3 fill-rose-500/20" /> {post.likesCount}
                      </span>
                      <span className="flex items-center gap-1 text-amber-700">
                        <MessageCircle className="w-3 h-3" /> {post.commentsCount}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {totalResultsCount === 0 && (
            <div className="py-16 text-center border border-slate-200 rounded-3xl bg-slate-50 my-4 p-6">
              <Search className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <h3 className="text-sm font-black text-slate-900 mb-1">لم نجد نتائج لـ "{query}"</h3>
              <p className="text-xs text-slate-500 font-medium">جرب البحث بـ اليوزر، اسم الحساب أو الكلمات المفتاحية</p>
            </div>
          )}
        </div>
      ) : (
        /* Default Explore View with Bento Grid */
        <div className="space-y-5">
          {/* Quick Trending Searches */}
          <div>
            <div className="flex items-center gap-1.5 text-xs font-black text-slate-700 mb-2.5 px-1">
              <TrendingUp className="w-4 h-4 text-amber-600" />
              <span>الأكثر بحثاً في البحرين 🇧🇭</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {[
                'أخبار البحرين',
                'فعاليات المنامة',
                'المحرق',
                'خليج البحرين',
                'جامعة البحرين',
                'تواصل بحريني',
              ].map((term) => (
                <button
                  key={term}
                  onClick={() => setQuery(term)}
                  className="px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-xs text-slate-700 hover:border-amber-400 hover:text-slate-900 transition-colors flex items-center gap-1.5 font-bold shadow-xs"
                >
                  <span>{term}</span>
                  <ArrowUpLeft className="w-3 h-3 text-slate-400" />
                </button>
              ))}
            </div>
          </div>

          {/* Members Showcase */}
          <div>
            <div className="flex items-center justify-between text-xs font-black text-slate-900 mb-3 px-1">
              <span className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-amber-600" />
                <span>أبرز الحسابات واليوزرات</span>
              </span>
              <button onClick={() => setActiveFilter('members')} className="text-amber-700 text-[11px] font-extrabold hover:underline">
                عرض الكل
              </button>
            </div>

            <div className="flex gap-3 overflow-x-auto scrollbar-none pb-2">
              {MOCK_USERS.map((user) => (
                <div
                  key={user.id}
                  onClick={() => onNavigate('profile')}
                  className="w-32 p-3 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col items-center text-center shrink-0 hover:border-amber-400 cursor-pointer transition-all shadow-xs"
                >
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-amber-400 mb-2"
                    referrerPolicy="no-referrer"
                  />
                  <span className="text-xs font-black text-slate-900 truncate w-full">@{user.username}</span>
                  <span className="text-[10px] text-slate-500 truncate w-full mt-0.5 font-medium">{user.name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Explore Grid */}
          <div>
            <h3 className="text-xs font-black text-slate-900 mb-2.5 px-1">استكشف منشورات المجتمع</h3>
            <div className="grid grid-cols-3 gap-1 rounded-2xl overflow-hidden border border-slate-200">
              {MOCK_POSTS.map((post) => (
                <div
                  key={post.id}
                  onClick={() => onNavigate('reels')}
                  className="relative aspect-[3/4] bg-slate-100 overflow-hidden cursor-pointer group"
                >
                  <img
                    src={post.mediaUrls?.[0] || post.userAvatar}
                    alt="Explore Post"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-80" />
                  <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between text-[10px] text-white font-black">
                    <span className="flex items-center gap-1">
                      <Heart className="w-3 h-3 text-rose-400 fill-rose-400" /> {post.likesCount}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
