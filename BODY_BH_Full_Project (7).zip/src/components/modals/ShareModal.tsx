import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Copy, Check, Share2, Send, MessageSquare } from 'lucide-react';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  title = 'Share BODY BH Post',
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    navigator.clipboard?.writeText?.(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const shareTargets = [
    { name: 'Direct Message', icon: Send, color: 'bg-amber-400/20 text-amber-300' },
    { name: 'WhatsApp', icon: MessageSquare, color: 'bg-emerald-500/20 text-emerald-400' },
    { name: 'Instagram', icon: Share2, color: 'bg-pink-500/20 text-pink-400' },
    { name: 'Threads', icon: Share2, color: 'bg-neutral-800 text-white' },
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/60 backdrop-blur-md">
        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', stiffness: 380, damping: 32 }}
          className="w-full max-w-md bg-white border-t border-slate-200 rounded-t-[36px] p-6 text-slate-900 shadow-2xl relative select-none"
        >
          <div className="w-12 h-1.2 bg-slate-300 rounded-full mx-auto mb-4" />

          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <span className="text-sm font-black text-slate-900 tracking-tight">{title}</span>
            <button onClick={onClose} className="p-2 rounded-full bg-slate-100 border border-slate-200 text-slate-500 hover:text-slate-900 transition-colors">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-4 gap-3 my-6">
            {shareTargets.map((target) => {
              const Icon = target.icon;
              return (
                <button
                  key={target.name}
                  onClick={onClose}
                  className="flex flex-col items-center gap-2 p-2.5 rounded-3xl bg-slate-50 border border-slate-200 hover:border-amber-400/60 transition-colors shadow-xs"
                >
                  <div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${target.color} shadow-xs`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] text-slate-700 font-bold">{target.name}</span>
                </button>
              );
            })}
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between shadow-xs">
            <span className="text-xs text-slate-500 font-mono truncate pr-2">
              https://body.bh/p/82f1x9a
            </span>
            <button
              onClick={handleCopyLink}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-300 text-slate-900 text-xs font-black flex items-center gap-1.5 shrink-0 shadow-xs hover:brightness-105 active:scale-95 transition-all"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Link'}</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
