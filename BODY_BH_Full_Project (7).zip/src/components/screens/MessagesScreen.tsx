import React, { useState } from 'react';
import { Search, ChevronDown, CheckCircle2, Edit, Camera, MapPin, Sparkles, Plus } from 'lucide-react';
import { ChatThread, ScreenType, UserProfile } from '../../types';
import { MOCK_CHATS } from '../../data/mockData';
import { useLanguage } from '../../context/LanguageContext';

interface MessagesScreenProps {
  userProfile?: UserProfile;
  onSelectChat: (chat: ChatThread) => void;
  onNavigate: (screen: ScreenType) => void;
}

export const MessagesScreen: React.FC<MessagesScreenProps> = ({ userProfile, onSelectChat, onNavigate }) => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'primary' | 'general' | 'requests'>('primary');
  const [query, setQuery] = useState('');

  const notesList = [
    {
      id: 'note_me',
      username: 'قصتك / ملاحظتك',
      avatar: userProfile?.avatar || '/logo.jpg',
      note: 'أضف ملاحظة...',
      isMe: true,
    },
  ];

  const filteredChats = MOCK_CHATS.filter(
    (c) =>
      c.participant.name.toLowerCase().includes(query.toLowerCase()) ||
      c.participant.username.toLowerCase().includes(query.toLowerCase()) ||
      c.lastMessage.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-white text-slate-900 p-4 pt-12 pb-28 max-w-md mx-auto selection:bg-amber-400 selection:text-slate-900">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-1.5 cursor-pointer">
          <h1 className="text-lg font-black text-slate-900 tracking-tight">{userProfile?.username || 'user.bh'}</h1>
          <CheckCircle2 className="w-4 h-4 text-cyan-500" />
          <ChevronDown className="w-4 h-4 text-slate-400" />
        </div>

        <button className="p-2.5 rounded-full bg-slate-100 border border-slate-200 text-slate-700 hover:bg-slate-200 transition-colors shadow-xs">
          <Edit className="w-4 h-4" />
        </button>
      </div>

      {/* Meta AI Search Bar */}
      <div className="relative flex items-center mb-5">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 rtl:right-3.5 rtl:left-auto" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="البحث أو السؤال في Meta AI..."
          className="w-full pl-10 pr-4 rtl:pr-10 rtl:pl-4 py-2.5 rounded-2xl bg-slate-100 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-500 shadow-xs"
        />
      </div>

      {/* Notes Row */}
      <div className="mb-6 overflow-x-auto scrollbar-none flex items-start gap-4 py-1">
        {notesList.map((item) => (
          <div key={item.id} className="flex flex-col items-center gap-1.5 shrink-0 max-w-[84px] cursor-pointer group">
            <div className="relative">
              {/* Note Bubble */}
              <div className="bg-slate-100 border border-slate-200 px-2.5 py-1.5 rounded-2xl text-[9px] font-bold text-slate-800 max-w-[100px] truncate text-center shadow-xs -mb-2 z-10 relative group-hover:scale-105 transition-transform">
                {item.note}
              </div>

              {/* Avatar Circle */}
              <div className="relative w-16 h-16 rounded-full p-0.5 bg-slate-200 mx-auto mt-1 border border-slate-300">
                <img
                  src={item.avatar}
                  alt={item.username}
                  className="w-full h-full rounded-full object-cover border border-white"
                  referrerPolicy="no-referrer"
                />
                {item.isMe && (
                  <div className="absolute bottom-0 right-0 p-1 rounded-full bg-amber-400 text-slate-900 shadow-xs border border-white">
                    <Plus className="w-3 h-3 stroke-[3]" />
                  </div>
                )}
              </div>
            </div>

            <span className="text-[10px] font-bold text-slate-700 truncate text-center w-full mt-1">
              {item.username}
            </span>
          </div>
        ))}
      </div>

      {/* Messages / Requests Bar */}
      <div className="flex items-center justify-between mb-3 px-1">
        <span className="text-xs font-black text-slate-900 uppercase tracking-wider">{t('tabInbox')}</span>
        <button className="text-xs font-black text-amber-700 hover:underline"> الطلبات (0)</button>
      </div>

      {/* Chat List */}
      <div className="space-y-3">
        {filteredChats.length === 0 ? (
          <div className="py-16 text-center flex flex-col items-center justify-center border border-slate-200 rounded-3xl bg-slate-50 my-4">
            <div className="w-14 h-14 rounded-full bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-700 mb-3 shadow-xs">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-black text-slate-900 mb-1">لا توجد رسائل بعد</h3>
            <p className="text-[11px] text-slate-500 max-w-[220px] font-medium">
              ابدأ محادثة جديدة مع الأعضاء والمدربين في مجتمع BODY BH
            </p>
          </div>
        ) : (
          filteredChats.map((chat) => (
            <div
              key={chat.id}
              onClick={() => onSelectChat(chat)}
              className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 hover:border-amber-400 cursor-pointer flex items-center justify-between gap-3 transition-all shadow-xs hover:scale-[1.01]"
            >
              <div className="flex items-center gap-3.5 truncate">
                <div className="relative shrink-0">
                  <img
                    src={chat.participant.avatar}
                    alt={chat.participant.name}
                    className="w-13 h-13 rounded-full object-cover border border-amber-400"
                    referrerPolicy="no-referrer"
                  />
                  {chat.isOnline ? (
                    <span className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center">
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                    </span>
                  ) : (
                    <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-slate-400 border-2 border-white" />
                  )}
                </div>

                <div className="truncate">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-black text-slate-900 truncate">{chat.participant.name}</span>
                    {chat.participant.verified && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-500 shrink-0" />}
                    <span
                      className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded-md ${
                        chat.isOnline
                          ? 'bg-emerald-100 border border-emerald-300 text-emerald-800'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {chat.isOnline ? 'متصل الآن' : 'غير متصل'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 truncate font-medium mt-0.5">
                    {chat.lastMessage} • {chat.lastMessageTime}
                  </p>
                </div>
              </div>

              <button className="p-2.5 rounded-full text-slate-400 hover:text-slate-900 hover:bg-slate-200 transition-colors shrink-0">
                <Camera className="w-5 h-5" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

