import express from "express";
import path from "path";
import fs from "fs";
import JSZip from "jszip";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini AI
  const apiKey = process.env.GEMINI_API_KEY;
  let ai: GoogleGenAI | null = null;
  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }

  // API Endpoints
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", app: "BODY BH", time: new Date().toISOString() });
  });

  // Direct ZIP download of complete source code
  app.get("/api/download-zip", async (_req, res) => {
    try {
      const zip = new JSZip();
      const projectRoot = process.cwd();

      const addFilesRecursively = (dirPath: string, zipFolder: JSZip) => {
        const items = fs.readdirSync(dirPath);
        for (const item of items) {
          if (item === "node_modules" || item === "dist" || item === ".git" || item === ".cache") continue;
          const fullPath = path.join(dirPath, item);
          const stat = fs.statSync(fullPath);
          if (stat.isDirectory()) {
            addFilesRecursively(fullPath, zipFolder.folder(item)!);
          } else {
            const content = fs.readFileSync(fullPath);
            zipFolder.file(item, content);
          }
        }
      };

      addFilesRecursively(projectRoot, zip);

      const zipBuffer = await zip.generateAsync({ type: "nodebuffer" });
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", 'attachment; filename="BODY_BH_Full_Project.zip"');
      res.send(zipBuffer);
    } catch (err: any) {
      console.error("ZIP Generation error:", err);
      res.status(500).json({ error: "Failed to generate ZIP file" });
    }
  });

  // AI Caption Generator for BODY BH posts
  app.post("/api/ai/caption", async (req, res) => {
    try {
      const { topic, tone = "luxury fitness", hashtagCount = 5 } = req.body;
      
      if (!ai) {
        return res.json({
          caption: `Elevating standard fitness at BODY BH. ${topic || "Daily regimen"}. #BODYBH #Fitness #Luxury #Bahrain`,
          hashtags: ["#BODYBH", "#BHStyle", "#FitnessGoal", "#LuxuryLifestyle"]
        });
      }

      const prompt = `Write an engaging, ultra-stylish Instagram/Threads style social media caption for a high-end luxury fitness and social media app called BODY BH. Topic/Image description: "${topic || "workout & aesthetic lifestyle"}". Tone: ${tone}. Include ${hashtagCount} relevant viral hashtags. Return JSON format with "caption" and "hashtags" array.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json"
        }
      });

      const text = response.text || "{}";
      const data = JSON.parse(text);
      res.json(data);
    } catch (err: any) {
      console.error("AI Caption error:", err);
      res.json({
        caption: `Unstoppable energy with BODY BH. ${req.body.topic || "Pure dedication"}. 🔥✨`,
        hashtags: ["#BODYBH", "#VIP", "#FitnessCulture", "#BahrainStyle"]
      });
    }
  });

  // AI Smart Reply for DM Messages
  app.post("/api/ai/smart-reply", async (req, res) => {
    try {
      const { lastMessage, senderName } = req.body;
      if (!ai) {
        return res.json({
          suggestions: [
            "Sounds awesome! Let's hit the workout session 💥",
            "Thanks! Appreciate the support 🙌",
            "Check out my latest reel on BODY BH 🔥"
          ]
        });
      }

      const prompt = `Given the last direct message from user "${senderName}": "${lastMessage}". Suggest 3 short, modern, stylish iOS direct message quick replies suitable for a fitness/lifestyle creator on BODY BH. Return JSON array of strings under property "suggestions".`;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: { responseMimeType: "application/json" }
      });

      const data = JSON.parse(response.text || "{}");
      res.json(data);
    } catch (err: any) {
      res.json({
        suggestions: [
          "Let's go! 🔥",
          "Appreciate you brother 💪",
          "Send me the details on WhatsApp or DM!"
        ]
      });
    }
  });

  // Vite middleware for dev or static files for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`BODY BH Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
