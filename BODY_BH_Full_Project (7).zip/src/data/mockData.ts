import { UserProfile, PostItem, StoryItem, ReelItem, NotificationItem, ChatThread, AdminAnalytics, StoreProduct } from '../types';

export const CURRENT_USER: UserProfile = {
  id: 'user_me',
  name: 'عضو جديد',
  username: 'user.bh',
  avatar: '/logo.jpg',
  banner: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&q=80&w=1200',
  bio: 'مرحباً بك في حسابي الرسمي على منصة BODY BH 🇧🇭 | لياقة ومحتوى الرياضة في مملكة البحرين',
  category: 'عضو جديد 🇧🇭',
  verified: true,
  vipPlus: true,
  followersCount: 0,
  followingCount: 0,
  postsCount: 0,
  website: 'https://body.bh',
  location: 'المنامة، مملكة البحرين'
};

export const MOCK_USERS: UserProfile[] = [
  CURRENT_USER
];

export const MOCK_STORIES: StoryItem[] = [];

export const MOCK_POSTS: PostItem[] = [];

export const MOCK_REELS: ReelItem[] = [];

export const MOCK_NOTIFICATIONS: NotificationItem[] = [];

export const MOCK_CHATS: ChatThread[] = [];

export const MOCK_PRODUCTS: StoreProduct[] = [
  {
    id: 'p1',
    name: 'بروتين واي ايزوليت BODY BH 100% (2.2 كجم)',
    description: 'واي بروتين معزول سريع الامتصاص، خالي من السكر والمواد الحافظة، 27غ بروتين صافي لكل جرعة.',
    price: 24.9,
    originalPrice: 29.9,
    category: 'supplements',
    categoryLabel: 'مكملات وتغذية',
    image: 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?auto=format&fit=crop&q=80&w=800',
    rating: 4.9,
    reviewsCount: 142,
    inStock: true,
    isPopular: true,
  },
  {
    id: 'p2',
    name: 'تيشيرت BODY BH الرياضي - إصدار المحترفين',
    description: 'قميص رياضي فاخر بخامة خفيفة مبردة تمنع التعرق ومناسبة للتمارين القاسية وشعار التطبيق المطرز.',
    price: 12.5,
    originalPrice: 15.0,
    category: 'apparel',
    categoryLabel: 'ملابس رياضية',
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=800',
    rating: 4.8,
    reviewsCount: 98,
    inStock: true,
    isNew: true,
  },
  {
    id: 'p3',
    name: 'حزام رفع الأوزان الجلدي الأصلي BODY BH',
    description: 'حزام يدعم أسفل الظهر أثناء التمارين والأوزان الثقيلة، مصنوع من الجلد الطبيعي الممتاز 100%.',
    price: 18.0,
    originalPrice: 22.0,
    category: 'equipment',
    categoryLabel: 'معدات تمارين',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&q=80&w=800',
    rating: 5.0,
    reviewsCount: 76,
    inStock: true,
    isPopular: true,
  },
  {
    id: 'p4',
    name: 'كرياتين مونوهيدرات الصافي (500 جرام)',
    description: 'زيادة القوة والجهد العضلي وضخامة العضلات، كرياتين دقيق الذرات سريع الذوبان والامتصاص.',
    price: 14.9,
    originalPrice: 17.5,
    category: 'supplements',
    categoryLabel: 'مكملات وتغذية',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=800',
    rating: 4.9,
    reviewsCount: 210,
    inStock: true,
  },
  {
    id: 'p5',
    name: 'عضوية البحرين المجانية الكاملة (0 د.ب)',
    description: 'تم إلغاء كافة الاشتراكات! احصل مجاناً على مدرب الذكاء الاصطناعي، رفع دقة 4K، والتفاعل مع مجتمع البحرين.',
    price: 0.0,
    originalPrice: 0.0,
    category: 'free_perks',
    categoryLabel: 'مميزات مجانية 🇧🇭',
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=800',
    rating: 5.0,
    reviewsCount: 320,
    inStock: true,
    isPopular: true,
  },
];

export const MOCK_ADMIN_STATS: AdminAnalytics = {
  totalUsers: 1,
  monthlyRevenue: 0,
  activeLiveStreams: 0,
  reportedPostsCount: 0,
  dailyActiveUsers: [0, 0, 0, 0, 0, 0, 1],
  revenueData: [0, 0, 0, 0, 0, 0, 0]
};
