import React, { useState } from 'react';
import { ArrowLeft, Search, CheckCircle2, ArrowUpDown, X, UserX, Users, ShieldAlert, UserPlus } from 'lucide-react';
import { ScreenType } from '../../types';
import { useLanguage } from '../../context/LanguageContext';

interface FollowersListScreenProps {
  initialTab?: 'followers' | 'following';
  followersCount?: number;
  followingCount?: number;
  onBack: () => void;
  onNavigate: (screen: ScreenType) => void;
}

interface FollowUserItem {
  id: string;
  name: string;
  username: string;
  avatar: string;
  isFollowing: boolean;
  badge?: string;
  isOnline?: boolean;
  lastActive?: string;
}

export const FollowersListScreen: React.FC<FollowersListScreenProps> = ({
  initialTab = 'followers',
  followersCount = 0,
  followingCount = 0,
  onBack,
  onNavigate,
}) => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'followers' | 'following' | 'subscriptions' | 'flagged'>(
    initialTab === 'following' ? 'following' : 'followers'
  );
  const [searchQuery, setSearchQuery] = useState('');

  const followersList: FollowUserItem[] = [
    {
      id: 'f1',
      name: 'الكابتن محمد البستكي',
      username: 'bastaki.fit',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      isFollowing: true,
      badge: 'مدرب محترف 🇧🇭',
      isOnline: true,
      lastActive: 'متصل الآن',
    },
    {
      id: 'f2',
      name: 'زينب العالي (كالستثنيكس)',
      username: 'zainab_cali',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
      isFollowing: true,
      badge: 'بطلة البحرين',
      isOnline: false,
      lastActive: 'نشط منذ 20د',
    },
    {
      id: 'f3',
      name: 'عبدالله بوعلاي',
      username: 'bouallay_pro',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      isFollowing: false,
      isOnline: true,
      lastActive: 'متصل الآن',
    },
    {
      id: 'f4',
      name: 'مريم سلمان',
      username: 'maryam.yoga',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      isFollowing: true,
      badge: 'يوغا وبيلاتس',
      isOnline: false,
      lastActive: 'نشط أمس',
    },
  ];

  const followingList: FollowUserItem[] = [
    {
      id: 'fg1',
      name: 'فيتنس جيم البحرين 🇧🇭',
      username: 'fitnessfirst_bh',
      avatar: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=150',
      isFollowing: true,
      badge: 'VIP موثق',
      isOnline: true,
      lastActive: 'متصل الآن',
    },
    {
      id: 'fg2',
      name: 'خالد الجاسم',
      username: 'khaled_jassim',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
      isFollowing: true,
      isOnline: false,
      lastActive: 'نشط منذ ساعة',
    },
  ];

  const currentList = activeTab === 'following' ? followingList : followersList;

  const filteredList = currentList.filter(
    (item) =>
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-white text-slate-900 p-4 pt-12 pb-24 max-w-md mx-auto selection:bg-amber-400 selection:text-slate-900">
      {/* Top Header */}
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-200">
        <button onClick={onBack} className="p-2 text-slate-700 hover:text-slate-900 transition-colors">
          <ArrowLeft className="w-5 h-5 rtl:rotate-180" />
        </button>
        <span className="text-sm font-black text-slate-900 tracking-tight">قائمة المتابعة 🇧🇭</span>
        <div className="w-8" />
      </div>

      {/* Tabs Row */}
      <div className="flex border-b border-slate-200 mb-4 text-xs font-bold">
        <button
          onClick={() => setActiveTab('followers')}
          className={`flex-1 py-2.5 text-center transition-colors relative ${
            activeTab === 'followers' ? 'text-slate-900 font-black' : 'text-slate-500'
          }`}
        >
          {followersCount} {t('followers')}
          {activeTab === 'followers' && (
            <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-400 rounded-full" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('following')}
          className={`flex-1 py-2.5 text-center transition-colors relative ${
            activeTab === 'following' ? 'text-slate-900 font-black' : 'text-slate-500'
          }`}
        >
          {followingCount} {t('followingCount')}
          {activeTab === 'following' && (
            <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-400 rounded-full" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('subscriptions')}
          className={`flex-1 py-2.5 text-center transition-colors relative ${
            activeTab === 'subscriptions' ? 'text-slate-900 font-black' : 'text-slate-500'
          }`}
        >
          VIP الاشتراكات
          {activeTab === 'subscriptions' && (
            <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-400 rounded-full" />
          )}
        </button>
      </div>

      {/* Search Input */}
      <div className="relative flex items-center mb-4">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 rtl:right-3.5 rtl:left-auto" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="ابحث عن اسم المستخدم أو الحساب..."
          className="w-full pl-10 pr-4 rtl:pr-10 rtl:pl-4 py-2.5 rounded-2xl bg-slate-100 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-400 shadow-xs"
        />
      </div>

      {activeTab === 'subscriptions' ? (
        <div className="text-center py-12 px-4 rounded-3xl bg-slate-50 border border-slate-200">
          <p className="text-sm font-black text-slate-900">الاشتراكات الحصرية والخاصة</p>
          <p className="text-xs text-slate-500 mt-1">اشترك مع كبار مدربي البحرين للحصول على محتوى خاص ومحادثات شخصية.</p>
        </div>
      ) : filteredList.length === 0 ? (
        <div className="text-center py-16 px-6 rounded-3xl bg-slate-50 border border-slate-200 my-4 flex flex-col items-center justify-center shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 mb-3 shadow-xs">
            <UserPlus className="w-8 h-8" />
          </div>
          <h3 className="text-sm font-black text-slate-900 mb-1">
            {activeTab === 'followers' ? 'لا يوجد متابعون بعد 🇧🇭' : 'لا تتابع أحداً بعد 🇧🇭'}
          </h3>
          <p className="text-xs text-slate-500 max-w-xs mb-5 leading-relaxed">
            {activeTab === 'followers'
              ? 'حسابك جديد كلياً! شارك منشوراتك ورابط حسابك للبدء بجذب المتابعين.'
              : 'استكشف المبدعين والمدربين الأفضل في البحرين واضغط متابعة لتظهر منشوراتهم هنا.'}
          </p>
          <button
            onClick={() => onNavigate('search')}
            className="px-6 py-2.5 rounded-full bg-gradient-to-r from-amber-400 via-amber-400 to-amber-300 text-slate-900 font-extrabold text-xs flex items-center gap-2 shadow-sm hover:brightness-105 active:scale-95 transition-all"
          >
            <Search className="w-4 h-4" />
            <span>استكشاف الحسابات والمدربين</span>
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredList.map((user) => (
            <div
              key={user.id}
              className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-200 hover:border-slate-300 transition-colors shadow-xs"
            >
              <div className="flex items-center gap-3">
                <div className="relative shrink-0">
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-11 h-11 rounded-full object-cover border border-amber-400 shadow-xs"
                    referrerPolicy="no-referrer"
                  />
                  {user.isOnline ? (
                    <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center">
                      <span className="w-1 h-1 rounded-full bg-white animate-pulse" />
                    </span>
                  ) : (
                    <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-slate-300 border-2 border-white" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-black text-slate-900">@{user.username}</span>
                    {user.badge && (
                      <span className="text-[9px] font-black text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                        {user.badge}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[11px] text-slate-600 font-medium">{user.name}</span>
                    <span
                      className={`text-[9px] font-bold ${
                        user.isOnline ? 'text-emerald-600' : 'text-slate-400'
                      }`}
                    >
                      • {user.lastActive || (user.isOnline ? 'متصل الآن' : 'غير متصل')}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => onNavigate('messages')}
                className="px-3.5 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-xs font-bold text-slate-700 hover:text-slate-900 hover:bg-slate-200 transition-colors"
              >
                مراسلة
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
