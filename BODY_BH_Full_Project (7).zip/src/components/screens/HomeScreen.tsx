import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  CheckCircle2,
  Crown,
  Bell,
  Search,
  Compass,
  ShoppingBag,
  Sparkles,
  Volume2,
  VolumeX,
  MoreHorizontal,
  Disc,
  MapPin,
  ChevronRight,
  Send,
  Plus,
  RefreshCw,
  Hash,
  TrendingUp,
  UserPlus
} from 'lucide-react';
import { PostItem, StoryItem, ScreenType, UserProfile } from '../../types';
import { MOCK_POSTS, MOCK_STORIES } from '../../data/mockData';
import { CommentsModal } from '../modals/CommentsModal';
import { ShareModal } from '../modals/ShareModal';
import { useLanguage } from '../../context/LanguageContext';
import logoImg from '../../assets/images/body_bh_logo_1785281238621.jpg';

interface HomeScreenProps {
  userProfile?: UserProfile;
  onNavigate: (screen: ScreenType) => void;
  onOpenStory: (story: StoryItem) => void;
  onOpenLiveStream: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  userProfile,
  onNavigate,
  onOpenStory,
  onOpenLiveStream,
}) => {
  const { t, isRTL } = useLanguage();
  const [posts, setPosts] = useState<PostItem[]>(MOCK_POSTS);
  const [mutedPosts, setMutedPosts] = useState<{ [key: string]: boolean }>({});
  const [carouselIndexes, setCarouselIndexes] = useState<{ [key: string]: number }>({});
  const [heartParticles, setHeartParticles] = useState<{ id: number; x: number; y: number }[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedHashtag, setSelectedHashtag] = useState<string>('الكل');

  // Suggested Athletes to Follow (Instagram/Threads suggestion tray)
  const [suggestedUsers, setSuggestedUsers] = useState([
    { id: 's1', name: 'المدرب طارق 🏋️', username: 'tariq_coach', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400', followed: false },
    { id: 's2', name: 'أحمد البحريني 🇧🇭', username: 'ahmed_fit', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400', followed: false },
    { id: 's3', name: 'سارة الرياضية 🌸', username: 'sara.bodybh', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=400', followed: false },
  ]);

  const hashtagsList = ['الكل', 'البحرين', 'يوميات_بحرينية', 'أحداث_البحرين', 'فعاليات', 'BODY_BH'];

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 1000);
  };

  const toggleFollowSuggested = (id: string) => {
    setSuggestedUsers((prev) =>
      prev.map((u) => (u.id === id ? { ...u, followed: !u.followed } : u))
    );
  };

  // Modals state
  const [selectedCommentsPost, setSelectedCommentsPost] = useState<PostItem | null>(null);
  const [isShareOpen, setIsShareOpen] = useState(false);

  const toggleLike = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          return {
            ...p,
            isLiked: !p.isLiked,
            likesCount: p.isLiked ? p.likesCount - 1 : p.likesCount + 1,
          };
        }
        return p;
      })
    );
  };

  const handleDoubleTap = (e: React.MouseEvent, postId: string) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const newParticle = { id: Date.now(), x, y };
    setHeartParticles((prev) => [...prev, newParticle]);

    setTimeout(() => {
      setHeartParticles((prev) => prev.filter((p) => p.id !== newParticle.id));
    }, 900);

    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId && !p.isLiked) {
          return { ...p, isLiked: true, likesCount: p.likesCount + 1 };
        }
        return p;
      })
    );
  };

  const toggleBookmark = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, isSaved: !p.isSaved } : p))
    );
  };

  const handleAddComment = (text: string) => {
    if (!selectedCommentsPost) return;
    const newCommentObj = {
      id: `c_${Date.now()}`,
      userId: 'user_me',
      username: 'tariq.bh',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=800',
      verified: true,
      text,
      timeAgo: 'Just now',
      likesCount: 0,
    };
    setPosts((prev) =>
      prev.map((p) =>
        p.id === selectedCommentsPost.id
          ? {
              ...p,
              commentsCount: p.commentsCount + 1,
              comments: [newCommentObj, ...p.comments],
            }
          : p
      )
    );
    setSelectedCommentsPost((prev) =>
      prev ? { ...prev, commentsCount: prev.commentsCount + 1, comments: [newCommentObj, ...prev.comments] } : null
    );
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 pb-28 pt-0 selection:bg-amber-400 selection:text-slate-900">
      {/* Top Header */}
      <header className="sticky top-0 z-30 px-4 py-3 flex items-center justify-between bg-white/95 backdrop-blur-2xl border-b border-slate-200 shadow-xs">
        <div className="flex items-center gap-2.5">
          <img 
            src={logoImg} 
            alt="Body Bh Logo" 
            onError={(e) => { e.currentTarget.src = '/logo.jpg'; }}
            className="w-9 h-9 rounded-xl object-cover border border-amber-400/60 shadow-xs"
          />
          <div>
            <h1 className="font-black tracking-tight text-xl text-transparent bg-clip-text bg-gradient-to-r from-slate-900 via-slate-800 to-amber-700">
              BODY BH
            </h1>
            <p className="text-[9px] text-amber-700 font-bold tracking-wider uppercase -mt-0.5">
              Kingdom of Bahrain 🇧🇭
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRefresh}
            title="تحديث الخلاصات"
            className="p-2.5 rounded-full bg-slate-100 border border-slate-200 text-amber-700 hover:text-slate-900 hover:bg-slate-200 transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={() => onNavigate('search')}
            className="p-2.5 rounded-full bg-slate-100 border border-slate-200 text-slate-700 hover:text-slate-900 hover:bg-slate-200 transition-colors"
          >
            <Search className="w-4 h-4" />
          </button>

          <button
            onClick={() => onNavigate('messages')}
            className="relative p-2.5 rounded-full bg-slate-100 border border-slate-200 text-slate-700 hover:text-slate-900 hover:bg-slate-200 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Hashtag Filters */}
      <div className="px-4 py-2 bg-slate-50 border-b border-slate-200 flex items-center gap-2 overflow-x-auto scrollbar-none">
        {hashtagsList.map((tag) => (
          <button
            key={tag}
            onClick={() => setSelectedHashtag(tag)}
            className={`px-3 py-1 rounded-full text-[11px] font-extrabold whitespace-nowrap transition-all border ${
              selectedHashtag === tag
                ? 'bg-amber-400 text-slate-900 border-amber-400 shadow-xs font-black'
                : 'bg-white text-slate-600 border-slate-200 hover:text-slate-900'
            }`}
          >
            {tag === 'الكل' ? 'الكل 🌐' : `#${tag}`}
          </button>
        ))}
      </div>

      {/* Stories Tray */}
      <div className="px-4 py-3.5 border-b border-slate-200 bg-slate-50/70 overflow-x-auto scrollbar-none flex items-center gap-4">
        <button
          onClick={() => onNavigate('create-post')}
          className="flex flex-col items-center gap-1.5 shrink-0 group focus:outline-none"
        >
          <div className="relative p-0.5 rounded-full bg-slate-200 border border-slate-300">
            <img
              src={userProfile?.avatar || logoImg}
              alt="Your Story"
              onError={(e) => { e.currentTarget.src = logoImg; }}
              className="w-14 h-14 rounded-full object-cover border-2 border-white group-hover:scale-105 transition-transform"
            />
            <div className="absolute bottom-0 right-0 w-5 h-5 rounded-full bg-amber-400 border-2 border-white text-slate-900 flex items-center justify-center text-xs font-black shadow-xs">
              +
            </div>
          </div>
          <span className="text-[11px] font-bold text-slate-700 truncate max-w-[68px]">
            قصتك
          </span>
        </button>

        {MOCK_STORIES.map((story) => (
          <button
            key={story.id}
            onClick={() => onOpenStory(story)}
            className="flex flex-col items-center gap-1.5 shrink-0 group focus:outline-none"
          >
            <div
              className={`relative p-0.5 rounded-full ${
                story.hasUnseen
                  ? 'bg-gradient-to-tr from-amber-400 via-rose-500 to-purple-600 shadow-xs animate-pulse'
                  : 'bg-slate-200 border border-slate-300'
              }`}
            >
              <img
                src={story.userAvatar}
                alt={story.username}
                className="w-14 h-14 rounded-full object-cover border-2 border-white group-hover:scale-105 transition-transform"
                referrerPolicy="no-referrer"
              />
            </div>
            <span className="text-[11px] font-bold text-slate-700 truncate max-w-[68px]">
              {story.username}
            </span>
          </button>
        ))}
      </div>

      {/* Main Feed Posts */}
      <div className="max-w-md mx-auto space-y-7 pt-4 px-3">
        {posts.length === 0 ? (
          <div className="py-16 px-6 text-center flex flex-col items-center justify-center bg-slate-50 border border-slate-200 rounded-3xl my-4">
            <div className="w-16 h-16 rounded-2xl bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-700 mb-4 shadow-xs">
              <Sparkles className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-black text-slate-900 mb-2">لا توجد منشورات بعد</h3>
            <p className="text-xs text-slate-600 max-w-xs mb-6 leading-relaxed font-medium">
              مرحباً بك في منصة BODY BH! 🇧🇭<br />كن أول من ينشر محتوى رياضياً واجتماعياً في البحرين.
            </p>
            <button
              onClick={() => onNavigate('create-post')}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-300 text-slate-900 font-black text-xs shadow-md hover:scale-105 transition-all flex items-center gap-2"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>إنشاء منشور جديد</span>
            </button>
          </div>
        ) : (
          posts.map((post) => {
          const currentImgIndex = carouselIndexes[post.id] || 0;
          return (
            <article
              key={post.id}
              className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm"
            >
              {/* Post Header */}
              <div className="p-3.5 flex items-center justify-between border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <img
                      src={post.userAvatar}
                      alt={post.username}
                      className="w-10 h-10 rounded-full object-cover border border-amber-400/40"
                      referrerPolicy="no-referrer"
                    />
                    {post.vipPlus && (
                      <div className="absolute -bottom-1 -right-1 bg-amber-400 text-slate-900 p-0.5 rounded-full shadow-xs">
                        <Crown className="w-2.5 h-2.5" />
                      </div>
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-black text-slate-900 hover:underline cursor-pointer tracking-tight">
                        {post.username}
                      </span>
                      {post.verified && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-500 shrink-0" />}
                      {post.vipPlus && (
                        <span className="bg-amber-100 text-amber-800 border border-amber-300 px-1.5 py-0.2 text-[9px] font-black rounded-full">
                          VIP+
                        </span>
                      )}
                    </div>
                    {post.location && (
                      <div className="flex items-center gap-1 text-[10px] text-slate-500 font-medium">
                        <MapPin className="w-2.5 h-2.5 text-amber-600 shrink-0" />
                        <span className="truncate max-w-[180px]">{post.location}</span>
                      </div>
                    )}
                  </div>
                </div>

                <button className="p-2 text-slate-400 hover:text-slate-900 rounded-full hover:bg-slate-100 transition-colors">
                  <MoreHorizontal className="w-4 h-4" />
                </button>
              </div>

              {/* Post Media Container */}
              <div
                onDoubleClick={(e) => handleDoubleTap(e, post.id)}
                className="relative w-full aspect-square bg-slate-100 overflow-hidden cursor-pointer select-none group"
              >
                <img
                  src={post.mediaUrls[currentImgIndex]}
                  alt={post.caption}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.02]"
                  referrerPolicy="no-referrer"
                />

                {/* Multi-photo carousel indicator pills */}
                {post.mediaUrls.length > 1 && (
                  <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-slate-900/80 backdrop-blur-md border border-slate-700 text-[10px] font-bold text-white shadow-md">
                    {currentImgIndex + 1} / {post.mediaUrls.length}
                  </div>
                )}

                {/* Next/Prev Carousel Buttons */}
                {post.mediaUrls.length > 1 && (
                  <div className="absolute inset-y-0 inset-x-2 flex items-center justify-between pointer-events-none">
                    {currentImgIndex > 0 ? (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setCarouselIndexes((prev) => ({ ...prev, [post.id]: currentImgIndex - 1 }));
                        }}
                        className="pointer-events-auto p-1.5 rounded-full bg-white/80 text-slate-900 backdrop-blur-md border border-slate-200 hover:scale-110 transition-transform shadow-xs"
                      >
                        <ChevronRight className="w-4 h-4 rotate-180" />
                      </button>
                    ) : (
                      <div />
                    )}

                    {currentImgIndex < post.mediaUrls.length - 1 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setCarouselIndexes((prev) => ({ ...prev, [post.id]: currentImgIndex + 1 }));
                        }}
                        className="pointer-events-auto p-1.5 rounded-full bg-white/80 text-slate-900 backdrop-blur-md border border-slate-200 hover:scale-110 transition-transform shadow-xs"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                )}

                {/* Sound toggle overlay */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setMutedPosts((prev) => ({ ...prev, [post.id]: !prev[post.id] }));
                  }}
                  className="absolute bottom-3 right-3 p-2 rounded-full bg-slate-900/70 backdrop-blur-md text-white border border-slate-700 hover:bg-slate-900 transition-colors shadow-md"
                >
                  {mutedPosts[post.id] ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                </button>

                {/* Animated Particle Hearts on Double Tap */}
                <AnimatePresence>
                  {heartParticles.map((particle) => (
                    <motion.div
                      key={particle.id}
                      initial={{ scale: 0.2, opacity: 0, y: 0 }}
                      animate={{ scale: 1.3, opacity: 1, y: -40 }}
                      exit={{ scale: 0.2, opacity: 0, y: -80 }}
                      style={{ left: particle.x - 48, top: particle.y - 48 }}
                      className="absolute pointer-events-none z-30"
                    >
                      <Heart className="w-24 h-24 text-rose-500 fill-rose-500 drop-shadow-[0_0_35px_rgba(244,63,94,0.9)]" />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {/* Post Actions Bar */}
              <div className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => toggleLike(post.id)}
                      className="flex items-center gap-1.5 active:scale-125 transition-transform"
                    >
                      <Heart
                        className={`w-6 h-6 transition-colors ${
                          post.isLiked ? 'text-rose-500 fill-rose-500' : 'text-slate-700 hover:text-slate-900'
                        }`}
                      />
                    </button>

                    <button
                      onClick={() => setSelectedCommentsPost(post)}
                      className="flex items-center gap-1.5 text-slate-700 hover:text-slate-900 transition-colors"
                    >
                      <MessageCircle className="w-6 h-6" />
                    </button>

                    <button
                      onClick={() => setIsShareOpen(true)}
                      className="flex items-center gap-1.5 text-slate-700 hover:text-slate-900 transition-colors"
                    >
                      <Share2 className="w-6 h-6" />
                    </button>
                  </div>

                  {/* Carousel pagination dots */}
                  {post.mediaUrls.length > 1 && (
                    <div className="flex items-center gap-1">
                      {post.mediaUrls.map((_, i) => (
                        <div
                          key={i}
                          className={`w-1.5 h-1.5 rounded-full transition-all ${
                            i === currentImgIndex ? 'w-4 bg-amber-500' : 'bg-slate-300'
                          }`}
                        />
                      ))}
                    </div>
                  )}

                  <button
                    onClick={() => toggleBookmark(post.id)}
                    className="text-slate-700 hover:text-slate-900 active:scale-110 transition-transform"
                  >
                    <Bookmark className={`w-6 h-6 ${post.isSaved ? 'text-amber-500 fill-amber-500' : ''}`} />
                  </button>
                </div>

                {/* Likes Count */}
                <div className="text-xs font-black text-slate-900 mb-1.5 tracking-tight">
                  {post.likesCount.toLocaleString()} {t('likedBy')}
                </div>

                {/* Caption */}
                <p className="text-xs text-slate-800 leading-relaxed mb-2.5 font-medium">
                  <span className="font-black text-slate-900 ml-1 mr-1">{post.username}</span>
                  {post.caption}
                </p>

                {/* Audio track pill */}
                {post.audioTrack && (
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-[11px] text-amber-800 font-bold mb-3 w-fit">
                    <Disc className="w-3.5 h-3.5 text-amber-600 animate-spin" style={{ animationDuration: '4s' }} />
                    <span className="truncate max-w-[240px]">{post.audioTrack}</span>
                  </div>
                )}

                {/* Comments trigger */}
                <button
                  onClick={() => setSelectedCommentsPost(post)}
                  className="text-xs text-slate-500 font-bold hover:text-slate-900 transition-colors"
                >
                  {t('viewComments')} ({post.commentsCount})
                </button>

                <div className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider font-bold">
                  {post.timeAgo}
                </div>
              </div>
            </article>
          );
        }))}
      </div>

      {/* Modals */}
      {selectedCommentsPost && (
        <CommentsModal
          isOpen={!!selectedCommentsPost}
          onClose={() => setSelectedCommentsPost(null)}
          comments={selectedCommentsPost.comments}
          onAddComment={handleAddComment}
        />
      )}

      <ShareModal isOpen={isShareOpen} onClose={() => setIsShareOpen(false)} />
    </div>
  );
};
