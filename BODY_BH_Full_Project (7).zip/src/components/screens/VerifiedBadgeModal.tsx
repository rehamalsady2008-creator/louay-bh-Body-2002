import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, Shield, Upload, FileText, Check } from 'lucide-react';

interface VerifiedBadgeModalProps {
  onBack: () => void;
}

export const VerifiedBadgeModal: React.FC<VerifiedBadgeModalProps> = ({ onBack }) => {
  const [legalName, setLegalName] = useState('Tariq Al-Mansoori');
  const [idUploaded, setIdUploaded] = useState(true);

  return (
    <div className="min-h-screen bg-black text-white p-4 pt-12 pb-28 max-w-md mx-auto selection:bg-amber-400 selection:text-black">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <button onClick={onBack} className="p-2.5 rounded-full bg-neutral-900 border border-white/10 text-neutral-300 hover:text-white transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="text-xs font-black text-cyan-400 uppercase tracking-widest">Verification Center</span>
        <div className="w-8" />
      </div>

      {/* Hero Badge Status */}
      <div className="p-6 rounded-3xl bg-neutral-900/90 border border-cyan-400/40 text-center mb-6 shadow-2xl">
        <div className="w-18 h-18 rounded-full bg-cyan-400/20 text-cyan-400 border border-cyan-400/50 flex items-center justify-center mx-auto mb-3 shadow-[0_0_35px_rgba(6,182,212,0.4)] animate-pulse">
          <CheckCircle2 className="w-9 h-9" />
        </div>
        <h2 className="text-xl font-black text-white tracking-tight">Verified Account Badge</h2>
        <p className="text-xs text-neutral-300 mt-1.5 max-w-xs mx-auto leading-relaxed font-medium">
          Confirms authenticity for recognized Bahrain creators, fitness ambassadors, and public figures.
        </p>

        <div className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 font-black text-xs mt-4 shadow-md">
          <Shield className="w-4 h-4" />
          <span>STATUS: APPROVED & ACTIVE</span>
        </div>
      </div>

      {/* Verification Details */}
      <div className="space-y-4 bg-neutral-900/80 border border-white/10 rounded-3xl p-5 shadow-xl">
        <div>
          <label className="text-[11px] font-black text-neutral-400 uppercase tracking-wider block mb-1">Legal Full Name</label>
          <input
            type="text"
            value={legalName}
            onChange={(e) => setLegalName(e.target.value)}
            className="w-full px-3.5 py-3 rounded-2xl bg-black/70 border border-white/10 text-xs text-white font-semibold shadow-inner"
          />
        </div>

        <div>
          <label className="text-[11px] font-black text-neutral-400 uppercase tracking-wider block mb-1">Identity Verification Document</label>
          <div className="p-4 rounded-2xl bg-black/70 border border-white/10 flex items-center justify-between shadow-inner">
            <div className="flex items-center gap-2.5 text-xs font-extrabold text-neutral-200">
              <FileText className="w-4 h-4 text-cyan-400" />
              <span>Bahrain_CPR_Identity.pdf</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-black bg-emerald-500/20 px-2.5 py-1 rounded-full border border-emerald-500/30">
              Verified
            </span>
          </div>
        </div>

        <button
          onClick={onBack}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-cyan-400 to-cyan-300 text-black font-black text-xs shadow-lg hover:brightness-110 active:scale-95 transition-all mt-2"
        >
          DONE
        </button>
      </div>
    </div>
  );
};
