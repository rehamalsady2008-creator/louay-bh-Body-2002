import React, { createContext, useContext, useState, useEffect } from 'react';

export type ThemeMode = 'light' | 'dark' | 'night' | 'system';

interface ThemeContextType {
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  activeTheme: 'light' | 'dark' | 'night';
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [themeMode, setThemeModeState] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('bodybh_theme_mode');
    return (saved as ThemeMode) || 'light';
  });

  const [activeTheme, setActiveTheme] = useState<'light' | 'dark' | 'night'>('light');

  const setThemeMode = (mode: ThemeMode) => {
    setThemeModeState(mode);
    localStorage.setItem('bodybh_theme_mode', mode);
  };

  useEffect(() => {
    const updateTheme = () => {
      let computed: 'light' | 'dark' | 'night' = 'light';

      if (themeMode === 'system') {
        const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        computed = prefersDark ? 'dark' : 'light';
      } else {
        computed = themeMode;
      }

      setActiveTheme(computed);

      const root = document.documentElement;
      const body = document.body;

      const classesToRemove = ['theme-light', 'theme-dark', 'theme-night', 'dark'];
      root.classList.remove(...classesToRemove);
      if (body) body.classList.remove(...classesToRemove);

      root.classList.add(`theme-${computed}`);
      if (body) body.classList.add(`theme-${computed}`);

      if (computed === 'dark' || computed === 'night') {
        root.classList.add('dark');
        if (body) body.classList.add('dark');
      }
    };

    updateTheme();

    if (themeMode === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const listener = () => updateTheme();
      if (mediaQuery.addEventListener) {
        mediaQuery.addEventListener('change', listener);
      } else {
        mediaQuery.addListener(listener);
      }
      return () => {
        if (mediaQuery.removeEventListener) {
          mediaQuery.removeEventListener('change', listener);
        } else {
          mediaQuery.removeListener(listener);
        }
      };
    }
  }, [themeMode]);

  return (
    <ThemeContext.Provider value={{ themeMode, setThemeMode, activeTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
