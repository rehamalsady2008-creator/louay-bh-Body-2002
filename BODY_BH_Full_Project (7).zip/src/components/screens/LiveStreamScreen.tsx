import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Heart, Send, Radio, Gift, CheckCircle2, Users, Flame, Trophy, Award, Sparkles } from 'lucide-react';
import { LiveComment, LiveGift } from '../../types';

interface LiveStreamScreenProps {
  onClose: () => void;
}

export const LiveStreamScreen: React.FC<LiveStreamScreenProps> = ({ onClose }) => {
  const [viewerCount, setViewerCount] = useState(14200);
  const [comments, setComments] = useState<LiveComment[]>([
    { id: '1', username: 'fatima.fit', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=800', verified: true, text: 'Welcome everyone! Live from Four Seasons Bahrain Bay! 🌅' },
    { id: '2', username: 'zayn_power', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=800', verified: true, text: 'Massive energy in Bahrain today 💪' },
    { id: '3', username: 'marcus_shreds', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=800', verified: true, text: 'Sent Bahrain Gold Falcon gift! 🦅' },
  ]);
  const [inputComment, setInputComment] = useState('');
  const [floatingHearts, setFloatingHearts] = useState<{ id: number; left: number }[]>([]);
  const [showGiftDrawer, setShowGiftDrawer] = useState(false);

  const giftsList: LiveGift[] = [
    { id: 'g1', name: 'Bahrain Pearl', icon: '🦪', coinCost: 100 },
    { id: 'g2', name: 'Gold Falcon', icon: '🦅', coinCost: 250 },
    { id: 'g3', name: 'Muscle Trophy', icon: '🏆', coinCost: 500 },
    { id: 'g4', name: 'Bahrain Tower', icon: '🗼', coinCost: 1000 },
  ];

  const handleTapHeart = () => {
    const id = Date.now();
    const left = Math.random() * 80 + 10;
    setFloatingHearts((prev) => [...prev, { id, left }]);
    setTimeout(() => {
      setFloatingHearts((prev) => prev.filter((h) => h.id !== id));
    }, 2000);
  };

  const handleSendComment = () => {
    if (!inputComment.trim()) return;
    const newComm: LiveComment = {
      id: `lc_${Date.now()}`,
      username: 'tariq.bh',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=800',
      verified: true,
      text: inputComment,
    };
    setComments((prev) => [...prev, newComm]);
    setInputComment('');
  };

  const handleSendGift = (gift: LiveGift) => {
    const giftComm: LiveComment = {
      id: `lc_gift_${Date.now()}`,
      username: 'tariq.bh',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=800',
      verified: true,
      text: `Sent a ${gift.name} ${gift.icon}!`,
      gift: gift.icon,
    };
    setComments((prev) => [...prev, giftComm]);
    setShowGiftDrawer(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black text-white flex flex-col justify-between max-w-md mx-auto select-none selection:bg-amber-400 selection:text-black">
      {/* Background Live Stream Video Feed Simulation */}
      <div
        onClick={handleTapHeart}
        className="relative w-full h-full flex items-center justify-center bg-neutral-950 overflow-hidden"
      >
        <img
          src="https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&q=80&w=1200"
          alt="Live Broadcast"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-transparent to-black/90" />

        {/* Floating Hearts Animation */}
        {floatingHearts.map((h) => (
          <motion.div
            key={h.id}
            initial={{ y: 0, opacity: 1, scale: 0.8 }}
            animate={{ y: -320, opacity: 0, scale: 1.6 }}
            transition={{ duration: 2.2, ease: 'easeOut' }}
            style={{ left: `${h.left}%` }}
            className="absolute bottom-24 z-40 pointer-events-none"
          >
            <Heart className="w-9 h-9 text-rose-500 fill-rose-500 drop-shadow-[0_0_25px_rgba(244,63,94,0.9)]" />
          </motion.div>
        ))}

        {/* Top Live Bar Header */}
        <div className="absolute top-11 left-4 right-4 z-20 flex items-center justify-between">
          <div className="flex items-center gap-2 p-1.5 pr-3 rounded-full bg-black/70 backdrop-blur-xl border border-white/20 shadow-lg">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=800"
              alt="Streamer"
              className="w-8 h-8 rounded-full object-cover border border-amber-400"
              referrerPolicy="no-referrer"
            />
            <div>
              <div className="flex items-center gap-1">
                <span className="text-xs font-black text-white">Tariq Al-Mansoori</span>
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
              </div>
              <span className="text-[9px] text-amber-300 font-extrabold uppercase tracking-wider">BODY BH LIVE • BAHRAIN BAY</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500 text-white font-black text-xs animate-pulse shadow-lg shadow-rose-500/40">
              <Radio className="w-3.5 h-3.5" />
              <span>LIVE</span>
              <span className="text-[10px] ml-1 bg-black/40 px-2 py-0.5 rounded-full font-mono">
                {viewerCount.toLocaleString()}
              </span>
            </div>

            <button onClick={onClose} className="p-2 rounded-full bg-black/70 backdrop-blur-md text-white hover:bg-black transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Comments Overlay Stream Bottom Left */}
        <div className="absolute left-4 right-16 bottom-22 z-30 max-h-52 overflow-y-auto space-y-2 pr-2 scrollbar-none">
          {comments.map((c) => (
            <div
              key={c.id}
              className="inline-flex items-center gap-2 p-2 px-3 rounded-2xl bg-black/75 backdrop-blur-xl border border-white/15 text-xs shadow-lg"
            >
              <img
                src={c.avatar}
                alt={c.username}
                className="w-5 h-5 rounded-full object-cover shrink-0"
                referrerPolicy="no-referrer"
              />
              <span className="font-black text-amber-300">{c.username}:</span>
              <span className="text-white font-medium">{c.text}</span>
              {c.gift && <span className="text-base ml-1">{c.gift}</span>}
            </div>
          ))}
        </div>

        {/* Gift Drawer Sheet Modal */}
        <AnimatePresence>
          {showGiftDrawer && (
            <motion.div
              initial={{ y: 200, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 200, opacity: 0 }}
              className="absolute bottom-20 left-4 right-4 z-40 p-4 rounded-3xl bg-black/90 backdrop-blur-2xl border border-amber-400/40 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-3 border-b border-white/10 pb-2">
                <span className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                  <Gift className="w-4 h-4 text-amber-400" />
                  <span>Send Live Gift Token</span>
                </span>
                <button onClick={() => setShowGiftDrawer(false)} className="text-neutral-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-4 gap-2">
                {giftsList.map((g) => (
                  <button
                    key={g.id}
                    onClick={() => handleSendGift(g)}
                    className="flex flex-col items-center gap-1 p-2.5 rounded-2xl bg-neutral-900/90 border border-white/10 hover:border-amber-400 transition-colors"
                  >
                    <span className="text-2xl">{g.icon}</span>
                    <span className="text-[10px] font-bold text-white">{g.name}</span>
                    <span className="text-[9px] text-amber-300 font-extrabold">{g.coinCost} coins</span>
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Bottom Bar Controls */}
        <div className="absolute bottom-5 left-4 right-4 z-30 flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
          <input
            type="text"
            value={inputComment}
            onChange={(e) => setInputComment(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendComment()}
            placeholder="Comment on live..."
            className="flex-1 px-4 py-3 rounded-full bg-black/75 backdrop-blur-xl border border-white/20 text-xs text-white placeholder-neutral-400 focus:outline-none focus:border-amber-400"
          />

          <button
            onClick={() => setShowGiftDrawer(!showGiftDrawer)}
            className="p-3 rounded-full bg-gradient-to-tr from-amber-400 to-amber-200 text-black font-extrabold hover:scale-110 transition-transform shadow-lg shadow-amber-500/20"
            title="Gift Drawer"
          >
            <Gift className="w-4 h-4" />
          </button>

          <button
            onClick={handleTapHeart}
            className="p-3 rounded-full bg-rose-500 text-white font-extrabold hover:scale-110 transition-transform shadow-lg shadow-rose-500/30"
          >
            <Heart className="w-4 h-4 fill-white" />
          </button>
        </div>
      </div>
    </div>
  );
};
