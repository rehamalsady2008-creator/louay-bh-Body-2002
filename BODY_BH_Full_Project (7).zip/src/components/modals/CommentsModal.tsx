import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Send, Heart, CheckCircle2 } from 'lucide-react';
import { CommentItem } from '../../types';

interface CommentsModalProps {
  isOpen: boolean;
  onClose: () => void;
  comments: CommentItem[];
  onAddComment: (text: string) => void;
  postTitle?: string;
}

export const CommentsModal: React.FC<CommentsModalProps> = ({
  isOpen,
  onClose,
  comments,
  onAddComment,
  postTitle = 'Comments',
}) => {
  const [newComment, setNewComment] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    onAddComment(newComment);
    setNewComment('');
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/60 backdrop-blur-md">
        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', stiffness: 380, damping: 32 }}
          className="w-full max-w-md h-[72vh] bg-white border-t border-slate-200 rounded-t-[36px] p-5 flex flex-col justify-between text-slate-900 shadow-2xl relative select-none"
        >
          {/* iOS Handle bar */}
          <div className="w-12 h-1.2 bg-slate-300 rounded-full mx-auto mb-3" />

          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <span className="text-sm font-black tracking-tight text-slate-900">{postTitle} ({comments.length})</span>
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-slate-100 border border-slate-200 text-slate-500 hover:text-slate-900 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Comment list */}
          <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1">
            {comments.length === 0 ? (
              <div className="text-center text-xs text-slate-500 py-10 font-semibold">
                Be the first to comment on BODY BH!
              </div>
            ) : (
              comments.map((comment) => (
                <div key={comment.id} className="flex gap-3 text-xs">
                  <img
                    src={comment.avatar}
                    alt={comment.username}
                    className="w-8.5 h-8.5 rounded-full object-cover border border-amber-400 shrink-0 shadow-xs"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="font-extrabold text-slate-900">{comment.username}</span>
                      {comment.verified && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-600" />}
                      <span className="text-[10px] text-slate-400 font-medium">{comment.timeAgo}</span>
                    </div>
                    <p className="text-slate-700 leading-relaxed font-medium">{comment.text}</p>
                  </div>
                  <button className="flex flex-col items-center gap-0.5 text-slate-400 hover:text-rose-500 transition-colors">
                    <Heart className="w-3.5 h-3.5" />
                    <span className="text-[9px] font-bold">{comment.likesCount}</span>
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Comment input form */}
          <form onSubmit={handleSubmit} className="pt-3 border-t border-slate-200 flex items-center gap-2">
            <input
              type="text"
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Comment on BODY BH post..."
              className="flex-1 px-4 py-3 rounded-full bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-amber-400 shadow-xs"
            />
            <button
              type="submit"
              disabled={!newComment.trim()}
              className="p-3 rounded-full bg-gradient-to-tr from-amber-400 to-amber-300 text-slate-900 font-black disabled:opacity-40 hover:brightness-105 shadow-xs"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
