import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Camera, 
  Check, 
  Mail, 
  ShieldCheck, 
  KeyRound, 
  X, 
  AlertCircle,
  Sparkles,
  Lock
} from 'lucide-react';
import { CURRENT_USER } from '../../data/mockData';

interface EditProfileScreenProps {
  onBack: () => void;
}

export const EditProfileScreen: React.FC<EditProfileScreenProps> = ({ onBack }) => {
  const [name, setName] = useState(CURRENT_USER.name);
  const [username, setUsername] = useState(CURRENT_USER.username);
  const [bio, setBio] = useState(CURRENT_USER.bio);
  const [category, setCategory] = useState(CURRENT_USER.category);
  const [website, setWebsite] = useState(CURRENT_USER.website || '');
  const [location, setLocation] = useState(CURRENT_USER.location || '');
  const [email, setEmail] = useState('user.bh@body.bh');
  const [newEmail, setNewEmail] = useState('');
  
  // Security Email Verification Modal State
  const [showEmailOtpModal, setShowEmailOtpModal] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [emailSuccessMsg, setEmailSuccessMsg] = useState<string | null>(null);
  const [emailErrorMsg, setEmailErrorMsg] = useState<string | null>(null);

  const [isSaved, setIsSaved] = useState(false);

  const handleStartEmailChange = () => {
    if (!newEmail.trim() || newEmail === email) {
      setEmailErrorMsg('يرجى كتابة عنوان بريد إلكتروني جديد مختلف');
      return;
    }
    setEmailErrorMsg(null);
    setIsSendingOtp(true);
    
    setTimeout(() => {
      setIsSendingOtp(false);
      setOtpSent(true);
      setShowEmailOtpModal(true);
    }, 700);
  };

  const handleVerifyEmailOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpCode || otpCode.length < 4) {
      setEmailErrorMsg('أدخل رمز التحقق المكون من 4 أرقام');
      return;
    }
    setEmailErrorMsg(null);
    setIsVerifyingOtp(true);

    setTimeout(() => {
      setIsVerifyingOtp(false);
      setEmail(newEmail);
      setNewEmail('');
      setShowEmailOtpModal(false);
      setOtpSent(false);
      setOtpCode('');
      setEmailSuccessMsg('تم تحديث البريد الإلكتروني بنجاح وتوثيقه بالرمز 🔒');
      setTimeout(() => setEmailSuccessMsg(null), 3500);
    }, 800);
  };

  const handleSave = () => {
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      onBack();
    }, 800);
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 p-4 pt-12 pb-28 max-w-md mx-auto selection:bg-amber-400 selection:text-slate-900">
      {/* Top Bar */}
      <div className="flex items-center justify-between mb-6">
        <button onClick={onBack} className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-900 font-bold transition-colors">
          <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
          <span>رجوع</span>
        </button>

        <span className="text-sm font-black text-slate-900 tracking-tight">تعديل الملف الشخصي 🇧🇭</span>

        <button
          onClick={handleSave}
          className="px-4 py-1.5 rounded-full bg-gradient-to-r from-amber-400 to-amber-300 text-slate-900 font-black text-xs flex items-center gap-1 hover:brightness-105 active:scale-95 transition-all shadow-sm"
        >
          {isSaved ? <Check className="w-4 h-4" /> : 'حفظ'}
        </button>
      </div>

      {/* Avatar Change */}
      <div className="flex flex-col items-center mb-6">
        <div className="relative group cursor-pointer">
          <img
            src={CURRENT_USER.avatar}
            alt="Avatar"
            className="w-24 h-24 rounded-full object-cover border-2 border-amber-400 shadow-lg"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-slate-900/60 rounded-full flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-xs">
            <Camera className="w-6 h-6 text-amber-300" />
            <span className="text-[9px] font-black text-white mt-1 uppercase">تغيير الصورة</span>
          </div>
        </div>
        <button className="text-xs font-black text-amber-600 mt-2.5 hover:underline">
          تعديل صورة الملف الشخصي والغلاف
        </button>
      </div>

      {emailSuccessMsg && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-2xl bg-emerald-500 text-slate-900 font-black text-xs text-center flex items-center gap-2 shadow-xl animate-bounce">
          <ShieldCheck className="w-5 h-5 text-slate-900 shrink-0" />
          <span>{emailSuccessMsg}</span>
        </div>
      )}

      {/* Grouped Form Fields */}
      <div className="space-y-4 bg-slate-50 border border-slate-200 rounded-3xl p-5 shadow-xs text-right">
        <div>
          <label className="text-[11px] font-black text-slate-500 uppercase tracking-wider block mb-1">الاسم الكامل</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3.5 py-3 rounded-2xl bg-white border border-slate-200 text-xs text-slate-900 focus:outline-none focus:border-amber-400 font-semibold shadow-xs"
          />
        </div>

        <div>
          <label className="text-[11px] font-black text-slate-500 uppercase tracking-wider block mb-1">اسم المستخدم (@)</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full px-3.5 py-3 rounded-2xl bg-white border border-slate-200 text-xs text-slate-900 focus:outline-none focus:border-amber-400 font-semibold shadow-xs"
          />
        </div>

        {/* SECURITY ENHANCED EMAIL CHANGE SECTION */}
        <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-300/60 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-amber-800 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-amber-600" />
              <span>البريد الإلكتروني الموثق (للأمان)</span>
            </span>
            <span className="text-[9px] font-bold text-emerald-700 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-md">
              موثق 🟢
            </span>
          </div>

          <div className="text-xs text-slate-800 font-bold bg-white p-2.5 rounded-xl border border-slate-200 flex items-center justify-between">
            <span>{email}</span>
            <Mail className="w-4 h-4 text-slate-400" />
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-600 block mb-1">تعديل البريد الإلكتروني (يتطلب رمز تحقق OTP):</label>
            <div className="flex gap-2">
              <input
                type="email"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                placeholder="أدخل البريد الجديد..."
                className="flex-1 px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 focus:outline-none focus:border-amber-400"
              />
              <button
                type="button"
                onClick={handleStartEmailChange}
                disabled={isSendingOtp}
                className="px-3.5 py-2 rounded-xl bg-amber-400 text-slate-900 font-extrabold text-xs hover:bg-amber-300 transition-colors shrink-0 shadow-xs"
              >
                {isSendingOtp ? 'جاري الإرسال...' : 'إرسال رمز OTP ✉️'}
              </button>
            </div>
            {emailErrorMsg && <p className="text-[10px] text-rose-600 mt-1 font-semibold">{emailErrorMsg}</p>}
          </div>
        </div>

        <div>
          <label className="text-[11px] font-black text-slate-500 uppercase tracking-wider block mb-1">التخصص / المجال</label>
          <input
            type="text"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full px-3.5 py-3 rounded-2xl bg-white border border-slate-200 text-xs text-slate-900 focus:outline-none focus:border-amber-400 font-semibold shadow-xs"
          />
        </div>

        <div>
          <label className="text-[11px] font-black text-slate-500 uppercase tracking-wider block mb-1">الوصف الشخصي (البيو)</label>
          <textarea
            rows={3}
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            className="w-full px-3.5 py-3 rounded-2xl bg-white border border-slate-200 text-xs text-slate-900 focus:outline-none focus:border-amber-400 font-medium shadow-xs"
          />
        </div>

        <div>
          <label className="text-[11px] font-black text-slate-500 uppercase tracking-wider block mb-1">رابط الموقع الإلكتروني</label>
          <input
            type="text"
            value={website}
            onChange={(e) => setWebsite(e.target.value)}
            className="w-full px-3.5 py-3 rounded-2xl bg-white border border-slate-200 text-xs text-slate-900 focus:outline-none focus:border-amber-400 font-semibold shadow-xs"
          />
        </div>
      </div>

      {/* EMAIL OTP VERIFICATION MODAL */}
      {showEmailOtpModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white border border-slate-200 rounded-3xl p-6 text-right relative shadow-2xl">
            <button
              onClick={() => setShowEmailOtpModal(false)}
              className="absolute top-4 left-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="w-12 h-12 rounded-2xl bg-amber-100 border border-amber-300 text-amber-700 flex items-center justify-center mb-3">
              <KeyRound className="w-6 h-6" />
            </div>

            <h3 className="text-base font-black text-slate-900 mb-1">رمز التحقق لتغيير البريد 🔐</h3>
            <p className="text-xs text-slate-600 mb-4 leading-relaxed">
              تم إرسال رمز تحقق كود OTP إلى بريدك الجديد: <span className="text-amber-700 font-bold">{newEmail}</span>
            </p>

            <form onSubmit={handleVerifyEmailOtp} className="space-y-4">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1 text-center">أدخل الرمز المكون من 4 أرقام</label>
                <input
                  type="text"
                  maxLength={4}
                  required
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="1234"
                  className="w-full py-3 px-4 rounded-xl bg-slate-50 border-2 border-amber-400 text-center text-xl font-black tracking-[1em] text-amber-800 focus:outline-none"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowEmailOtpModal(false)}
                  className="py-2.5 px-4 rounded-xl bg-slate-100 text-slate-600 font-bold text-xs hover:bg-slate-200"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isVerifyingOtp}
                  className="flex-1 py-2.5 rounded-xl bg-amber-400 text-slate-900 font-black text-xs hover:bg-amber-300 transition-colors shadow-xs"
                >
                  {isVerifyingOtp ? 'جاري التوثيق...' : 'تأكيد وحفظ البريد 🟢'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
