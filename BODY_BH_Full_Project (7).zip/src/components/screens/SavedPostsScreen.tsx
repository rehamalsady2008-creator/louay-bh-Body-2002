import React, { useState } from 'react';
import { ArrowLeft, Bookmark, Folder, Grid, Trash2 } from 'lucide-react';
import { MOCK_POSTS } from '../../data/mockData';
import { ScreenType } from '../../types';

interface SavedPostsScreenProps {
  onBack: () => void;
  onNavigate: (screen: ScreenType) => void;
}

export const SavedPostsScreen: React.FC<SavedPostsScreenProps> = ({ onBack, onNavigate }) => {
  const [selectedFolder, setSelectedFolder] = useState<string>('All Bookmarks');

  const folders = ['All Bookmarks', 'Workouts', 'Nutrition', 'Inspiration'];

  const savedPosts = MOCK_POSTS.filter((p) => p.isSaved || true);

  return (
    <div className="min-h-screen bg-white text-slate-900 p-4 pt-12 pb-28 max-w-md mx-auto selection:bg-amber-400 selection:text-slate-900">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <button onClick={onBack} className="p-2.5 rounded-full bg-slate-100 border border-slate-200 text-slate-700 hover:text-slate-900 transition-colors shadow-xs">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2">
          <Bookmark className="w-5 h-5 text-amber-600 fill-amber-600" />
          <h1 className="text-sm font-black text-slate-900 tracking-tight uppercase">العناصر المحفوظة</h1>
        </div>
        <div className="w-8" />
      </div>

      {/* Folders Bar */}
      <div className="flex gap-2.5 mb-5 overflow-x-auto scrollbar-none">
        {folders.map((f) => (
          <button
            key={f}
            onClick={() => setSelectedFolder(f)}
            className={`px-4 py-2 rounded-full border text-xs font-black transition-all shrink-0 ${
              selectedFolder === f
                ? 'bg-amber-400 text-slate-900 border-amber-400 shadow-xs scale-105'
                : 'bg-slate-100 text-slate-600 border-slate-200 hover:text-slate-900'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Saved Grid */}
      <div className="grid grid-cols-2 gap-3">
        {savedPosts.map((post) => (
          <div
            key={post.id}
            onClick={() => onNavigate('home')}
            className="relative aspect-square rounded-3xl overflow-hidden bg-slate-100 border border-slate-200 cursor-pointer group shadow-xs hover:border-amber-400 transition-colors"
          >
            <img
              src={post.mediaUrls[0]}
              alt="Saved"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent opacity-90" />

            <div className="absolute bottom-3 left-3 right-3">
              <span className="text-[10px] font-black text-amber-300 block mb-0.5">{post.username}</span>
              <p className="text-[10px] font-semibold text-white truncate drop-shadow-xs">{post.caption}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
