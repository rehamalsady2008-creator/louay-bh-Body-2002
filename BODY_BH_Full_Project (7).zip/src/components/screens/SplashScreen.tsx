import React, { useEffect } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Shield, ChevronRight } from 'lucide-react';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onFinish();
    }, 2400);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div className="relative min-h-screen w-full bg-white flex flex-col items-center justify-between p-8 overflow-hidden select-none">
      {/* Background radial glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-tr from-amber-200/40 via-amber-100/40 to-cyan-100/40 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full flex justify-end">
        <span className="text-[11px] font-semibold text-slate-500 border border-slate-200 px-3 py-1 rounded-full bg-slate-50">
          iOS 26 • v3.8.0
        </span>
      </div>

      {/* Main Logo Emblem */}
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-col items-center text-center my-auto"
      >
        <div className="relative w-32 h-32 rounded-3xl p-1 bg-gradient-to-tr from-amber-300 via-amber-200 to-amber-100 border border-amber-300 shadow-md flex items-center justify-center mb-6 overflow-hidden">
          <img 
            src="/logo.jpg" 
            alt="BODY BH Avatar" 
            className="w-full h-full object-cover rounded-2xl shadow-xs"
            onError={(e) => { e.currentTarget.src = '/logo.jpg'; }}
          />
          <div className="absolute -bottom-1 -right-1 bg-gradient-to-tr from-amber-400 to-amber-300 p-1.5 rounded-full shadow-sm z-10">
            <Sparkles className="w-4 h-4 text-slate-900" />
          </div>
        </div>

        <h1 className="text-3xl font-black tracking-tight text-slate-900 mb-1">
          بودي البحرين 🇧🇭
        </h1>
        <p className="text-xs font-bold text-slate-500 max-w-xs leading-relaxed">
          المنصة الاجتماعية الرسمية الأولى والجامعة لمملكة البحرين 🇧🇭
        </p>
      </motion.div>

      {/* Loading Progress */}
      <div className="w-full max-w-xs flex flex-col items-center gap-3">
        <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
          <motion.div
            initial={{ width: '0%' }}
            animate={{ width: '100%' }}
            transition={{ duration: 2.2, ease: 'easeInOut' }}
            className="h-full bg-gradient-to-r from-amber-400 via-amber-500 to-amber-300"
          />
        </div>
        <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-medium">
          <Shield className="w-3.5 h-3.5 text-amber-500" />
          <span>Encrypted Apple Security • Bahrain Network</span>
        </div>
      </div>
    </div>
  );
};
