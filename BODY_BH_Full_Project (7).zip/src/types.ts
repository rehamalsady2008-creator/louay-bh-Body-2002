export type ScreenType =
  | 'splash'
  | 'login'
  | 'register'
  | 'home'
  | 'stories'
  | 'reels'
  | 'search'
  | 'explore'
  | 'notifications'
  | 'messages'
  | 'chat'
  | 'profile'
  | 'edit-profile'
  | 'settings'
  | 'create-post'
  | 'live-stream'
  | 'body-bh-plus'
  | 'verified-badge'
  | 'saved-posts'
  | 'admin-dashboard'
  | 'followers-list'
  | 'following-list'
  | 'store';

export interface UserProfile {
  id: string;
  name: string;
  username: string;
  avatar: string;
  banner?: string;
  bio: string;
  category: string;
  verified: boolean;
  vipPlus: boolean;
  followersCount: number;
  followingCount: number;
  postsCount: number;
  website?: string;
  location?: string;
  isFollowing?: boolean;
}

export interface CommentItem {
  id: string;
  userId: string;
  username: string;
  avatar: string;
  verified: boolean;
  text: string;
  timeAgo: string;
  likesCount: number;
  isLiked?: boolean;
}

export interface PostItem {
  id: string;
  userId: string;
  username: string;
  userAvatar: string;
  verified: boolean;
  vipPlus: boolean;
  location?: string;
  timeAgo: string;
  mediaType: 'image' | 'video' | 'carousel';
  mediaUrls: string[];
  caption: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  isLiked: boolean;
  isSaved: boolean;
  audioTrack?: string;
  tags?: string[];
  comments: CommentItem[];
}

export interface StoryItem {
  id: string;
  userId: string;
  username: string;
  userAvatar: string;
  verified: boolean;
  hasUnseen: boolean;
  stories: {
    id: string;
    mediaUrl: string;
    mediaType: 'image' | 'video';
    timestamp: string;
    caption?: string;
  }[];
}

export interface ReelItem {
  id: string;
  userId: string;
  username: string;
  userAvatar: string;
  verified: boolean;
  videoUrl: string;
  thumbnail: string;
  audioName: string;
  caption: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  isLiked: boolean;
  isSaved: boolean;
  comments: CommentItem[];
}

export interface NotificationItem {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'mention' | 'live' | 'system';
  userId: string;
  username: string;
  avatar: string;
  verified: boolean;
  timeAgo: string;
  content: string;
  postThumbnail?: string;
  isRead: boolean;
}

export interface MessageItem {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  isVoiceNote?: boolean;
  voiceDuration?: string;
  mediaUrl?: string;
  status: 'sent' | 'delivered' | 'read';
}

export interface ChatThread {
  id: string;
  participant: UserProfile;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  isOnline: boolean;
  isPinned?: boolean;
  messages: MessageItem[];
}

export interface LiveGift {
  id: string;
  name: string;
  icon: string;
  coinCost: number;
}

export interface LiveComment {
  id: string;
  username: string;
  avatar: string;
  verified: boolean;
  text: string;
  gift?: string;
}

export interface AdminAnalytics {
  totalUsers: number;
  monthlyRevenue: number;
  activeLiveStreams: number;
  reportedPostsCount: number;
  dailyActiveUsers: number[];
  revenueData: number[];
}

export interface StoreProduct {
  id: string;
  name: string;
  description: string;
  price: number; // in BHD
  originalPrice?: number;
  category: 'supplements' | 'apparel' | 'equipment' | 'free_perks' | 'nutrition';
  categoryLabel: string;
  image: string;
  rating: number;
  reviewsCount: number;
  inStock: boolean;
  isPopular?: boolean;
  isNew?: boolean;
}

export interface CartItem {
  product: StoreProduct;
  quantity: number;
}
