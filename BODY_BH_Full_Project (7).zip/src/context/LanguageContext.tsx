import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'ar' | 'en';

export interface Translations {
  [key: string]: {
    ar: string;
    en: string;
  };
}

export const TRANSLATIONS: Translations = {
  // Navigation / Tabs
  tabFeed: { ar: 'الرئيسية', en: 'Feed' },
  tabReels: { ar: 'ريلز', en: 'Reels' },
  tabPost: { ar: 'إنشاء', en: 'Post' },
  tabInbox: { ar: 'الرسائل', en: 'Inbox' },
  tabProfile: { ar: 'ملفي', en: 'Profile' },

  // General App Header & Status
  liveNow: { ar: 'بث مباشر الآن', en: 'Live Stream Active' },
  settingsTitle: { ar: 'التفضيلات والإعدادات', en: 'Preferences & Settings' },
  appTitle: { ar: 'بودي البحرين', en: 'BODY BH' },

  // Auth Screens
  welcomeBack: { ar: 'مرحباً بك مجدداً', en: 'Welcome back to BODY BH' },
  loginSub: { ar: 'منصة اللياقة والتواصل الاحترافية في البحرين', en: 'Bahrain’s Premier Fitness & Social Network' },
  emailOrUsername: { ar: 'البريد الإلكتروني أو اسم المستخدم', en: 'Email or Username' },
  password: { ar: 'كلمة المرور', en: 'Password' },
  loginBtn: { ar: 'تسجيل الدخول', en: 'LOG IN' },
  noAccount: { ar: 'ليس لديك حساب؟', en: "Don't have an account?" },
  signUpLink: { ar: 'سجل الآن', en: 'Sign Up' },
  registerTitle: { ar: 'إنشاء حساب جديد', en: 'Create New Account' },
  fullName: { ar: 'الاسم الكامل', en: 'Full Name' },
  username: { ar: 'اسم المستخدم (@)', en: 'Username (@)' },
  selectCategory: { ar: 'التخصص الرياضي', en: 'Category / Specialty' },
  registerBtn: { ar: 'إنشاء الحساب الان', en: 'CREATE ACCOUNT' },
  alreadyHaveAccount: { ar: 'لديك حساب بالفعل؟', en: 'Already have an account?' },

  // Home Feed & Stories
  yourStory: { ar: 'قصتك', en: 'Your Story' },
  addStory: { ar: 'إضافة قصة', en: 'Add Story' },
  watchLive: { ar: 'شاهد البث', en: 'Watch LIVE' },
  likedBy: { ar: 'أعجب بـ', en: 'Liked by' },
  andOthers: { ar: 'وآخرين', en: 'and others' },
  viewComments: { ar: 'عرض جميع التعليقات', en: 'View all comments' },
  addCommentPlaceholder: { ar: 'اكتب تعليقاً في بودي البحرين...', en: 'Comment on BODY BH post...' },

  // Reels
  originalAudio: { ar: 'صوت أصلي', en: 'Original Audio' },
  follow: { ar: 'متابعة', en: 'Follow' },
  following: { ar: 'تمت المتابعة', en: 'Following' },
  share: { ar: 'مشاركة', en: 'Share' },
  save: { ar: 'حفظ', en: 'Save' },

  // Search & Explore
  searchPlaceholder: { ar: 'ابحث عن مدربين، تمارين، وصفات صحية...', en: 'Search creators, workouts, recipes...' },
  trendingTags: { ar: 'الوسوم الأكثر تداولاً في البحرين', en: 'Trending Fitness Tags in Bahrain' },
  popularCreators: { ar: 'أبرز صناع المحتوى', en: 'Popular Creators' },
  exploreAll: { ar: 'استكشف منشورات المجتمع', en: 'Explore Community Feed' },

  // Notifications
  notificationsHeader: { ar: 'النشاط والإشعارات', en: 'Notifications & Activity' },
  markAllRead: { ar: 'تحديد الكل كمقروء', en: 'Mark all read' },
  today: { ar: 'اليوم', en: 'Today' },
  earlier: { ar: 'في وقت سابق', en: 'Earlier' },

  // Messages & Chat
  messagesHeader: { ar: 'الرسائل المباشرة', en: 'Direct Messages' },
  searchChats: { ar: 'البحث في المحادثات...', en: 'Search chats...' },
  typeMessage: { ar: 'اكتب رسالة بصوتك أو نصك...', en: 'Type a message...' },
  online: { ar: 'متصل الآن', en: 'Online' },
  voiceNote: { ar: 'ملاحظة صوتية', en: 'Voice Note' },

  // Profile Screen
  posts: { ar: 'منشورات', en: 'Posts' },
  followers: { ar: 'متابعين', en: 'Followers' },
  followingCount: { ar: 'يتابع', en: 'Following' },
  editProfile: { ar: 'تعديل الملف الشخصي', en: 'Edit Profile' },
  shareProfile: { ar: 'مشاركة الملف', en: 'Share Profile' },
  savedPosts: { ar: 'المحفوظات', en: 'Saved Collection' },
  vipBadge: { ar: 'عضوية BODY BH+ VIP', en: 'BODY BH+ VIP Pass' },
  verifiedCenter: { ar: 'مركز التوثيق', en: 'Verification Center' },

  // Edit Profile Screen
  saveBtn: { ar: 'حفظ', en: 'Save' },
  cancelBtn: { ar: 'إلغاء', en: 'Cancel' },
  categoryPillar: { ar: 'التخصص والتصنيف', en: 'Category Pillar' },
  bioDesc: { ar: 'السيرة الذاتية (Bio)', en: 'Bio Description' },
  websiteUrl: { ar: 'رابط الموقع', en: 'Website URL' },
  locationTag: { ar: 'الموقع الجغرافي', en: 'Location Tag' },
  changePhoto: { ar: 'تغيير صورة الملف الشخصي والغلاف', en: 'Edit Profile Photo & Banner' },

  // Settings Screen
  preferences: { ar: 'تفضيلات النظام iOS 26', en: 'iOS 26 Preferences' },
  privacySecurity: { ar: 'الخصوصية والأمان', en: 'Privacy & Security' },
  privateAccount: { ar: 'حساب خاص', en: 'Private Account' },
  faceIdLock: { ar: 'قفل التطبيق بـ Face ID', en: 'Face ID App Lock' },
  notificationsMedia: { ar: 'الإشعارات والوسائط', en: 'Notifications & Media' },
  pushNotifications: { ar: 'الإشعارات الفورية', en: 'Push Notifications' },
  autoplayAudio: { ar: 'التشغيل التلقائي للصوت', en: 'Auto-Play Audio' },
  languageLocale: { ar: 'اللغة والمنطقة', en: 'Language & Locale' },
  arabicLang: { ar: 'العربية (البحرين)', en: 'العربية (Bahrain)' },
  englishLang: { ar: 'English (US)', en: 'English (US)' },
  openAdminAnalytics: { ar: 'فتح لوحة تحكم المسؤول والتحليلات', en: 'Open System Admin Analytics' },
  signOut: { ar: 'تسجيل الخروج من بودي البحرين', en: 'SIGN OUT OF BODY BH' },

  // Create Post
  newPostTitle: { ar: 'منشور جديد', en: 'New Post' },
  writeCaption: { ar: 'اكتب شرحاً وتفاصيل منشورك...', en: 'Write a caption & workout details...' },
  addLocation: { ar: 'إضافة موقع (المناظر البحرية، الجيم...)', en: 'Add Location (Gym, Bahrain Bay...)' },
  tagPeople: { ar: 'الإشارة إلى أشخاص', en: 'Tag People' },
  addAudio: { ar: 'إضافة مقطع صوتي رياضي', en: 'Add Audio Track' },
  shareNow: { ar: 'نشر المنشور الآن', en: 'SHARE POST NOW' },

  // Live Stream
  liveTitle: { ar: 'البث المباشر المباشر', en: 'Live Stream' },
  liveViewers: { ar: 'مشاهد', en: 'viewers' },
  sendGift: { ar: 'إرسال هدية', en: 'Send Gift' },
  endStream: { ar: 'إنهاء البث', en: 'End Stream' },

  // Body BH Free App
  vipTitle: { ar: 'تطبيق مجاني 100% لكل البحرين 🇧🇭', en: '100% Free App For Bahrain 🇧🇭' },
  vipSub: { ar: 'تم إلغاء كافة الاشتراكات! جميع المميزات والدعم مجاني للجميع', en: 'All subscriptions cancelled! All features 100% free' },
  subscribeBhd: { ar: 'مجاني بالكامل (0 د.ب)', en: '100% Free Always (0 BHD)' },

  // Admin Dashboard
  adminTitle: { ar: 'لوحة تحكم وتوجيه النظام', en: 'System Admin Control' },
  activeUsers: { ar: 'المستخدمون النشطون', en: 'Active Users' },
  monthlyRevenue: { ar: 'الإيرادات الشهرية', en: 'Monthly Revenue' },
  dailyActiveEngagement: { ar: 'التفاعل اليومي في شبكة البحرين', en: 'Daily Active Engagement' },
  moderationQueue: { ar: 'قائمة الرقابة والمراجعة', en: 'Content Moderation Queue' },
  dismiss: { ar: 'تجاهل', en: 'Dismiss' },
  resolve: { ar: 'اعتماد القرار', en: 'Resolve' },

  // Verified Badge
  verifiedStatusApproved: { ar: 'الحالة: موثق ومُعتمد رسمياً', en: 'STATUS: APPROVED & ACTIVE' },
  verifiedCenterDesc: { ar: 'تأكيد هوية صناع المحتوى والرياضيين والشخصيات العامة في البحرين.', en: 'Confirms authenticity for recognized Bahrain creators, fitness ambassadors, and public figures.' },
  documentName: { ar: 'بطاقة_الهوية_البحرينية_CPR.pdf', en: 'Bahrain_CPR_Identity.pdf' },
  doneBtn: { ar: 'تم', en: 'DONE' },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType>({
  language: 'ar',
  setLanguage: () => {},
  t: (key) => key,
  isRTL: true,
});

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('body_bh_lang');
    return (saved === 'en' || saved === 'ar') ? saved : 'ar';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('body_bh_lang', lang);
  };

  const isRTL = language === 'ar';

  useEffect(() => {
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [isRTL, language]);

  const t = (key: string): string => {
    if (TRANSLATIONS[key]) {
      return TRANSLATIONS[key][language] || TRANSLATIONS[key]['en'];
    }
    return key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRTL }}>
      <div dir={isRTL ? 'rtl' : 'ltr'} className={isRTL ? 'font-arabic' : 'font-sans'}>
        {children}
      </div>
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);
