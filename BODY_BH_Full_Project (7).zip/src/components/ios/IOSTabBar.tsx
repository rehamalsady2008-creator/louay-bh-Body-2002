import React from 'react';
import { Home, PlaySquare, Search, Send } from 'lucide-react';
import { motion } from 'motion/react';
import { ScreenType } from '../../types';
import { useLanguage } from '../../context/LanguageContext';
import { CURRENT_USER } from '../../data/mockData';

interface IOSTabBarProps {
  activeScreen: ScreenType;
  onSelectTab: (screen: ScreenType) => void;
  unreadMessagesCount?: number;
  unreadNotificationsCount?: number;
  userAvatar?: string;
}

export const IOSTabBar: React.FC<IOSTabBarProps> = ({
  activeScreen,
  onSelectTab,
  unreadMessagesCount = 1,
  userAvatar,
}) => {
  const { t } = useLanguage();
  const avatarSrc = userAvatar || CURRENT_USER.avatar || '/logo.jpg';

  const tabs = [
    { id: 'home' as ScreenType, label: t('tabFeed'), icon: Home },
    { id: 'reels' as ScreenType, label: t('tabReels'), icon: PlaySquare },
    { id: 'messages' as ScreenType, label: t('tabInbox'), icon: Send, hasBadge: unreadMessagesCount > 0 },
    { id: 'search' as ScreenType, label: t('exploreAll'), icon: Search },
    { id: 'profile' as ScreenType, label: t('tabProfile'), isAvatar: true },
  ];

  return (
    <div className="fixed bottom-3 left-0 right-0 z-40 px-4 max-w-md mx-auto pointer-events-none">
      <div className="pointer-events-auto relative flex items-center justify-between p-1.5 rounded-full bg-[#121214]/92 backdrop-blur-2xl border border-white/15 shadow-[0_16px_40px_rgba(0,0,0,0.6)]">
        {tabs.map((tab) => {
          const isActive = activeScreen === tab.id;

          if (tab.isAvatar) {
            return (
              <button
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                className="relative flex items-center justify-center p-1.5 rounded-full transition-transform hover:scale-105 active:scale-95 shrink-0"
              >
                {isActive && (
                  <motion.div
                    layoutId="activeTabPill"
                    className="absolute inset-0 rounded-full bg-neutral-700/80 border border-white/20"
                    transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                  />
                )}
                <img
                  src={avatarSrc}
                  alt="Profile"
                  className={`relative z-10 w-7 h-7 rounded-full object-cover border transition-all ${
                    isActive ? 'border-amber-400 ring-2 ring-amber-400/50 scale-105' : 'border-white/20 opacity-90'
                  }`}
                  referrerPolicy="no-referrer"
                />
              </button>
            );
          }

          const Icon = tab.icon!;

          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`relative flex items-center justify-center py-2 px-4 rounded-full transition-all duration-200 shrink-0 ${
                isActive ? 'text-white font-bold' : 'text-white/70 hover:text-white active:scale-95'
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="activeTabPill"
                  className="absolute inset-0 rounded-full bg-neutral-700/80 border border-white/10 shadow-inner"
                  transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                />
              )}

              <div className="relative z-10 flex items-center justify-center">
                <Icon
                  className={`w-6 h-6 transition-all duration-200 ${
                    isActive ? 'text-white scale-110' : 'text-white/80'
                  } ${tab.id === 'messages' ? 'rotate-[-10deg]' : ''}`}
                />

                {tab.hasBadge && (
                  <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-rose-500 rounded-full ring-2 ring-[#121214]" />
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};


