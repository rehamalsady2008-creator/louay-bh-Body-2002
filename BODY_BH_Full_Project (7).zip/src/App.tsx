import React, { useState, useEffect } from 'react';
import { ScreenType, StoryItem, ChatThread, UserProfile, PostItem } from './types';
import { IOSStatusBar } from './components/ios/IOSStatusBar';
import { IOSTabBar } from './components/ios/IOSTabBar';
import { onAuthStateChanged, auth } from './lib/firebase';
import { useTheme } from './context/ThemeContext';

import { SplashScreen } from './components/screens/SplashScreen';
import { LoginScreen } from './components/screens/LoginScreen';
import { RegisterScreen } from './components/screens/RegisterScreen';
import { HomeScreen } from './components/screens/HomeScreen';
import { StoriesScreen } from './components/screens/StoriesScreen';
import { ReelsScreen } from './components/screens/ReelsScreen';
import { SearchScreen } from './components/screens/SearchScreen';
import { ExploreScreen } from './components/screens/ExploreScreen';
import { NotificationsScreen } from './components/screens/NotificationsScreen';
import { MessagesScreen } from './components/screens/MessagesScreen';
import { ChatScreen } from './components/screens/ChatScreen';
import { ProfileScreen } from './components/screens/ProfileScreen';
import { EditProfileScreen } from './components/screens/EditProfileScreen';
import { SettingsScreen } from './components/screens/SettingsScreen';
import { CreatePostScreen } from './components/screens/CreatePostScreen';
import { LiveStreamScreen } from './components/screens/LiveStreamScreen';
import { BodyBhPlusScreen } from './components/screens/BodyBhPlusScreen';
import { VerifiedBadgeModal } from './components/screens/VerifiedBadgeModal';
import { SavedPostsScreen } from './components/screens/SavedPostsScreen';
import { AdminDashboardScreen } from './components/screens/AdminDashboardScreen';
import { FollowersListScreen } from './components/screens/FollowersListScreen';
import { StoreScreen } from './components/screens/StoreScreen';

import { MOCK_CHATS, CURRENT_USER } from './data/mockData';

export default function App() {
  const { activeTheme } = useTheme();
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('splash');
  const [activeStory, setActiveStory] = useState<StoryItem | null>(null);
  const [activeChat, setActiveChat] = useState<ChatThread | null>(MOCK_CHATS[0]);
  const [notificationText, setNotificationText] = useState<string | null>(null);

  // Clean brand-new user profile state
  const [userProfile, setUserProfile] = useState<UserProfile>({
    id: 'user_me',
    name: 'عضو جديد',
    username: 'user.bh',
    avatar: '/logo.jpg',
    banner: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&q=80&w=1200',
    bio: 'مرحباً بك في حسابي الرسمي على منصة BODY BH 🇧🇭 | لياقة ومحتوى الرياضة في مملكة البحرين',
    category: 'عضو جديد 🇧🇭',
    verified: true,
    vipPlus: true,
    followersCount: 0,
    followingCount: 0,
    postsCount: 0,
    website: 'https://body.bh',
    location: 'المنامة، مملكة البحرين'
  });

  const [userPosts, setUserPosts] = useState<PostItem[]>([]);

  // Listen to Firebase Real Authentication state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (fbUser) => {
      if (fbUser) {
        setUserProfile((prev) => ({
          ...prev,
          id: fbUser.uid,
          name: fbUser.displayName || prev.name || 'عضو جديد',
          username: fbUser.email ? fbUser.email.split('@')[0] : prev.username,
          avatar: fbUser.photoURL || prev.avatar || '/logo.jpg',
        }));
      }
    });
    return () => unsubscribe();
  }, []);

  const handleLoginOrRegister = (userData?: { name?: string; username?: string; email?: string; photoURL?: string }) => {
    if (userData) {
      setUserProfile((prev) => ({
        ...prev,
        name: userData.name || prev.name,
        username: userData.username || prev.username,
        avatar: userData.photoURL || prev.avatar,
        postsCount: userPosts.length,
        followersCount: 0,
        followingCount: 0,
      }));
    }
    setCurrentScreen('home');
  };

  const handleCreatePost = (postData: { mediaUrl: string; mediaType?: 'image' | 'video'; title?: string; caption: string; location: string }) => {
    const fullCaption = postData.title 
      ? `📌 ${postData.title}\n${postData.caption}`
      : (postData.caption || 'منشوري الجديد على منصة BODY BH! 💥');

    const newPost: PostItem = {
      id: `post_${Date.now()}`,
      userId: userProfile.id,
      username: userProfile.username,
      userAvatar: userProfile.avatar || '/logo.jpg',
      verified: true,
      vipPlus: true,
      timeAgo: 'الآن',
      location: postData.location || 'المنامة، مملكة البحرين 🇧🇭',
      caption: fullCaption,
      mediaUrls: [postData.mediaUrl],
      mediaType: postData.mediaType || 'image',
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      isLiked: false,
      isSaved: false,
      comments: []
    };

    setUserPosts((prev) => [newPost, ...prev]);
    setUserProfile((prev) => ({
      ...prev,
      postsCount: prev.postsCount + 1
    }));
    setCurrentScreen('profile');
  };

  const hideTabBar = [
    'splash',
    'login',
    'register',
    'chat',
    'stories',
    'live-stream',
    'edit-profile',
    'settings',
    'verified-badge',
    'admin-dashboard',
    'followers-list',
    'following-list',
  ].includes(currentScreen);

  const isDarkOrNight = activeTheme === 'dark' || activeTheme === 'night';

  return (
    <div className={`min-h-screen font-sans antialiased selection:bg-amber-400 selection:text-slate-900 transition-colors duration-300 ${
      activeTheme === 'light' ? 'bg-slate-100 text-slate-900' : activeTheme === 'night' ? 'bg-black text-white' : 'bg-slate-950 text-slate-100'
    }`}>
      {/* Container wrapper mimicking iOS device viewport */}
      <div className={`relative max-w-md mx-auto min-h-screen overflow-x-hidden shadow-2xl transition-colors duration-300 ${
        activeTheme === 'light' ? 'bg-white border-x border-slate-200 text-slate-900' : activeTheme === 'night' ? 'bg-black border-x border-neutral-900 text-white' : 'bg-slate-900 border-x border-slate-800 text-slate-100'
      }`}>
        
        {/* iOS Status Bar with Dynamic Island */}
        {currentScreen !== 'splash' && (
          <IOSStatusBar
            activeNotification={notificationText}
            isLiveActive={currentScreen === 'live-stream'}
          />
        )}

        {/* Screen Router */}
        <main className="w-full">
          {currentScreen === 'splash' && (
            <SplashScreen onFinish={() => setCurrentScreen('login')} />
          )}

          {currentScreen === 'login' && (
            <LoginScreen
              onLoginSuccess={(userData) => handleLoginOrRegister(userData)}
              onGoToRegister={() => setCurrentScreen('register')}
            />
          )}

          {currentScreen === 'register' && (
            <RegisterScreen
              onRegisterSuccess={(userData) => handleLoginOrRegister(userData)}
              onGoToLogin={() => setCurrentScreen('login')}
            />
          )}

          {currentScreen === 'home' && (
            <HomeScreen
              userProfile={userProfile}
              onNavigate={(s) => setCurrentScreen(s)}
              onOpenStory={(story) => setActiveStory(story)}
              onOpenLiveStream={() => setCurrentScreen('live-stream')}
            />
          )}

          {currentScreen === 'reels' && <ReelsScreen />}

          {currentScreen === 'search' && (
            <SearchScreen onNavigate={(s) => setCurrentScreen(s)} />
          )}

          {currentScreen === 'explore' && (
            <ExploreScreen
              onNavigate={(s) => setCurrentScreen(s)}
              onOpenLiveStream={() => setCurrentScreen('live-stream')}
            />
          )}

          {currentScreen === 'notifications' && (
            <NotificationsScreen
              onNavigate={(s) => setCurrentScreen(s)}
              onOpenLiveStream={() => setCurrentScreen('live-stream')}
            />
          )}

          {currentScreen === 'messages' && (
            <MessagesScreen
              userProfile={userProfile}
              onSelectChat={(chat) => {
                setActiveChat(chat);
                setCurrentScreen('chat');
              }}
              onNavigate={(s) => setCurrentScreen(s)}
            />
          )}

          {currentScreen === 'chat' && activeChat && (
            <ChatScreen
              chat={activeChat}
              onBack={() => setCurrentScreen('messages')}
            />
          )}

          {currentScreen === 'profile' && (
            <ProfileScreen
              userProfile={userProfile}
              userPosts={userPosts}
              onNavigate={(s) => setCurrentScreen(s)}
            />
          )}

          {currentScreen === 'edit-profile' && (
            <EditProfileScreen onBack={() => setCurrentScreen('profile')} />
          )}

          {currentScreen === 'settings' && (
            <SettingsScreen
              onBack={() => setCurrentScreen('profile')}
              onNavigate={(s) => setCurrentScreen(s)}
              onLogout={() => setCurrentScreen('login')}
            />
          )}

          {currentScreen === 'create-post' && (
            <CreatePostScreen
              onBack={() => setCurrentScreen('profile')}
              onPostSuccess={handleCreatePost}
            />
          )}

          {currentScreen === 'live-stream' && (
            <LiveStreamScreen onClose={() => setCurrentScreen('home')} />
          )}

          {currentScreen === 'body-bh-plus' && (
            <BodyBhPlusScreen onBack={() => setCurrentScreen('profile')} />
          )}

          {currentScreen === 'store' && (
            <StoreScreen
              onBack={() => setCurrentScreen('home')}
              onNavigate={(s) => setCurrentScreen(s)}
            />
          )}

          {currentScreen === 'verified-badge' && (
            <VerifiedBadgeModal onBack={() => setCurrentScreen('profile')} />
          )}

          {currentScreen === 'saved-posts' && (
            <SavedPostsScreen
              onBack={() => setCurrentScreen('profile')}
              onNavigate={(s) => setCurrentScreen(s)}
            />
          )}

          {currentScreen === 'admin-dashboard' && (
            <AdminDashboardScreen onBack={() => setCurrentScreen('profile')} />
          )}

          {currentScreen === 'followers-list' && (
            <FollowersListScreen
              initialTab="followers"
              followersCount={userProfile.followersCount}
              followingCount={userProfile.followingCount}
              onBack={() => setCurrentScreen('profile')}
              onNavigate={(s) => setCurrentScreen(s)}
            />
          )}

          {currentScreen === 'following-list' && (
            <FollowersListScreen
              initialTab="following"
              followersCount={userProfile.followersCount}
              followingCount={userProfile.followingCount}
              onBack={() => setCurrentScreen('profile')}
              onNavigate={(s) => setCurrentScreen(s)}
            />
          )}
        </main>

        {/* Stories Overlay Popup */}
        {activeStory && (
          <StoriesScreen
            story={activeStory}
            onClose={() => setActiveStory(null)}
          />
        )}

        {/* Floating Glass Bottom Tab Bar */}
        {!hideTabBar && (
          <IOSTabBar
            activeScreen={currentScreen}
            userAvatar={userProfile.avatar}
            onSelectTab={(screen) => setCurrentScreen(screen)}
          />
        )}
      </div>
    </div>
  );
}
